<?php


namespace ExpertSMS\Shortcodes;

use ExpertSMS\Core\Singleton;
use ExpertSMS\Core\Utils;

/**
 * Class PostsType
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Shortcodes
 */
class ProductsType extends ShortcodeSetup {

	use Singleton;

	/**
	 * @inhertDoc
	 *
	 * @since 6.0.0
	 * @return string
	 */
	protected function get_tag(): string {

		return 'smsNewslettersProduct';
	}

	/**
	 * @inhertDoc
	 *
	 * @since 6.0.0
	 * @return string
	 */
	public function id(): string {

		return 'products';
	}

	public function display( array $attrs ): void {

		$expert_sms_options = wp_parse_args(
			[
				'theme'       => 'newsletter-btn-red',//default value
				'popup_title' => 'خبرنامه پیامکی',//default value
			],
			get_option( 'expert_sms_settings', [] )
		);

		$user = wp_get_current_user();

		$view = sprintf( 'front.%s.single', rtrim( $this->id(), 's' ) );

		Utils::load_views( $view, compact( 'attrs', 'expert_sms_options', 'user' ) );
	}

	/**
	 * Register user to posts table.(wp_prefix_smsnews_posts DataBase table)
	 *
	 * @since 6.0.0
	 * @return void
	 */
	public function register_user(): void {

		global $wpdb;
		$mobile = ! empty( $_POST['mobile'] ) && isset( $_POST['mobile'] ) ? $_POST['mobile'] : null;
		if ( ! is_user_logged_in() ) {
			$username = ! empty( $_POST['username'] ) && isset( $_POST['username'] ) ? $_POST['username'] : null;
		} else {
			$user     = wp_get_current_user();
			$username = (string) ( $user && $user->user_login );
		}
		$nonce          = ! empty( $_POST['nonce'] ) && isset( $_POST['nonce'] ) ? $_POST['nonce'] : null;
		$product_id     = ! empty( $_POST['product_id'] ) && isset( $_POST['product_id'] ) ? $_POST['product_id'] : null;
		$register_error = $this->request_validation( $product_id, $username, $mobile, $nonce );
		$terms          = get_the_terms( $product_id, [ 'taxonomy' => 'product_cat' ] );
		$error          = [
			'Repetitious'       => __( 'عملیات ناموفق ، شما قبلاً در خبرنامه این پست عضو شده اید !!', 'expert-sms' ),
			'invalid'           => __( 'عملیات ناموفق ، شماره تلفن وارد شده نا معتبر می باشد !!', 'expert-sms' ),
			'empty_data_nopriv' => __( 'فیلد شماره تلفن همراه و نام کاربری خالی می باشد .', 'expert-sms' ),
			'empty_data'        => __( 'فیلد شماره تلفن همراه خالی می باشد .', 'expert-sms' ),
		];
		switch ( $register_error ) {
			case 'Repetitious':
				$message = $error['Repetitious'];
				wp_send_json( [
					'status_message' => false,
					'report_message' => $message
				] );
				break;
			case 'invalid':
				$message = $error['invalid'];
				wp_send_json( [
					'status_message' => false,
					'report_message' => $message
				] );
				break;
			case 'empty_data':
				if ( ! is_user_logged_in() ) {
					$message = $error['empty_data_nopriv'];
				} else {
					$message = $error['empty_data'];
				}
				wp_send_json( [
					'status_message' => false,
					'report_message' => $message
				] );
				break;
			case 'success':
				foreach ( $terms as $term ) {
					$cat_id[]   = $term->term_id;
					$cat_name[] = $term->name;
				}
				$userdata = $wpdb->insert( $wpdb->prefix . 'expert_sms_products', [
					'product_id'      => $product_id,
					'term_id'         => serialize( $cat_id ?? [] ),
					'mobile'          => $mobile,
					'user_name'       => esc_html( $username ),
					'term_name'       => serialize( $cat_name ?? [] ),
					'product_name'    => get_the_title( $product_id ),
					'purchase_status' => false
				], [ '%d', '%s', '%s', '%s', '%s', '%s', '%d' ] );

				if ( $userdata ) {
					$data_id = $wpdb->insert_id;
				} else {
					$data_id = $wpdb->last_error;
				}
				if ( ! is_user_logged_in() ) {
					do_action( 'expert_sms_user_register', $username, $mobile );
				}
				$message = __( 'درخواست شما برای عضویت در سامانه پیامکی با موفقیت ثبت شد .', 'expert-sms' );
				wp_send_json( [
					'status_message' => true,
					'report_message' => $message,
					'user_id'        => $data_id,
				] );
				break;
		}
	}
}
