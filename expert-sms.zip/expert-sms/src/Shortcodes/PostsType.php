<?php


namespace ExpertSMS\Shortcodes;

use ExpertSMS\Core\Singleton;
use ExpertSMS\Core\Utils;

/**
 * Class PostsType
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Shortcodes
 */
class PostsType extends ShortcodeSetup {

	use Singleton;

	public function __construct() {

		parent::__construct();

		add_action( "wp_ajax_register_newsletters_post_user", [ $this, 'register_user' ] );
		add_action( "wp_ajax_nopriv_register_newsletters_post_user", [ $this, 'register_user' ] );
	}

	/**
	 * @inhertDoc
	 *
	 * @since 6.0.0
	 * @return string
	 */
	protected function get_tag(): string {

		return 'smsNewsletters';
	}

	/**
	 * @inhertDoc
	 *
	 * @since 6.0.0
	 * @return string
	 */
	public function id(): string {

		return 'posts';
	}

	public function display( array $attrs ): void {

		$expert_sms_options = wp_parse_args(
			get_option( 'expert_sms_settings', [] ),
			[
				'theme'       => 'newsletter-btn-red',//default value
				'popup_title' => 'خبرنامه پیامکی',//default value
			]
		);

		$user = wp_get_current_user();

		Utils::load_views( 'front.post.single', compact( 'attrs', 'expert_sms_options', 'user' ) );
	}

	/**
	 * Register user to posts table.(wp_prefix_smsnews_posts DataBase table)
	 *
	 * @since 6.0.0
	 * @return void
	 */
	public function register_user(): void {

		global $wpdb;

		$mobile = ! empty( $_POST['mobile'] ) && isset( $_POST['mobile'] ) ? $_POST['mobile'] : null;

		if ( ! is_user_logged_in() ) {
			$username = ! empty( $_POST['username'] ) && isset( $_POST['username'] ) ? $_POST['username'] : null;
		} else {
			$user = wp_get_current_user();
			if ( $user && $user->ID ) {
				$username = $user->display_name;
			}
		}

		$nonce          = ! empty( $_POST['nonce'] ) && isset( $_POST['nonce'] ) ? $_POST['nonce'] : null;
		$postID         = ! empty( $_POST['pid'] ) && isset( $_POST['pid'] ) ? $_POST['pid'] : null;
		$register_error = $this->request_validation( $postID, $username, $mobile, $nonce );
		$terms          = get_the_category( $postID );
		$error          = [
			'Repetitious'       => __( 'عملیات ناموفق ، شما قبلاً در خبرنامه این پست عضو شده اید !!', 'expert-sms' ),
			'invalid'           => __( 'عملیات ناموفق ، شماره تلفن وارد شده نا معتبر می باشد !!', 'expert-sms' ),
			'empty_data_nopriv' => __( 'فیلد شماره تلفن همراه و نام کاربری خالی می باشد .', 'expert-sms' ),
			'empty_data'        => __( 'فیلد شماره تلفن همراه خالی می باشد .', 'expert-sms' ),
		];

		switch ( $register_error ) {

			case 'Repetitious':
				$message = $error['Repetitious'];
				wp_send_json( [
					'status_message' => false,
					'report_message' => $message
				] );
				break;

			case 'invalid':
				$message = $error['invalid'];
				wp_send_json( [
					'status_message' => false,
					'report_message' => $message
				] );
				break;

			case 'empty_data':
				if ( ! is_user_logged_in() ) {
					$message = $error['empty_data_nopriv'];
				} else {
					$message = $error['empty_data'];
				}
				wp_send_json( [
					'status_message' => false,
					'report_message' => $message
				] );
				break;
			case 'success':
				foreach ( $terms as $term ) {
					$cat_id[]   = $term->term_id;
					$cat_name[] = $term->name;
				}

				$userdata = $wpdb->insert( $wpdb->prefix . 'smsnews_posts', [
					'post_id'   => $postID,
					'term_id'   => serialize( $cat_id ?? [] ),
					'mobile'    => $mobile,
					'user_name' => esc_html( $username ),
					'term_name' => serialize( $cat_name ?? [] ),
					'post_name' => get_the_title( (int) $postID )
				], [ '%d', '%s', '%s', '%s', '%s', '%s' ] );

				if ( $userdata ) {
					$data_id = $wpdb->insert_id;
				} else {
					$data_id = $wpdb->last_error;
				}
				if ( ! is_user_logged_in() ) {
					do_action( 'expert_sms_user_register', $username, $mobile );
				}
				$message = __( 'درخواست شما برای عضویت در سامانه پیامکی با موفقیت ثبت شد .', 'expert-sms' );
				wp_send_json( [
					'status_message' => true,
					'report_message' => $message,
					'user_id'        => $data_id,
				] );
				break;
		}
	}
}
