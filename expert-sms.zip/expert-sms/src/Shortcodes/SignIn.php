<?php


namespace ExpertSMS\Shortcodes;

use ExpertSMS\Controllers\HooksController;
use ExpertSMS\Core\Utils;

/**
 * Class SignIn
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Shortcodes
 */
class SignIn extends ShortcodeSetup {

	public function __construct( HooksController $hooks ) {

		parent::__construct( $hooks );

		add_action( 'wp_ajax_nopriv_resend_code', [ $this, 'resend_code' ] );
		add_action( 'wp_ajax_nopriv_signin_user', [ $this, 'signin_user' ] );
	}

	protected function get_tag(): string {

		return 'expert_sms_signin';
	}

	public function display( array $attrs ): void {

		Utils::load_views( 'back.pages.signin', compact( 'attrs' ) );
	}

	public function id(): string {

		return 'sign-in';
	}

	/**
	 * @hooked 'wp_ajax_nopriv_resend_code'
	 *
	 * @since  6.0.0
	 */
	public function resend_code(): void {

		$verify_code = random_number( 4 );

		$send_verify_code = send_verify_code( $_POST['mobile'], $verify_code, $this->hooks );
		wp_send_json_success( [
			'message'           => __( 'یک کد چهار رقمی برای شما ارسال شد لطفاْ کد مورد نظر را وارد نمایید .', 'expert-sms' ),
			'show_verify_field' => $send_verify_code ? : false,
		] );
	}

	/**
	 * @hooked 'wp_ajax_signin_user'
	 *
	 * @since  6.0.0
	 */
	public function signin_user(): void {

		global $expert_sms_options;

		$mobile      = ! empty( $_POST['mobile'] ) && isset( $_POST['mobile'] ) ? $_POST['mobile'] : null;
		$verify_code = random_number( 4 );

		if ( ! validate_mobile_number( $mobile ) ) {

			wp_send_json( [
				'status'  => false,
				'message' => __( 'لطفاْ یک شماره همراه معتبر وارد نمایید .', 'expert-sms' ),
			] );
		}

		$input_code = $_POST['verify_code'] ?? '';

		if (
			! isset( $_POST['nonce'] )
			|| ! wp_verify_nonce( $_POST['nonce'], 'signin_user' )
		) {

			wp_send_json( [
				'success' => false,
				'message' => __( 'هنگام ارسال درخواست مشکلی در سیستم بوجود آمد لطفاً دوباره امتحان کنید .', 'expert-sms' ),
			] );

		} else {

			if ( ! username_exists( $mobile ) ) {

				wp_send_json( [
					'success' => false,
					'message' => __( 'لطفاً ابتدا در سایت ثبت نام کرده و سپس وارد شوید !', 'expert-sms' ),
				] );
			}

			if ( empty( $input_code ) ) {

				$send_verify_code = send_verify_code( $mobile, $verify_code, $this->hooks );
				wp_send_json_success( [
					'message'           => __( 'یک کد چهار رقمی برای شما ارسال شد لطفاْ کد مورد نظر را وارد نمایید .', 'expert-sms' ),
					'resend'            => '<a href="#" class="resend-code">ارسال مجدد</a>',
					'show_verify_field' => $send_verify_code ? : false,
				] );
			}

			if ( $input_code !== $this->get_verify_code( $mobile ) ) {

				wp_send_json( [
					'status'  => false,
					'message' => __( 'کد تایید وارد شده صحیح نیست !', 'expert-sms' ),
				] );
			}

			// Automatic login //
			$user = get_user_by( 'login', $mobile );

			// Redirect URL
			if ( is_wp_error( $user ) ) {

				wp_send_json( [
					'status'  => false,
					'message' => __( 'ورود موفقیت آمیز نبود ُ لطفاْ دوباره تلاش کنید.', 'expert-sms' ),
				] );
			}

			wp_clear_auth_cookie();
			wp_set_current_user( $user->ID );
			wp_set_auth_cookie( $user->ID );

			$redirect_to = isset( $expert_sms_options['redirect_after_login'] ) ? : home_url();

			wp_send_json_success( [
				'message'  => __( 'شما با موفقیت وارد شدید.', 'expert-sms' ),
				'redirect' => true,
			] );

			wp_redirect( $redirect_to );

			exit();
		}
	}

	/**
	 * Get verification code.
	 *
	 * @param $mobile
	 *
	 * @since 6.0.0
	 * @return string
	 */
	public function get_verify_code( $mobile ): string {

		global $wpdb;

		$data = $wpdb->get_row( $wpdb->prepare( "
						SELECT  code FROM {$wpdb->prefix}user_verification
						WHERE mobile LIKE %s
						", $mobile ) );

		if ( is_null( $data ) ) {

			return false;
		}

		return $data->code;
	}
}