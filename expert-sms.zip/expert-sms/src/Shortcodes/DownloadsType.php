<?php

namespace ExpertSMS\Shortcodes;

use ExpertSMS\Core\Singleton;

/**
 * Class DownloadsType
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Shortcodes
 */
class DownloadsType extends ShortcodeSetup {

	use Singleton;

	/**
	 * DownloadsType constructor.
	 *
	 * @since 6.0.0
	 */
	public function __construct() {

		parent::__construct();

		add_action( "wp_ajax_register_newsletters_download_user", 'register_user' );
		add_action( "wp_ajax_nopriv_register_newsletters_download_user", 'register_user' );
	}

	/**
	 * @inhertDoc
	 *
	 * @since 6.0.0
	 * @return string
	 */
	public function id(): string {

		return 'downloads';
	}

	/**
	 * @inhertDoc
	 *
	 * @since 6.0.0
	 * @return string
	 */
	protected function get_tag(): string {

		return 'smsNewslettersDownload';
	}

	/**
	 * Display shortcode template.
	 *
	 * @param array $attrs
	 *
	 * @since 6.0.0
	 * @return void
	 */
	public function display( array $attrs ): void {

		$expert_sms_options = wp_parse_args(
			[
				'theme'       => 'newsletter-btn-red',//default value
				'popup_title' => __( 'خبرنامه پیامکی', 'expert-sms' ),//default value
			],
			get_option( 'expert_sms_settings', [] )
		);

		expert_sms_load_views( 'front.download.single-download', compact( 'expert_sms_options', 'attrs' ) );
	}

	/**
	 * Register user to downloads table.(wp_prefix_smsnews_downloads DataBase table)
	 *
	 * @since 6.0.0
	 * @return void
	 */
	public function register_user(): void {

		global $wpdb;

		$mobile      = ! empty( $_POST['mobile'] ) && isset( $_POST['mobile'] ) ? $_POST['mobile'] : null;
		$nonce       = ! empty( $_POST['nonce'] ) && isset( $_POST['nonce'] ) ? $_POST['nonce'] : null;
		$download_id = ! empty( $_POST['download_id'] ) && isset( $_POST['download_id'] ) ? $_POST['download_id'] : null;

		if ( ! is_user_logged_in() ) {
			$username = ! empty( $_POST['username'] ) && isset( $_POST['username'] ) ? $_POST['username'] : null;
		} else {
			$user     = wp_get_current_user();
			$username = (string) ( $user && $user->user_login );
		}

		$register_error = $this->request_validation( $download_id, $username, $mobile, $nonce );
		$categories     = get_the_terms( $download_id, 'download_category' );
		$error          = [
			'Repetitious'       => __( 'عملیات ناموفق ، شما قبلاً در خبرنامه این پست عضو شده اید !!', 'expert-sms' ),
			'invalid'           => __( 'عملیات ناموفق ، شماره تلفن وارد شده نا معتبر می باشد !!', 'expert-sms' ),
			'empty_data_nopriv' => __( 'فیلد شماره تلفن همراه و نام کاربری خالی می باشد .', 'expert-sms' ),
			'empty_data'        => __( 'فیلد شماره تلفن همراه خالی می باشد .', 'expert-sms' ),
		];

		switch ( $register_error ) {

			case 'Repetitious':
				$message = $error['Repetitious'];
				wp_send_json( [
					'status_message' => false,
					'report_message' => $message
				] );
				break;
			case 'invalid':
				$message = $error['invalid'];
				wp_send_json( [
					'status_message' => false,
					'report_message' => $message
				] );
				break;
			case 'empty_data':
				if ( ! is_user_logged_in() ) {
					$message = $error['empty_data_nopriv'];
				} else {
					$message = $error['empty_data'];
				}
				wp_send_json( [
					'status_message' => false,
					'report_message' => $message
				] );
				break;
			case 'success':
				foreach ( $categories as $category ) {
					$cat_id[]   = $category->term_id;
					$cat_name[] = $category->name;
				}
				$userdata = $wpdb->insert( $wpdb->prefix . 'expert_sms_downloads', [
					'download_id'     => $download_id,
					'term_id'         => serialize( $cat_id ?? [] ),
					'term_name'       => serialize( $cat_name ?? [] ),
					'mobile'          => $mobile,
					'user_name'       => esc_html( $username ),
					'download_name'   => get_the_title( $download_id ),
					'purchase_status' => false
				], [ '%d', '%s', '%s', '%s', '%s', '%s', '%d' ] );

				if ( $userdata ) {
					$data_id = $wpdb->insert_id;
				} else {
					$data_id = $wpdb->last_error;
				}
				do_action( 'expert_sms_user_register', $username, $mobile );
				$message = __( 'درخواست شما برای عضویت در سامانه پیامکی با موفقیت ثبت شد .', 'expert-sms' );
				wp_send_json( [
					'status_message' => true,
					'report_message' => $message,
					'user_id'        => $data_id,
				] );
				break;
		}
	}
}
