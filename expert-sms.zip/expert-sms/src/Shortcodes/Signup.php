<?php


namespace ExpertSMS\Shortcodes;

use ExpertSMS\Controllers\HooksController;
use ExpertSMS\Core\Utils;

/**
 * Class Signup
 * @since   6.0.0
 *
 * @package ExpertSMS\Shortcodes
 */
class Signup extends ShortcodeSetup {

	public function __construct(HooksController $hooks) {

		parent::__construct($hooks);

		add_action( 'wp_ajax_nopriv_signup_user', [ $this, 'signup_user' ] );
	}

	/**
	 * @hooked 'wp_ajax_nopriv_signup_user'
	 *
	 * @since  6.0.0
	 */
	public function signup_user(): void {

		$full_name = ! empty( $_POST['full_name'] ) && isset( $_POST['full_name'] ) ? $_POST['full_name'] : '';
		$mobile    = ! empty( $_POST['mobile'] ) && isset( $_POST['mobile'] ) ? $_POST['mobile'] : '';

		if (
			! isset( $_POST['nonce'] )
			|| ! wp_verify_nonce( $_POST['nonce'], 'signup_user' )
		) {

			wp_send_json( [
				'status'  => false,
				'message' => __( 'دسترسی شما نا معتبر بود، لطفا دوباره وارد این صفحه شوید.', 'expert-sms' )
			] );

		} else {

			$user_inserted = wp_insert_user( [
				'user_login'   => $mobile,
				'display_name' => $full_name,
				'user_pass'    => hash( 'md5', $mobile . $full_name )
			] );

			if ( is_wp_error( $user_inserted ) ) {

				wp_send_json( [
					'status'  => false,
					'message' => $user_inserted->get_error_message(),
				] );
			}

			wp_send_json_success( [
				'message' => __( 'ثبت نام شما با موفقیت انجام شد .', 'expert-sms' ),
			] );
		}
	}

	protected function get_tag(): string {

		return 'expert_sms_signup';
	}

	public function display( array $attrs ): void {

		Utils::load_views( 'back.pages.signup', compact( 'attrs' ) );
	}

	public function id(): string {

		return 'sign-up';
	}
}