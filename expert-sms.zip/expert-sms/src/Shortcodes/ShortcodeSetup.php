<?php


namespace ExpertSMS\Shortcodes;

use ExpertSMS\Controllers\HooksController;
use ExpertSMS\Core\Utils;

/**
 * Class ShortcodeSetup
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Shortcodes
 */
abstract class ShortcodeSetup {

	protected $hooks;

	/**
	 * ShortcodeSetup constructor.
	 *
	 * @since 6.0.0
	 */
	public function __construct( HooksController $hooks = null ) {

		$this->hooks = $hooks;

		add_shortcode( $this->get_tag(), [ $this, 'register' ] );
	}

	/**
	 * Retrieve shortcode.
	 *
	 * @param array  $attrs
	 * @param string $content
	 *
	 * @since 6.0.0
	 * @return string
	 */
	public function register( $attrs, string $content = '' ): string {

		ob_start();

		if ( in_array( $this->id(), [ 'sign-in', 'sign-up' ], true ) ) {

			$attrs = shortcode_atts( [

			], $attrs, $this->get_tag() );

			$this->display( $attrs );

			$output = ob_get_clean();

			return str_replace( [ '<pre class="wp-block-preformatted">', '</pre>' ], '', $output );
		}

		$attributes = shortcode_atts(
			[
				'title'          => __( 'خبرنامه پیام کوتاه', 'expert-sms' ),
				'name'           => false,
				'description'    => __( 'برای دریافت آخرین اخبار مربوط به بروز رسانی این محصول در خبرنامه پیامکی ما عضو شوید .', 'expert-sms' ),
				'dialog_heading' => __( 'اطلاع رسان بروز رسانی های وردپرس و ووکامرس', 'expert-sms' ),
			]
			, $attrs, $this->get_tag() );

		$this->display( $attributes );

		return ob_get_clean();
	}

	/**
	 * Register user validate params data.
	 *
	 * @param $download_id
	 * @param $username
	 * @param $mobile
	 * @param $register_mobile_nonce
	 *
	 * @since 6.0.0
	 * @return string
	 */
	public function request_validation( $download_id, $username, $mobile, $register_mobile_nonce ): string {

		global $wpdb;

		$query = sprintf(
			"SELECT mobile FROM %s sd WHERE %s LIKE mobile AND %d LIKE %s_id",
			$this->get_db_name(),
			$mobile,
			$download_id,
			rtrim( $this->id(), 's' )
		);

		$status = $wpdb->get_row( $query );

		if ( $status ) {
			return 'Repetitious';
		}

		if ( empty( $username ) || empty( $mobile ) ) {

			return 'empty_data';
		}

		if ( strlen( $mobile ) < 11 || strlen( $mobile ) > 11 || ! preg_match( '/^09[0-9]{9}$/', $mobile ) ) {

			return 'invalid';
		}

		if ( ! isset( $register_mobile_nonce ) || ! wp_verify_nonce( $register_mobile_nonce, 'register_mobile' ) ) {

			wp_die( __( 'درخواست شما از منبع نامعتبر ارسال شده است لطفاً این صفحه را ترک کنید .', 'expert-sms' ) );
		}

		return 'success';
	}

	/**
	 * Retrieve shortcode tag name as string.
	 *
	 * @since 6.0.0
	 * @return string
	 */
	abstract protected function get_tag(): string;

	/**
	 * Display shortcode template.
	 *
	 * @param array $attrs
	 *
	 * @since 6.0.0
	 * @return void
	 */
	abstract public function display( array $attrs ): void;

	/**
	 * Get shortcode identifier.
	 *
	 * @since 6.0.0
	 * @return string
	 */
	abstract public function id(): string;

	/**
	 * Get DataBase name.
	 *
	 * @since 6.0.0
	 * @return string
	 */
	protected function get_db_name(): string {

		global $wpdb;

		return sprintf(
			'%ssmsnews_%s',
			$wpdb->prefix,
			$this->id()
		);
	}
}