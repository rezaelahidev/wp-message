<?php

namespace ExpertSMS\Controllers;

use ExpertSMS\Core\Singleton;

/**
 * Class AssetsController
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Controllers
 */
class AssetsController {

	use Singleton;

	/**
	 * AssetsController constructor.
	 *
	 * @since 6.0.0
	 */
	private function __construct() {

		add_action( 'wp_enqueue_scripts', [ $this, 'frontend_enqueue' ] );

		add_action( 'admin_enqueue_scripts', [ $this, 'backend_enqueue' ] );
	}

	/**
	 * Enqueue Front-End assets.
	 *
	 * @since 6.0.0
	 * @return void
	 */
	public function frontend_enqueue(): void {

		wp_register_style( 'sms-fontawesome', SMS_ASS_CSS . 'font-awesome.min.css' );
		wp_enqueue_style( 'sms-fontawesome' );
		wp_register_style( 'front-font', SMS_ASS_CSS . 'fontiran.css' );
		wp_enqueue_style( 'front-font' );
		wp_register_style( 'sms-main-css', SMS_ASS_CSS . 'expert-sms-main.css' );
		wp_enqueue_style( 'sms-main-css' );
		
		wp_register_script( 'jquery', SMS_ASS_JS . 'jquery-1.10.2.js' );

		if ( ! wp_script_is( 'jquery', 'enqueued' ) ) {
			wp_enqueue_script( 'jquery' );
		}

		wp_register_script( 'modal-main-js', SMS_ASS_JS . 'expert-sms-main.js' );
		wp_enqueue_script( 'modal-main-js' );
		wp_enqueue_script( 'ajax-js', SMS_ASS_JS . 'ajax.js' );

		// Localize data
		wp_localize_script( 'ajax-js', 'expert_sms',
			[
				'admin_url'    => admin_url( 'admin-ajax.php' ),
				'signin_page'  => home_url() . '/sign-in',
				'profile_page' => home_url() . '/my-account',
			]
		);
	}

	/**
	 * Enqueue Back-End assets.
	 *
	 * @since 6.0.0
	 * @return void
	 */
	public function backend_enqueue(): void {

		wp_register_style( 'exp-admin-css', SMS_ASS_CSS . 'expert-sms-admin.css' );
		wp_enqueue_style( 'exp-admin-css' );
		wp_register_style( 'admin-font', SMS_ASS_CSS . 'fontiran.css' );
		wp_enqueue_style( 'admin-font' );
	}
}