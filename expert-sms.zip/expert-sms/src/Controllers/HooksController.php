<?php


namespace ExpertSMS\Controllers;

use ExpertSMS\Core\Rest\RestSetup;
use ExpertSMS\Core\Singleton;
use ExpertSMS\Rest\Sender;

/**
 * Class WPController
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Controllers
 */
class HooksController {

	use Singleton;

	/**
	 * Store message content
	 *
	 * @var string $message
	 */
	protected $message;

	/**
	 * WPController constructor.
	 *
	 * @since 6.0.0
	 */
	private function __construct() {

		add_action( 'init', [ $this, 'mce_addons' ] );

		add_action( 'save_post', [ $this, 'send_sms_after_save_post' ], 1000 );

		//Post Column
		add_action( 'manage_posts_custom_column', [ $this, 'display_followers' ], 10, 2 );
		// Add Filter Posts Column
		add_filter( 'manage_posts_columns', [ $this, 'follower_column_title' ] );
		add_filter( 'manage_edit-download_columns', [ $this, 'follower_column_title' ] );
		add_filter( 'manage_edit-product_columns', [ $this, 'follower_column_title' ] );

		///Restrict manage posts
		add_action( 'restrict_manage_posts', [ $this, 'manage_posts_list' ] );
		add_filter( 'request', [ $this, 'custom_request_query' ] );

		add_action( 'admin_post_expert_sms_posts_backup', [ $this, 'posts_backup_handler' ] );

		add_action( 'admin_post_expert_sms_products_backup', [ $this, 'products_backup_handler' ] );

		add_action( 'admin_post_expert_sms_downloads_backup', [ $this, 'downloads_backup_handler' ] );

		add_filter( 'the_content', [ $this, 'remove_pre_tag' ] );
	}

	/**
	 * Init wp.
	 *
	 * @since   6.0.0
	 * @return void
	 */
	public function mce_addons(): void {

		add_filter( "mce_external_plugins", [ $this, "mce_external_buttons" ] );
		add_filter( 'mce_buttons', [ $this, 'mce_register_buttons' ] );

		//add shortcode selector to wordpress editor
		add_filter( 'mce_external_plugins', [ $this, 'register_mce_plugin' ] );
	}

	/**
	 * Retrieve mce external buttons list.
	 *
	 * @param $plugin_array
	 *
	 * @return array
	 */
	public function mce_external_buttons( $plugin_array ): array {

		$plugin_array['plugin_tmp'] = SMS_ASS_JS . 'smsnews-plugin.js';

		return $plugin_array;
	}

	/**
	 * Register buttons to mce.
	 *
	 * @param array $buttons
	 *
	 * @since 6.0.0
	 * @return array
	 */
	public function mce_register_buttons( array $buttons ): array {

		array_push( $buttons, 'simple_btn', 'showrecent', "separator", 'shortcodeSelector' );

		return $buttons;
	}

	/**
	 * add shortcode selector callback functions
	 *
	 * @param array $plugins
	 *
	 * @since 6.0.0
	 * @return array
	 */
	public function register_mce_plugin( array $plugins ): array {

		$plugins['shortcodeSelector'] = SMS_ASS_JS . 'shortcodeSelector.js';

		return $plugins;
	}

	/**
	 * Sending sms after save post.
	 *
	 * @param int $post_id
	 *
	 * @since 6.0.0
	 * @return bool
	 */
	public function send_sms_after_save_post( int $post_id ): bool {

		$this->message = sanitize_text_field( $_POST['sms_content'] ?? '' );

		if ( empty( $this->message ) ) {

			return false;
		}

		if ( 'download' === get_post_type( $post_id ) ) {

			$users = $this->get_users( 'downloads', $post_id );

		} elseif ( 'post' === get_post_type( $post_id ) ) {

			$users = $this->get_users( 'posts', $post_id );

		} elseif ( 'product' === get_post_type( $post_id ) ) {

			$users = $this->get_users( 'products', $post_id );
		}

		if ( empty( $users ) ) {

			return false;
		}

		array_map( [ $this, 'send' ], $users );

		return true;
	}

	/**
	 * @param array $user
	 *
	 * @return bool
	 */
	public function send( array $user ): bool {

		if ( ! isset( $user['mobile'], $user['user_name'] ) ) {

			return false;
		}

		$sender  = new Sender();
		$request = new \WP_REST_Request( 'POST',
			sprintf(
				'%1$s/%2$s',
				RestSetup::NAMESPACE,
				$sender->end_point()
			)
		);

		$request->set_body_params(
			[
				'user'    => $user['user_name'],
				'mobile'  => $user['mobile'],
				'message' => $this->message ?? $user['message'] ?? ''
			]
		);

		try {

			$response = $sender->handler( $request );

		} catch ( \Exception $exception ) {

			return $exception->getCode();
		}

		$data = $response->get_data();

		return $data['success'] ?? false;
	}

	/**
	 * Get users list.
	 *
	 * @param string $table
	 * @param int    $post_id
	 *
	 * @since 6.0.0
	 * @return array
	 */
	public function get_users( string $table, int $post_id ): array {

		global $wpdb;

		$query = sprintf(
			'SELECT mobile , user_name FROM %s sp WHERE sp.post_id = %d',
			$wpdb->prefix . 'smsnews_' . $table,
			$post_id
		);

		$results = $wpdb->get_results( $query, ARRAY_A );

		if ( ! $results ) {

			return [];
		}

		return $results;
	}

	/**
	 * @return string
	 */
	public function get_message(): string {
		return $this->message;
	}

	/**
	 * @param string $message
	 */
	public function set_message( string $message ): void {
		$this->message = $message;
	}

	/**
	 * @param $column
	 * @param $post_id
	 *
	 * @since 5.8.2  //Refactor method body
	 * @return bool
	 */
	public function column_html( $column, $post_id ): bool {

		global $wpdb, $post_type;

		$table = 'smsnews_posts'; // Default Value

		switch ( $post_type = get_post_type( $post_id ) ) {

			case 'post':
			case 'product':
			case 'download':

				$table = sprintf( 'smsnews_%ss', $post_type );

				break;
		}

		$query = sprintf( "
	SELECT COUNT(DISTINCT sp.mobile) as mobiles FROM {$wpdb->prefix}%s sp
	WHERE sp.%s_id=%d
	", $table, $post_type, $post_id );

		$total = $wpdb->get_results( $query );

		if ( is_null( $total ) ) {

			return false;
		}

		if ( $column === 'total_' . $post_type . '_users' ) {

			if ( ! current_user_can( 'manage_options' ) ) {

				return false;
			}

			$followers = add_query_arg( [
				'page'   => $post_type . '_users.php',
				'action' => $post_type . '_users',
				'ID'     => $post_id
			], admin_url( 'admin.php' ) );

			echo sprintf( '<a target="_blank" href="%s">%s</a>',
				esc_html( $followers ),
				( $total[0]->mobiles ?? 0 ) . 'نفر'
			);

			update_post_followers( $post_id, $total[0]->mobiles ?? 0 );
		}

		return true;
	}

	/**
	 * Manager for posts lists.
	 *
	 * @since 6.0.0
	 * @return void
	 */
	public function manage_posts_list(): void {

		global $post_type;

		if ( ! in_array( $post_type, [ 'post', 'download', 'product' ], true ) ) {

			return;
		}

		$this->restrict_manage_post_types();
	}

	/**
	 * Restrict post types manager.
	 *
	 * @since 6.0.0
	 * @return bool true on success, false on failure!
	 */
	protected function restrict_manage_post_types(): bool {

		global $wpdb, $post_type;

		$post_ids = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_type = %s", $post_type ) );

		if ( is_null( $post_ids ) ) {
			return false;
		}

		//	Add Input Text Custom Fields In Restrict .
		$query         = 'SELECT DISTINCT meta_value ';
		$query         .= "FROM $wpdb->postmeta ";
		$query         .= "WHERE meta_key = 'user_count' ";
		$query         .= 'AND post_id IN( ' . implode( ',', $post_ids ) . ') ';
		$query         .= 'ORDER BY meta_value+0 ASC ';
		$custom_fields = $wpdb->get_results( $query );

		if ( empty( $custom_fields ) ) {
			return false;
		}

		//	Add Select Box Custom Fields In Restrict .
		$range_query         = 'SELECT DISTINCT meta_value ';
		$range_query         .= "FROM $wpdb->postmeta ";
		$range_query         .= "WHERE meta_key = 'range_of_count_users' ";
		$range_query         .= 'AND post_id IN( ' . implode( ',', $post_ids ) . ') ';
		$range_custom_fields = $wpdb->get_results( $range_query );

		if ( empty( $range_custom_fields ) ) {
			return false;
		}

		?>
        <label for="filter-by-user-count" class="screen-reader-text"><?php _e( 'تعداد کاربران' ); ?></label>
        <select name="range_user_count">
            <option value=""><?php _e( 'براساس تمامی کاربران' ); ?></option>
            <option value="range_1_100"><?php echo 'بازه ی 1 تا 100'; ?></option>
            <option value="range_101_200"><?php echo 'بازه ی 101 تا 200'; ?></option>
            <option value="range_201_300"><?php echo 'بازه ی 201 تا 300'; ?></option>
            <option value="range_300_up"><?php echo 'بازه ی 300 به بالا'; ?></option>
        </select>
        <input type="text" name="meta_user_count" id="meta_user_count" placeholder="تعداد کاربران">
		<?php

		return true;
	}

	/**
	 * Retrieve custom request query vars as array!
	 *
	 * @param array $vars
	 *
	 * @since 6.0.0
	 * @return array
	 */
	public function custom_request_query( array $vars ): array {

		global $pagenow, $post_type;

		$possible_post_types = [ 'post', 'download', 'product' ];

		if ( 'edit.php' !== $pagenow || ! in_array( $post_type, $possible_post_types, true ) ) {

			return $vars;
		}

		if ( ! empty( $_GET['meta_user_count'] ) ) {
			$meta_user_count    = $_GET['meta_user_count'];
			$vars['meta_key']   = 'user_count';
			$vars['meta_value'] = $meta_user_count;
		}

		if ( ! empty( $_GET['range_user_count'] ) ) {
			$range_meta_user_count = $_GET['range_user_count'];
			$vars['meta_key']      = 'range_of_count_users';
			$vars['meta_value']    = $range_meta_user_count;
		}

		return $vars;
	}

	/**
	 * Display followers counter.
	 *
	 * @param string $column
	 * @param int    $post_id
	 *
	 * @since 5.8.2  //Refactor method body
	 * @return bool
	 */
	public function display_followers( string $column, int $post_id ): bool {

		global $wpdb, $post_type;

		$table = 'smsnews_posts'; // Default Value

		switch ( $post_type = get_post_type( $post_id ) ) {

			case 'post':
			case 'product':
			case 'download':

				$table = sprintf( 'smsnews_%ss', $post_type );

				break;
		}

		$query = sprintf( "
	SELECT COUNT(DISTINCT sp.mobile) as mobiles FROM {$wpdb->prefix}%s sp
	WHERE sp.%s_id=%d
	", $table, $post_type, $post_id );

		$total = $wpdb->get_results( $query );

		if ( is_null( $total ) ) {

			return false;
		}

		if ( sprintf( 'total_%s_users', $post_type ) === $column ) {

			if ( ! current_user_can( 'manage_options' ) ) {

				return false;
			}

			$followers = add_query_arg( [
				'page'   => $post_type . '_users.php',
				'action' => $post_type . '_users',
				'ID'     => $post_id
			], admin_url( 'admin.php' ) );

			echo sprintf( '<a href="%s">%s</a>',
				esc_html( $followers ),
				$total[0]->mobiles . 'نفر'
			);

			update_post_followers( $post_id, $total[0]->mobiles );
		}

		return true;
	}

	/**
	 * Get the followers column title.
	 *
	 * @param array $columns
	 *
	 * @since 5.8.2
	 * @return array
	 */
	public function follower_column_title( array $columns ): array {

		global $post_type;

		if ( in_array( $post_type, [ 'post', 'product', 'download' ] ) ) {

			return array_merge( $columns, [ 'total_' . $post_type . '_users' => __( 'دنبال کننده', 'expert-sms' ) ] );
		}

		return $columns;
	}

	public function posts_backup_handler(): void {

		global $wpdb;
		$data = $wpdb->get_results( "
	SELECT * FROM {$wpdb->prefix}smsnews_posts" );

		if ( is_null( $data ) ) {
			return;
		}

		$file = json_encode( $data );

		header( 'Content-Description: File Transfer' );
		header( 'Content-Type: application/json' );
		header( 'Content-Disposition: attachment; filename="' . $wpdb->prefix . 'expert_sms_posts.json"' );
		header( 'Expires: 0' );
		header( 'Cache-Control: must-revalidate' );
		header( 'Pragma: public' );
		header( 'Content-Length: ' . mb_strlen( $file ) );

		echo $file;
	}

	public function products_backup_handler(): void {

		global $wpdb;
		//	$data = $wpdb->get_results( "
		//	SELECT * FROM {$wpdb->prefix}expert_sms_products" );
		//	if ( is_null( $data ) ) {
		//		return false;
		//	}
		//	$file = json_encode( $data );
		//	header( 'Content-Description: File Transfer' );
		//	header( 'Content-Type: application/json' );
		//	header( 'Content-Disposition: attachment; filename="' . $wpdb->prefix . 'expert_sms_products.json"' );
		//	header( 'Expires: 0' );
		//	header( 'Cache-Control: must-revalidate' );
		//	header( 'Pragma: public' );
		//	header( 'Content-Length: ' . mb_strlen( $file ) );
		//	echo $file;

		//

		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=data.csv' );
		$output = fopen( "php://output", "w" );
		fputcsv( $output, array(
			'id',
			'product_id',
			'term_id',
			'mobile',
			'user_name',
			'term_name',
			'product_name',
			'purchase_status'
		) );
		$result = $wpdb->get_results( "
	SELECT * FROM {$wpdb->prefix}smsnews_products
	" );

		if ( is_null( $result ) ) {
			return;
		}

		foreach ( $result as $row => $value ) {
			fputcsv( $output, $value );
		}

		fclose( $output );
	}

	public function downloads_backup_handler(): void {

		global $wpdb;
		$data = $wpdb->get_results( "
	SELECT * FROM {$wpdb->prefix}smsnews_downloads" );

		if ( is_null( $data ) ) {
			return;
		}

		$file = json_encode( $data );
		header( 'Content-Description: File Transfer' );
		header( 'Content-Type: application/json' );
		header( 'Content-Disposition: attachment; filename="' . $wpdb->prefix . 'expert_sms_downloads.json"' );
		header( 'Expires: 0' );
		header( 'Cache-Control: must-revalidate' );
		header( 'Pragma: public' );
		header( 'Content-Length: ' . mb_strlen( $file ) );

		echo $file;
	}

	/**
	 * @hooked 'the_content'
	 *
	 * @param $content
	 *
	 * @since  5.3.0
	 * @return string|string[]
	 */
	public function remove_pre_tag( $content ) {

		return str_replace( [ '<pre>', '</pre>' ], '', $content );
	}
}