<?php


namespace ExpertSMS\Compatibility;

/**
 * Class Utils
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Compatibility
 */
class Utils {

	protected static $message_vars = [
		'username' => '%name%',
		'order'    => '%order%',
		'EOL'      => '%enter%',
		'brand'    => '%brand%',
		'factor'   => '%factor%',
	];

	/**
	 * @param array  $order_items
	 * @param int    $order_id
	 * @param string $username
	 *
	 * @since 6.0.0
	 * @return string
	 */
	public static function prepare_order_message_content( array $order_items, int $order_id, string $username ): string {

		$expert_sms_options = get_option( 'expert_sms_settings' );

		$message = apply_filters( 'expert-sms/compatibilities/order/message/content/before', '' );

		if ( ! isset( $expert_sms_options['purchase_msg'] ) ) {

			$message = str_replace(
				[
					self::$message_vars['username'],
					self::$message_vars['EOL'],
					self::$message_vars['order'],
					self::$message_vars['brand'],
				],
				[
					$username,
					PHP_EOL,
					$order_id,
					get_bloginfo( 'name' ),
				],
				$message . '%name% عزیز %enter% سفارش شما با شماره پیگیری %order% در فروشگاه %brand% با موفقیت ثبت شد.'
			);

		} else {

			foreach ( $order_items as $key => $order_item ) {

				$factor[] = sprintf(
					'محصول %s به تعداد %d با قیمت %d %s',
					$order_item['title'] ?? $order_item['name'] ?? '',
					$order_item['quantity'],
					$order_item['price'] ?? $order_item['item_price'] ?? '',
					array_key_last( $order_items ) !== $key ? 'و' : ''
				);
			}

			$message = str_replace( self::$message_vars,
				[
					$username,
					$order_id,
					PHP_EOL,
					get_bloginfo( 'name' ),
					empty( $factor ) ? '' : implode( ' ', $factor ),
				],
				sprintf( '%s%s', $message, $expert_sms_options['purchase_msg'] )
			);
		}

		return apply_filters( 'expert-sms/compatibilities/order/message/content/after', $message );
	}
}
