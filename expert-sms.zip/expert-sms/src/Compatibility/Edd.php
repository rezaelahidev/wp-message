<?php

namespace ExpertSMS\Compatibility;

use ExpertSMS\Controllers\HooksController;

/**
 * Class Edd
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Compatibility
 */
class Edd {

	protected $hooks_controller;

	public function __construct( HooksController $hooks_controller ) {

		$this->hooks_controller = $hooks_controller;

		add_action( 'edd_purchase_form_user_info_fields', [ $this, 'checkout_fields' ] );
		add_filter( 'edd_payment_meta', [ $this, 'store_custom_fields' ] );
		add_action( 'edd_payment_personal_details_list', [ $this, 'view_order_details' ], 10, 2 );
		add_action( 'edd_add_email_tags', [ $this, 'add_email_tag' ] );
		add_action( 'edd_complete_purchase', [ $this, 'complete_purchase' ] );

		add_action( 'edd_complete_download_purchase', [ $this, 'complete_item_download_complete' ], 20, 5 );
	}

	public function checkout_fields(): void {
		?>
        <p id="edd-phone-wrap">
            <label class="edd-label" for="edd-phone">شماره تلفن همراه</label>
            <span class="edd-description exp-sms-desc-field">
        	برای دریافت آخرین بروز رسانی های مربوط به محصول خریداری شده ، شماره تلفن همراهتان را وارد کرده و عضو سیستم پیام رسان ما شوید .
        </span>
            <input class="edd-input" type="text" name="edd_phone" id="edd-phone" placeholder="تلفن همراه"/>
        </p>
		<?php
	}

	public function store_custom_fields( $payment_meta ): array {
		if ( did_action( 'edd_purchase' ) ) {
			$payment_meta['phone']      = isset( $_POST['edd_phone'] ) ? sanitize_text_field( $_POST['edd_phone'] ) : '';
			$payment_meta['first_name'] = isset( $_POST['edd_first'] ) ? sanitize_text_field( $_POST['edd_first'] ) : '';
			$payment_meta['last_name']  = isset( $_POST['edd_last'] ) ? sanitize_text_field( $_POST['edd_last'] ) : '';
		}

		return $payment_meta;
	}

	public function view_order_details( $payment_meta, $user_info ): void {
		$phone = isset( $payment_meta['phone'] ) ? $payment_meta['phone'] : 'none';
		?>
        <div class="column-container">
            <div class="column">
                <strong>شماره تلفن همراه : </strong>
				<?php echo $phone; ?>
            </div>
        </div>
		<?php
	}

	public function add_email_tag(): void {

		edd_add_email_tag( 'phone', 'Customer\'s phone number', 'expert_sms_edd_email_tag_phone' );
	}

	public function complete_purchase( $payment_id ): void {

		$expert_sms_options = get_option( 'expert_sms_settings' );

		// Basic payment meta
		$payment_meta = edd_get_payment_meta( $payment_id );

		// Cart details
		$cart_items = edd_get_payment_meta_cart_details( $payment_id );

		$admin_mobile_number = isset( $expert_sms_options['admin_mobile_number'] ) ? $expert_sms_options['admin_mobile_number'] : '';

		if ( isset( $expert_sms_options['new_order_notify'] ) && $expert_sms_options['new_order_notify'] ) {

			$this->hooks_controller->set_message(
				Utils::prepare_order_message_content(
					$cart_items,
					$payment_id,
					$payment_meta['first_name']
				)
			);
			$this->hooks_controller->send(
				[
					'mobile'    => $payment_meta['phone'] ?? '',
					'user_name' => sprintf( '%s %s', $payment_meta['first_name'], $payment_meta['last_name'] ),
				]
			);

			if ( ! empty( $admin_mobile_number ) ) {

				$website_name = get_bloginfo( 'name' );
				$message      = "به اطلاع می رسانیم سفارش \n{$payment_id} توسط کاربر \n{$payment_meta['first_name']} ثبت شده است لطفا جهت پیگیری به پیشخوان مراجعه نمایید.";

				$this->hooks_controller->set_message( $message );
				$this->hooks_controller->send(
					[
						'mobile'    => $admin_mobile_number,
						'user_name' => sprintf( '%s %s', $payment_meta['first_name'], $payment_meta['last_name'] ),
					]
				);
			}
		}
	}

	public function complete_item_download_complete( $download_id, $payment_id, $download_type, $download, $cart_index ): bool {

		global $wpdb;

		$payment_meta = edd_get_payment_meta( $payment_id );
		$status       = $wpdb->get_row( $wpdb->prepare( "
    SELECT mobile FROM {$wpdb->prefix}smsnews_downloads sd
    WHERE %s LIKE mobile AND %d LIKE download_id
    ", $payment_meta['phone'], $download_id ) );
		if ( $status ) {
			return false;
		}
		if ( empty( $payment_meta['phone'] ) ) {
			return false;
		}
		if ( strlen( $payment_meta['phone'] ) < 11 || strlen( $payment_meta['phone'] ) > 11 || ! preg_match( '/^09[0-9]{9}$/', $payment_meta['phone'] ) ) {
			return false;
		}
		$categories = get_the_terms( $download_id, 'download_category' );

		if ( ! is_wp_error( $categories ) && $categories ) {
			foreach ( $categories as $category ) {
				$cat_id[]   = $category->term_id;
				$cat_name[] = $category->name;
			}
		}

		$user_purchase_dl = $wpdb->insert( $wpdb->prefix . 'smsnews_downloads', [
			'download_id'     => $download_id,
			'term_id'         => serialize( $cat_id ?? [] ),
			'term_name'       => serialize( $cat_name ?? [] ),
			'mobile'          => sanitize_text_field( $payment_meta['phone'] ),
			'user_name'       => $payment_meta['first_name'] . ' ' . $payment_meta['last_name'],
			'download_name'   => get_the_title( $download_id ),
			'purchase_status' => true
		], [ '%d', '%s', '%s', '%s', '%s', '%s', '%d' ] );

		if ( is_null( $user_purchase_dl ) ) {
			return false;
		}

		return true;
	}
}