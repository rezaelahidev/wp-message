<?php


namespace ExpertSMS\Compatibility;

use ExpertSMS\Controllers\HooksController;

/**
 * Class Woocommerce
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Compatibility
 */
class Woocommerce {

	protected $hooks_controller;

	public function __construct( HooksController $hooks_controller ) {

		$this->hooks_controller = $hooks_controller;

		add_action( 'woocommerce_checkout_create_order', [ $this, 'create_order' ], 10, 2 );
		add_action( 'woocommerce_thankyou', [ $this, 'register_new_user' ], 10, 1 );

		add_action( 'woocommerce_product_meta_end', [ $this, 'show_after_add_to_cart_form' ] );

		add_filter( 'woocommerce_billing_fields', [ $this, 'mobile_number_woocommerce_field' ] );
	}

	/**
	 * @hooked 'woocommerce_checkout_create_order'
	 *
	 * @param $order
	 * @param $data
	 *
	 * @since  5.0.0
	 */
	public function create_order( $order, $data ): void {

		if ( isset( $data['billing_mobile_number'] ) ) {
			$meta_key    = '_billing_mobile_number';
			$field_value = $data['billing_mobile_number'];
			$order->update_meta_data( $meta_key, $field_value );
		}
	}

	/**
	 * @param $order_id
	 *
	 * @since 5.0.0
	 */
	public function register_new_user( $order_id ): void {
		//mobile_field_name
		global $wpdb;

		$expert_sms_options = get_option( 'expert_sms_settings' );

		$order               = new \WC_Order( $order_id );
		$items               = $order->get_items();
		$mobile              = $order->get_meta( '_billing_mobile_number' );
		$username            = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
		$admin_mobile_number = isset( $expert_sms_options['admin_mobile_number'] ) ? $expert_sms_options['admin_mobile_number'] : '';
		$cat_id              = [];
		$cat_name            = [];

		foreach ( $items as $item_id => $item_values ) {
			$categories = get_the_terms( $item_values->get_product_id(), 'product_cat' );
			foreach ( $categories as $category ) {
				$cat_id[]   = $category->term_id;
				$cat_name[] = $category->name;
			}

			$wpdb->insert( $wpdb->prefix . 'smsnews_products', [
				'product_id'      => $item_values->get_product_id(),
				'term_id'         => serialize( $cat_id ),
				'mobile'          => $mobile,
				'user_name'       => esc_html( $username ),
				'term_name'       => serialize( $cat_name ),
				'product_name'    => get_the_title( $item_values->get_product_id() ),
				'purchase_status' => true
			], [ '%d', '%s', '%s', '%s', '%s', '%s', '%d' ] );

			$order_items[] = [
				'title'    => wc_get_product( $item_values->get_product_id() )->get_title(),
				'quantity' => $item_values->get_quantity(),
				'price'    => $item_values->get_subtotal(),// Line subtotal (non discounted)
			];
		}


		if ( isset( $expert_sms_options['new_order_notify'] ) && $expert_sms_options['new_order_notify'] ) {

			$this->hooks_controller->set_message(
				Utils::prepare_order_message_content(
					$order_items ?? [],
					$order_id,
					$username
				)
			);
			$this->hooks_controller->send(
				[
					'mobile'    => $mobile,
					'user_name' => $username
				]
			);

			if ( ! empty( $admin_mobile_number ) ) {

				$website_name  = get_bloginfo( 'name' );
				$product_title = get_the_title( $item_values->get_product_id() );
				$message       = "به اطلاع می رسانیم محصول \n{$product_title} توسط کاربر \n{$username} خریداری شده است لطفاً برای پیگیری سفارش به پیشخوان \n{$website_name} مراجعه نمایید .";

				$this->hooks_controller->set_message( $message );
				$this->hooks_controller->send( [ $admin_mobile_number, $username ] );
			}
		}
	}

	public function show_after_add_to_cart_form(): void {

		global $expert_sms_options;

		$title = isset( $expert_sms_options['title'] ) ? $expert_sms_options['title'] : '';

		$description = isset( $expert_sms_options['desc'] ) ? $expert_sms_options['desc'] : '';

		echo do_shortcode( '[smsNewslettersProduct title="' . $title . '" name="true" description="' . $description . '"]' );
	}

	/**
	 * @hooked 'woocommerce_billing_fields'
	 *
	 * @param array $fields
	 *
	 * @since  6.0.0
	 * @return array
	 */
	public function mobile_number_woocommerce_field( array $fields ): array {

		$fields['billing_mobile_number'] = [
			'label'       => __( 'شماره همراه' ),
			'placeholder' => _x( '0912-000-00-00', 'placeholder', 'woocommerce' ), // Add custom field placeholder
			'required'    => true, // if field is required or not
			'clear'       => false, // add clear or not
			'type'        => 'text', // add field type
			'class'       => [ '' ]    // add class name
		];

		return $fields;
	}
}
