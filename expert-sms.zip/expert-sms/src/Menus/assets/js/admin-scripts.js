jQuery(document).ready(function ($) {
    $('.section-post').on('click', function () {
        $('.danger').hide();
        $('.success').hide();
        var selectedSection = $('#sections option:selected').text();
        $.post(AdminL10n['admin_ajax'] || '',
            {action: 'getCategoryFollowers', section: selectedSection, table: 'post'},
            function (data) {
                $('.select-section').replaceWith(data);
                $('.group-send').css({"display": "block"});
            });
    });
    $('.section-product').on('click', function () {
        $('.danger').hide();
        $('.success').hide();
        var selectedSection = $('#sections option:selected').text();
        $.post(AdminL10n['admin_ajax'] || '', {
            action: 'getProductCategoryFollowers',
            section: selectedSection,
            table: 'product'
        }, function (data) {
            $('.select-section').replaceWith(data);
            $('.group-send').css({"display": "block"});
        });
    });
    $('.section-download').on('click', function () {
        $('.danger').hide();
        $('.success').hide();
        var selectedSection = $('#sections option:selected').text();
        $.post(AdminL10n['admin_ajax'] || '', {
            action: 'getDownloadCategoryFollowers',
            section: selectedSection,
            table: 'download'
        }, function (data) {
            $('.select-section').replaceWith(data);
            $('.group-send').css({"display": "block"});
        });
    });
    $('#post_cat_sms').on('click', function (event) {
        event.preventDefault();
        var _this = $(this);
        var mobile = new Array();
        $("#contact:checked").each(function () {
            mobile.push($(this).val());
        })
        var user_name = new Array();
        $("#contact:checked").each(function () {
            user_name.push($(this).data('username'));
        });
        var message = $('.sms-content').val();
        $.ajax({
            url: AdminL10n['admin_ajax'] || '',
            type: 'post',
            dataType: 'json',
            data: {
                action: 'send_cat_sms_post',
                message: message,
                user_name: user_name,
                mobile: mobile
            },
            beforeSend: function () {
                $('#loadFacebookG').show();
                $('.danger').css({"display": "none"});
                $('.success').css({"display": "none"});
            },
            success: function (response) {
                if (response.success) {
                    $('.success').text(response.message);
                    $('.success').css({"display": "block"});
                } else {
                    $('.danger').text(response.message);
                    $('.danger').css({"display": "block"});
                }
                $('#loadFacebookG').hide();
            },
            error: function (response) {

            }
        });
    });


    $('#search_post_users').on('click', function (event) {
        event.preventDefault();
        var _this = $(this);
        var type = $('#type').val();
        var search_content = $('#search_content').val();
        $.ajax({
            url: AdminL10n['admin_ajax'] || '',
            type: 'post',
            dataType: 'json',
            data: {
                action: 'search_post_users',
                search_content: search_content,
                type: type
            },
            beforeSend: function () {
                $('#loadFacebookG').show();
            },
            success: function (response) {
                if (response.success) {
                    $('.widefat').replaceWith(response.render_users);

                } else {
                    $('.widefat').replaceWith(response.render_users);
                }
                $('#loadFacebookG').hide();
            },
            error: function (response) {

            }
        });
    });
    $('#search_download_users').on('click', function (event) {
        event.preventDefault();
        var _this = $(this);
        var type = $('#type').val();
        var search_content = $('#search_content').val();
        $.ajax({
            url: AdminL10n['admin_ajax'] || '',
            type: 'post',
            dataType: 'json',
            data: {
                action: 'search_download_users',
                search_content: search_content,
                type: type
            },
            beforeSend: function () {
                $('#loadFacebookG').show();
            },
            success: function (response) {
                if (response.success) {
                    $('.widefat').replaceWith(response.render_users);

                } else {
                    $('.widefat').replaceWith(response.render_users);
                }
                $('#loadFacebookG').hide();
            },
            error: function (response) {

            }
        });
    });
    $('#search_product_users').on('click', function (event) {
        event.preventDefault();
        var _this = $(this);
        var type = $('#type').val();
        var search_content = $('#search_content').val();
        $.ajax({
            url: AdminL10n['admin_ajax'] || '',
            type: 'post',
            dataType: 'json',
            data: {
                action: 'search_product_users',
                search_content: search_content,
                type: type
            },
            beforeSend: function () {
                $('#loadFacebookG').show();
            },
            success: function (response) {
                if (response.success) {
                    $('.widefat').replaceWith(response.render_users);

                } else {
                    $('.widefat').replaceWith(response.render_users);
                }
                $('#loadFacebookG').hide();
            },
            error: function (response) {

            }
        });
    });
    $('#search_digits_users').on('click', function (event) {
        event.preventDefault();
        var _this = $(this);
        var type = $('#type').val();
        var search_content = $('#search_content').val();
        $.ajax({
            url: AdminL10n['admin_ajax'] || '',
            type: 'post',
            dataType: 'json',
            data: {
                action: 'search_digits_users',
                search_content: search_content,
                type: type
            },
            beforeSend: function () {
                $('#loadFacebookG').show();
            },
            success: function (response) {
                if (response.success) {
                    $('.widefat').replaceWith(response.render_users);

                } else {
                    $('.widefat').replaceWith(response.render_users);
                }
                $('#loadFacebookG').hide();
            },
            error: function (response) {

            }
        });
    });
    $('#search_by_col_users').on('click', function (event) {
        event.preventDefault();
        var _this = $(this);
        var type = $('#type').val();
        var search_content = $('#search_content').val();
        var post_id = _this.data('pid');
        $.ajax({
            url: AdminL10n['admin_ajax'] || '',
            type: 'post',
            dataType: 'json',
            data: {
                action: 'search_by_col_users',
                search_content: search_content,
                type: type,
                post_id: post_id
            },
            beforeSend: function () {
                $('#loadFacebookG').show();
            },
            success: function (response) {
                if (response.success) {
                    $('.widefat').replaceWith(response.render_users);

                } else {
                    $('.widefat').replaceWith(response.render_users);
                }
                $('#loadFacebookG').hide();
            },
            error: function (response) {

            }
        });
    });
    $('#search_by_col_dl_users').on('click', function (event) {
        event.preventDefault();
        var _this = $(this);
        var type = $('#type').val();
        var search_content = $('#search_content').val();
        var download_id = _this.data('dlid');
        $.ajax({
            url: AdminL10n['admin_ajax'] || '',
            type: 'post',
            dataType: 'json',
            data: {
                action: 'search_by_col_dl_users',
                search_content: search_content,
                type: type,
                download_id: download_id
            },
            beforeSend: function () {
                $('#loadFacebookG').show();
            },
            success: function (response) {
                if (response.success) {
                    $('.widefat').replaceWith(response.render_users);

                } else {
                    $('.widefat').replaceWith(response.render_users);
                }
                $('#loadFacebookG').hide();
            },
            error: function (response) {

            }
        });
    });
    $('#search_by_col_product_users').on('click', function (event) {
        event.preventDefault();
        var _this = $(this);
        var type = $('#type').val();
        var search_content = $('#search_content').val();
        var product_id = _this.data('product_id');
        $.ajax({
            url: AdminL10n['admin_ajax'] || '',
            type: 'post',
            dataType: 'json',
            data: {
                action: 'search_by_col_product_users',
                search_content: search_content,
                type: type,
                product_id: product_id
            },
            beforeSend: function () {
                $('#loadFacebookG').show();
            },
            success: function (response) {
                if (response.success) {
                    $('.widefat').replaceWith(response.render_users);

                } else {
                    $('.widefat').replaceWith(response.render_users);
                }
                $('#loadFacebookG').hide();
            },
            error: function (response) {

            }
        });
    });
    $('.group-send-posts').on('click', function (event) {
        event.preventDefault();
        var _this = $(this);
        var mobile = new Array();
        $("#contact:checked").each(function () {
            mobile.push($(this).val());
        })
        var user_name = new Array();
        $("#contact:checked").each(function () {
            user_name.push($(this).data('username'));
        });
        var message = $('.sms-content').val();
        var send_all = $('#send_all:checked').data('send_all');
        var post_type = $('#send_all').data('post_type');
        $.ajax({
            url: AdminL10n['admin_ajax'] || '',
            type: 'post',
            dataType: 'json',
            data: {
                action: 'send_from_campaigns',
                message: message,
                user_name: user_name,
                mobile: mobile,
                send_all: send_all,
                post_type: post_type
            },
            beforeSend: function () {
                $('#loadFacebookG').show();
                $('.danger').css({"display": "none"});
                $('success').css({"display": "none"});
            },
            success: function (response) {
                if (response.success) {
                    $('.success').text(response.message);
                    $('.success').css({"display": "block"});

                    var mobileRows = document.querySelectorAll('.user-rows .expert-sms-mobile');

                    for (var data in response.statuses) {

                        mobileRows && mobileRows.forEach(function (mobileRow) {

                            var senderResult = mobileRow.parentElement.querySelector('.expert-sms-sender-result');
                            var mobileNumber = mobileRow.getAttribute('data-mobile');

                            if (mobileNumber !== data) {

                                return;
                            }

                            if (!response.statuses || !response.statuses[data] || !response.statuses[data].success) {

                                senderResult.outerHTML = '<span class="expert-sms-fail-badge">ارسال نشد!</span>';

                                mobileRow.parentElement.style.backgroundColor = '#ff000029';

                                return;
                            }

                            senderResult.outerHTML = '<span class="expert-sms-success-badge">ارسال شد.</span>';
                            mobileRow.parentElement.style.backgroundColor = '#00ff0026';
                        });
                    }

                } else {
                    $('.danger').text(response.message);
                    $('.danger').css({"display": "block"});
                }

                $('#loadFacebookG').hide();
            },
            error: function (response) {

            }
        });
    });
});