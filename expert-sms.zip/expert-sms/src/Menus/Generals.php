<?php


namespace ExpertSMS\Menus;

use ExpertSMS\Controllers\HooksController;
use ExpertSMS\Core\Utils;

/**
 * Class PostMenu
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Menus
 */
class Generals extends PanelSetup {

	public function __construct( HooksController $hooks_controller ) {

		parent::__construct( $hooks_controller );

		foreach ( [ 'postsExporter', 'productsExporter', 'downloadsExporter', 'digitsExporter' ] as $action ) {

			add_action( "admin_post_{$action}", [ $this, $action ] );
		}
	}

	public function register(): void {

		add_submenu_page(
			'post_users.php',
			__( 'تنظیمات', 'expert-sms' ),
			__( 'تنظیمات', 'expert-sms' ),
			'manage_options',
			'sms_settings.php',
			[ $this, 'settings_page' ]
		);
		add_submenu_page(
			'post_users.php',
			__( 'خروجی', 'expert-sms' ),
			__( 'خروجی', 'expert-sms' ),
			'manage_options',
			'export_data.php',
			[ $this, 'get_export_menu' ]
		);
	}

	public function get_export_menu(): void {

		Utils::load_views( 'back.export.index' );
	}

	public function postsExporter(): void {

		$format      = isset( $_POST['format'] ) && ! empty( $_POST['format'] ) ? $_POST['format'] : null;
		$exportClass = sprintf( '\ExpertSMS\Exporter\%sExporter', $format );

		if ( ! class_exists( $exportClass ) ) {

			return;
		}

		$export_object = new $exportClass();
		$export_object->export( 'postsExporter' );
		exit();
	}

	public function productsExporter(): void {

		$format      = isset( $_POST['format'] ) && ! empty( $_POST['format'] ) ? $_POST['format'] : null;
		$exportClass = sprintf( '\ExpertSMS\Exporter\%sExporter', $format );

		if ( ! class_exists( $exportClass ) ) {

			return;
		}

		$export_object = new $exportClass;
		$export_object->export( 'productsExporter' );
		exit();
	}

	public function downloadsExporter(): void {

		$format      = isset( $_POST['format'] ) && ! empty( $_POST['format'] ) ? $_POST['format'] : null;
		$exportClass = sprintf( '\ExpertSMS\Exporter\%sExporter', $format );

		if ( ! class_exists( $exportClass ) ) {

			return;
		}

		$export_object = new $exportClass;
		$export_object->export( 'downloadsExporter' );
		exit();
	}

	public function digitsExporter(): void {

		$format      = isset( $_POST['format'] ) && ! empty( $_POST['format'] ) ? $_POST['format'] : null;
		$exportClass = sprintf( '\ExpertSMS\Exporter\%sExporter', $format );

		if ( ! class_exists( $exportClass ) ) {

			return;
		}

		$export_object = new $exportClass;
		$export_object->export( 'digitsExporter' );
		exit();
	}

	public function settings_page(): void {

		$tabs        = [
			'general'     => 'همگانی',
			'webservice'  => 'وب سرویس',
			'woocommerce' => 'ووکامرس',
		];
		$colors      = [
			'newsletter-btn-red'     => 'قرمز',
			'newsletter-btn-blue'    => 'آبی',
			'newsletter-btn-purple'  => 'بنفش',
			'newsletter-btn-crimson' => 'زرشکی',
			'newsletter-btn-green'   => 'سبز',
			'newsletter-btn-black'   => 'مشکی'
		];
		$webservices = [
			'faraz'            => 'فراز اس ام اس',
			'farapayamak'      => 'فراپیامک',
			'smsir'            => 'پیامک سفید sms.ir',
			'melipayamak'      => 'ملی پیامک',
			'cando'            => 'کندو',
			'sunway'           => 'سان وی',
			'newsmsir'         => 'newsms.ir',
			'sibsmspanel'      => 'سیب اس ام اس پنل (sibsmspanel.ir)',
			'shahvarpayam'     => 'شاهوار پیام(sms.shahvarpayam.ir)',
			'modirpayamak.com' => 'مدیر پیامک(modirpayamak.com)',
			'ippanel.com'      => 'آی پی پنل(ippanel.com)',
			'sms.zhiak.com'    => 'ژیاک(sms.zhiak.com)',
			'sms.rangine.ir'   => 'رنگینه(sms.rangine.ir)',
			'payamnam'         => 'payamnam.ir',
			'mediana'          => 'سامانه مدیانا',
			'relax'            => 'ریلکس',
			'raygansms'        => 'رایگان اس ام اس',
			'payam-resan'      => 'پیام رسان',
			'niazpardaz'       => 'نیاز پرداز',
		];

		switch ( true ) {

			case isset( $_GET['tab'] ) && $_GET['tab'] === 'woocommerce':

				$data = [
					'purchase_msg'       => isset( $_POST['purchase_message'] ) && ! empty( $_POST['purchase_message'] ) ? $_POST['purchase_message'] : 'کاربر گرامی شماره همراه شما در سامانه پیامکی ثبت شد و از این پس بروز رسانی های مربوط به محصول خریداری شده برای شما ارسال خواهد شد با تشکر از خرید شما .',
					'active_newsletters' => isset( $_POST['active_newsletters'] ) && ! empty( $_POST['active_newsletters'] ) ? $_POST['active_newsletters'] : 'deactive',
					'new_order_notify'   => isset( $_POST['new_order_notify'] ) && ! empty( $_POST['new_order_notify'] ) ? $_POST['new_order_notify'] : false,
					'stock_quantity'     => isset( $_POST['stock_quantity'] ) && ! empty( $_POST['stock_quantity'] ) ? $_POST['stock_quantity'] : false,
				];

				if ( ! empty( $_POST ) ) {

					$this->save( $_POST, $data );
				}

				Utils::load_views( 'back.settings.woocommerce', compact( 'colors', 'webservices', 'tabs' ) );

				break;

			case isset( $_GET['tab'] ) && $_GET['tab'] === 'webservice':

				$data = [
					'webservice_username' => isset( $_POST['webservice_username'] ) && ! empty( $_POST['webservice_username'] ) ? $_POST['webservice_username'] : null,
					'webservice_password' => isset( $_POST['webservice_password'] ) && ! empty( $_POST['webservice_password'] ) ? $_POST['webservice_password'] : null,
					'webservice_number'   => isset( $_POST['webservice_number'] ) && ! empty( $_POST['webservice_number'] ) ? $_POST['webservice_number'] : null,
					'api_key'             => isset( $_POST['API_KEY'] ) && ! empty( $_POST['API_KEY'] ) ? $_POST['API_KEY'] : null,
					'secret_key'          => isset( $_POST['secret_key'] ) && ! empty( $_POST['secret_key'] ) ? $_POST['secret_key'] : null,
					'webservice'          => isset( $_POST['webservice'] ) && ! empty( $_POST['webservice'] ) ? $_POST['webservice'] : 'melipayamak',
					'code_pattern'        => isset( $_POST['code_pattern'] ) && ! empty( $_POST['code_pattern'] ) ? $_POST['code_pattern'] : '',
					'pattern'             => isset( $_POST['pattern'] ) && ! empty( $_POST['pattern'] ) ? $_POST['pattern'] : '',
				];

				if ( ! empty( $_POST ) ) {

					$this->save( $_POST, $data );
				}

				Utils::load_views( 'back.settings.webservice', compact( 'colors', 'webservices', 'tabs' ) );

				break;

			default:

				$data = [
					'title'               => isset( $_POST['title'] ) && ! empty( $_POST['title'] ) ? $_POST['title'] : null,
					'popup_title'         => isset( $_POST['popup_title'] ) && ! empty( $_POST['popup_title'] ) ? $_POST['popup_title'] : null,
					'desc'                => isset( $_POST['desc'] ) && ! empty( $_POST['desc'] ) ? $_POST['desc'] : null,
					'theme'               => isset( $_POST['theme'] ) && ! empty( $_POST['theme'] ) ? $_POST['theme'] : '.newsletter-btn-purple',
					'admin_mobile_number' => isset( $_POST['admin_mobile_number'] ) && ! empty( $_POST['admin_mobile_number'] ) ? $_POST['admin_mobile_number'] : '',
					'users_per_page'      => isset( $_POST['users_per_page'] ) && ! empty( $_POST['users_per_page'] ) ? $_POST['users_per_page'] : 1,
				];

				if ( ! empty( $_POST ) ) {

					$this->save( $_POST, $data );
				}

				Utils::load_views( 'back.settings.general', compact( 'colors', 'webservices', 'tabs' ) );

				break;
		}
	}

	/**
	 * @param $post
	 * @param $data
	 *
	 * @since 5.7.0
	 * @return bool
	 */
	protected function save( $post, $data ): bool {

		$old_settings = (array) get_option( 'expert_sms_settings' );

		if ( ! isset( $post['save_settings'] ) ) {

			return false;
		}

		if ( ! isset( $post['save_setting_nonce'] )
		     || ! wp_verify_nonce( $post['save_setting_nonce'], 'save_setting_action' )
		) {
			wp_die( 'سطح دسترسی غیرمجار ، لطفاً این صفحه را ترک کنید .' );
		}

		$settings = array_merge( $old_settings, $data );

		update_option( 'expert_sms_settings', $settings );

		return true;
	}

	protected function priority(): int {

		return 50;
	}

	protected function id(): string {

		return 'general';
	}

	public function follower_post_sending_template(): void {

		global $wpdb;

		$expert_sms_options = get_option( 'expert_sms_settings' );

		$post_id      = $_GET['ID'] ?? null;
		$pagenum      = isset( $_GET['pagenum'] ) ? absint( $_GET['pagenum'] ) : 1;
		$limit        = $expert_sms_options['users_per_page'] ?? 1; // number of rows in page
		$offset       = ( $pagenum - 1 ) * $limit;
		$total        = $wpdb->get_var( "SELECT COUNT(DISTINCT mobile) FROM {$wpdb->prefix}smsnews_posts" );
		$num_of_pages = ceil( $total / $limit );
		$post_data    = $wpdb->get_results( $wpdb->prepare( "
	SELECT sp.id,sp.post_id,sp.post_name,sp.user_name,sp.mobile FROM
	{$wpdb->prefix}smsnews_posts as sp 
	WHERE sp.post_id = %d 
	GROUP BY sp.mobile
	ORDER BY id DESC
	LIMIT %d , %d 
	 ", $post_id, $offset, $limit ) );

		if ( is_null( $post_data ) ) {
			return;
		}

		$action = isset( $_GET['action'] ) && ! empty( $_GET['action'] ) ? $_GET['action'] : null;

		if ( 'user_edit' === $action ) {
			$action_callback = $_GET['action'] . '_handler';
			if ( function_exists( $action_callback ) ) {
				$action_callback();

				return;
			}
		}
		if ( 'user_delete' === $action ) {
			$action_callback = $_GET['action'] . '_handler';
			if ( function_exists( $action_callback ) ) {
				$action_callback();

				return;
			}
		}

		if ( 'send_sms' === $action ) {
			$action_callback = sprintf( 'expert_sms_%s_handler', $_GET['action'] );
			if ( function_exists( $action_callback ) ) {
				$action_callback( $this->hooks_controller );

				return;
			}
		}

		\ExpertSMS\Core\Utils::load_views( 'back.custom-column.post', compact( 'post_data', 'post_id', 'num_of_pages', 'pagenum' ) );
	}

	public function follower_download_sending_template(): void {

		global $wpdb, $expert_sms_options;
		$download_id  = $_GET['ID'] ?? null;
		$pagenum      = isset( $_GET['pagenum'] ) ? absint( $_GET['pagenum'] ) : 1;
		$limit        = $expert_sms_options['users_per_page'] ?? 1; // number of rows in page
		$offset       = ( $pagenum - 1 ) * $limit;
		$total        = $wpdb->get_var( "SELECT COUNT(DISTINCT mobile) FROM {$wpdb->prefix}smsnews_downloads" );
		$num_of_pages = ceil( $total / $limit );
		$data         = $wpdb->get_results( $wpdb->prepare( "
	SELECT * FROM {$wpdb->prefix}smsnews_downloads sd 
	WHERE download_id = %d
	GROUP BY sd.mobile
	ORDER BY id DESC 
	LIMIT %d , %d
	", $download_id, $offset, $limit ) );
		$action       = isset( $_GET['action'] ) && ! empty( $_GET['action'] ) ? $_GET['action'] : null;

		if ( $action == 'user_edit_dl' ) {
			$action_callback = $_GET['action'] . '_handler';
			if ( function_exists( $action_callback ) ) {
				$action_callback();

				return;
			}
		}
		if ( $action == 'user_delete_dl' ) {
			$action_callback = $_GET['action'] . '_handler';
			if ( function_exists( $action_callback ) ) {
				$action_callback();

				return;
			}
		}

		if ( $action == 'send_sms_dl' ) {
			$action_callback = $_GET['action'] . '_handler';
			if ( function_exists( $action_callback ) ) {
				$action_callback();

				return;
			}
		}

		\ExpertSMS\Core\Utils::load_views( 'back.custom-column.download', compact( 'data', 'download_id', 'pagenum', 'num_of_pages' ) );
	}

	public function follower_product_sending_template(): void {

		global $wpdb, $expert_sms_options;
		$product_id   = $_GET['ID'] ?? null;
		$pagenum      = isset( $_GET['pagenum'] ) ? absint( $_GET['pagenum'] ) : 1;
		$limit        = $expert_sms_options['users_per_page'] ?? 1; // number of rows in page
		$offset       = ( $pagenum - 1 ) * $limit;
		$total        = $wpdb->get_var( "SELECT COUNT(DISTINCT mobile) FROM {$wpdb->prefix}smsnews_products" );
		$num_of_pages = ceil( $total / $limit );
		$data         = $wpdb->get_results( $wpdb->prepare( "
	SELECT * FROM {$wpdb->prefix}smsnews_products sp 
	WHERE product_id = %d
	GROUP BY sp.mobile
	ORDER BY id DESC 
	LIMIT %d,%d
	", $product_id, $offset, $limit ) );
		$action       = isset( $_GET['action'] ) && ! empty( $_GET['action'] ) ? $_GET['action'] : null;

		if ( $action == 'user_edit_product' ) {
			$action_callback = $_GET['action'] . '_handler';
			if ( function_exists( $action_callback ) ) {
				$action_callback();

				return;
			}
		}
		if ( $action == 'user_delete_product' ) {
			$action_callback = $_GET['action'] . '_handler';
			if ( function_exists( $action_callback ) ) {
				$action_callback();

				return;
			}
		}

		if ( $action == 'send_sms_product' ) {
			$action_callback = $_GET['action'] . '_handler';
			if ( function_exists( $action_callback ) ) {
				$action_callback();

				return;
			}
		}

		\ExpertSMS\Core\Utils::load_views( 'back.custom-column.product', compact( 'data', 'product_id', 'pagenum', 'num_of_pages' ) );
	}
}