<?php

if ( ! function_exists( 'expert_sms_user_edit_handler' ) ) {

	function expert_sms_user_edit_handler( \ExpertSMS\Controllers\HooksController $hooks, string $page ): bool {

		global $wpdb;

		$page = expert_sms_get_page_type( $page );

		if ( ! in_array( $page, [ 'post', 'download', 'product', 'digits' ], true ) ) {

			return false;
		}

		$data = $wpdb->get_results( sprintf( "
	SELECT * FROM {$wpdb->prefix}smsnews_%ss sp 
	WHERE sp.id=%d
	", $page, $_GET['id'] ) );

		if ( is_null( $data ) ) {
			return false;
		}

		if ( isset( $_POST['edit_user'] ) ) {
			if (
				! isset( $_POST['edit_user_nonce'] )
				|| ! wp_verify_nonce( $_POST['edit_user_nonce'], 'edit_user' )
			) {
				wp_die( 'درخواست شما نامعتبر می باشد ، لطفاً این صفحه را ترک کنید .' );
			}
			$wpdb->update( $wpdb->prefix . 'smsnews_posts', [
				'user_name' => isset( $_POST['name'] ) && ! empty( $_POST['name'] ) ? sanitize_user( $_POST['name'] ) : null,
				'mobile'    => isset( $_POST['mobile'] ) && ! empty( $_POST['mobile'] ) ? sanitize_text_field( $_POST['mobile'] ) : null
			], [ 'id' => $_GET['id'] ], [ '%s', '%s' ], [ '%d' ] );
			echo $wpdb->last_error;
		}

		\ExpertSMS\Core\Utils::load_views( 'back.options.edit', [ 'data' => $data, '_GET', $_GET ] );

		return true;
	}
}

if ( ! function_exists( 'expert_sms_user_delete_handler' ) ) {

	function expert_sms_user_delete_handler( \ExpertSMS\Controllers\HooksController $hooks, string $page ) {

		global $wpdb;

		$page = expert_sms_get_page_type( $page );

		if ( ! in_array( $page, [ 'post', 'download', 'product', 'digits' ], true ) ) {

			return;
		}

		$wpdb->delete( $wpdb->prefix . 'smsnews_' . $page . 's', [
			'id' => $_GET['id']
		], [ '%d' ] );
		\ExpertSMS\Core\Utils::load_views( 'back.options.delete' );
	}
}

if ( ! function_exists( 'expert_sms_send_sms_handler' ) ) {

	/**
	 * @param \ExpertSMS\Controllers\HooksController $hooks
	 * @param string                                 $page
	 *
	 * @since 6.0.0
	 * @return array
	 */
	function expert_sms_send_sms_handler( \ExpertSMS\Controllers\HooksController $hooks, string $page ): array {

		global $wpdb;

		$page = expert_sms_get_page_type( $page );

		if ( ! in_array( $page, [ 'post', 'download', 'product', 'digits' ], true ) ) {

			return [];
		}

		$data = $wpdb->get_results( sprintf( "
	SELECT * FROM {$wpdb->prefix}smsnews_%ss sp 
	WHERE sp.id=%d
	", $page, $_GET['id'] ) );

		if ( is_null( $data ) ) {
			return [];
		}

		$statuses = [];

		if ( isset( $_POST['send'] ) ) {

			$content = isset( $_POST['content'] ) && ! empty( $_POST['content'] ) ? sanitize_text_field( $_POST['content'] ) : null;

			if ( empty( $content ) ) {
				echo '<div class="danger">' . 'امکان ارسال پیامک خالی وجود ندارد !' . '</div>';
			}

			foreach ( $data as $item ) {

				if ( ! isset( $item->mobile ) ) {

					continue;
				}

				$statuses[ $item->mobile ] = $hooks->send(
					[
						'message'   => $content,
						'mobile'    => $item->mobile,
						'user_name' => $item->user_name,
					]
				);
			}
		}

		if ( ! empty( $statuses ) && ! in_array( true, $statuses, true ) ) {

			echo '<div class="danger">' . 'ارسال پیام ناموفق !' . '</div>';
		}

		\ExpertSMS\Core\Utils::load_views( 'back.options.send-sms', compact( 'data' ) );

		return $statuses;
	}
}

if ( ! function_exists( 'expert_sms_get_page_type' ) ) {

	/**
	 * @param string $page
	 *
	 * @since 6.0.0
	 * @return string
	 */
	function expert_sms_get_page_type( string $page ): string {

		return (string) str_replace( [ '-users.php', '_users.php' ], '', $page );
	}
}

function expert_sms_user_edit_digits_handler() {

	global $wpdb;
	$data = $wpdb->get_results( $wpdb->prepare( "
	SELECT meta_value,user_id FROM $wpdb->usermeta 
	WHERE meta_key=%s AND user_id=%d
	", 'billing_phone', $_GET['id'] ) );

	if ( is_null( $data ) ) {
		return false;
	}

	if ( isset( $_POST['edit_user'] ) ) {
		if (
			! isset( $_POST['edit_user_nonce'] )
			|| ! wp_verify_nonce( $_POST['edit_user_nonce'], 'edit_user' )
		) {
			wp_die( 'درخواست شما نامعتبر می باشد ، لطفاً این صفحه را ترک کنید .' );
		}
		$wpdb->update( $wpdb->usermeta, [
			'meta_value' => isset( $_POST['mobile'] ) && ! empty( $_POST['mobile'] ) ? sanitize_text_field( $_POST['mobile'] ) : null
		],
			[
				'user_id'  => $_GET['id'],
				'meta_key' => 'billing_phone',
			],
			[ '%s' ], [ '%d', '%s' ] );
		echo $wpdb->last_error;
	}

	\ExpertSMS\Core\Utils::load_views( 'back.options.edit', compact( 'data' ) );

	return true;
}

function expert_sms_user_delete_digits_handler() {

	global $wpdb;
	$wpdb->delete( $wpdb->usermeta, [
		'user_id' => $_GET['id'],
	], [ '%d' ] );

	\ExpertSMS\Core\Utils::load_views( 'back.options.delete' );
}

function expert_sms_send_sms_digits_handler() {

	global $wpdb;
	$data = $wpdb->get_results( $wpdb->prepare( "
	SELECT meta_value , user_id FROM $wpdb->usermeta 
	WHERE meta_key=%s AND user_id=%d
	", 'billing_phone', $_GET['id'] ) );
	if ( is_null( $data ) ) {
		return false;
	}

	if ( isset( $_POST['send'] ) ) {
		$content = isset( $_POST['content'] ) && ! empty( $_POST['content'] ) ? sanitize_text_field( $_POST['content'] ) : null;

		foreach ( $data as $item ) {
			$stat = expert_sms_send_sms_simple( $item->meta_value, get_user_by( 'ID', $item->user_id )->display_name, $content );
		}
		if ( ! $stat ) {
			echo '<div class="danger">' . 'امکان ارسال پیامک خالی وجود ندارد !! .' . '</div>';
		}

	}

	\ExpertSMS\Core\Utils::load_views( 'back.options.send-sms', compact( 'data' ) );
}