<?php


namespace ExpertSMS\Menus;

use ExpertSMS\Controllers\HooksController;
use ExpertSMS\Core\Utils;

/**
 * Class PanelUtils
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Menus
 */
class PanelUtils {

	/**
	 * Get table rows count with distinct mobile field.
	 *
	 * @param string $table
	 *
	 * @since 6.0.0
	 * @return int
	 */
	public static function get_table_count( string $table ): int {

		global $wpdb;

		$table_prefix = 'smsnews_';
		$query        = sprintf( 'SELECT COUNT(DISTINCT mobile) FROM `%s`', $wpdb->prefix . $table_prefix . $table );

		$var = $wpdb->get_var( $query );

		return (int) ( $var ?? 0 );
	}

	/**
	 * Get table rows grouped by mobile field and order by identifier field.
	 *
	 * @param string $table
	 * @param int    $offset
	 * @param int    $limit
	 *
	 * @since 6.0.0
	 * @return object|stdClass|\stdClass[]
	 */
	public static function get_table_rows( string $table, int $offset, int $limit ) {

		global $wpdb;

		$table_prefix = 'smsnews_';
		$query        = sprintf(
			'SELECT * FROM `%s` as sp	GROUP BY mobile	ORDER BY id DESC LIMIT %d , %d',
			$wpdb->prefix . $table_prefix . $table,
			$offset,
			$limit
		);

		$results = $wpdb->get_results( $query );

		if ( ! $results ) {

			return new \stdClass();
		}

		return $results;
	}

	/**
	 * Panel menu callback
	 *
	 * @param string               $table
	 * @param HooksController|null $hooks_controller
	 *
	 * @since 6.0.0
	 * @return void
	 */
	public static function menu_callback( string $table, HooksController $hooks_controller = null ): void {

		$expert_sms_options = get_option( 'expert_sms_settings' );

		$pagenum      = isset( $_GET['pagenum'] ) ? absint( $_GET['pagenum'] ) : 1;
		$limit        = $expert_sms_options['users_per_page'] ?? 1; // number of rows in page
		$offset       = ( $pagenum - 1 ) * $limit;
		$total        = self::get_table_count( $table );
		$num_of_pages = ceil( $total / $limit );

		$action = isset( $_GET['action'] ) && ! empty( $_GET['action'] ) ? $_GET['action'] : null;

		$action_callback = sprintf( 'expert_sms_%s_handler', $action );

		if ( function_exists( $action_callback ) && is_callable( $action_callback ) ) {

			$action_callback( $hooks_controller, $_GET['page'] ?? '' );

		} else {

			$data = self::get_table_rows( $table, $offset, $limit );

			$view = sprintf( 'back.%s.users', $table );
			Utils::load_views( $view, compact( 'data', 'pagenum', 'num_of_pages', 'total' ) );
		}
	}
}