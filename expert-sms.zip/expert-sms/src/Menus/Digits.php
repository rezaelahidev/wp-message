<?php


namespace ExpertSMS\Menus;

use ExpertSMS\Controllers\HooksController;
use ExpertSMS\Core\Utils;

/**
 * Class PostMenu
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Menus
 */
class Digits extends PanelSetup {

	public function __construct( HooksController $hooks_controller ) {

		parent::__construct( $hooks_controller );

		add_action( 'wp_ajax_search_digits_users', [ $this, 'search_users' ] );
	}

	public function register(): void {

		add_submenu_page(
			'post_users.php',
			__( 'دیجیتس', 'expert-sms' ),
			__( 'دیجیتس', 'expert-sms' ),
			'manage_options',
			'digits-users.php',
			[ $this, 'display' ]
		);
	}

	public function display(): bool {

		global $wpdb, $expert_sms_options;

		$pagenum      = isset( $_GET['pagenum'] ) ? absint( $_GET['pagenum'] ) : 1;
		$limit        = $expert_sms_options['users_per_page'] ?? 1; // number of rows in page
		$offset       = ( $pagenum - 1 ) * $limit;
		$total        = $wpdb->get_results( $wpdb->prepare( "SELECT COUNT(DISTINCT meta_value) as count FROM $wpdb->usermeta WHERE meta_key=%s", 'billing_phone' ) );
		$num_of_pages = ceil( $total[0]->count / $limit );

		$data = $wpdb->get_results( $wpdb->prepare( "
	SELECT meta_value , user_id FROM $wpdb->usermeta
	WHERE meta_key=%s
	GROUP BY meta_value
	ORDER BY user_id DESC 
	LIMIT %d,%d
	", 'billing_phone', $offset, $limit ) );

		$action = isset( $_GET['action'] ) && ! empty( $_GET['action'] ) ? $_GET['action'] : null;

		$action_callback = sprintf( 'expert_sms_%s_handler', $action );

		if ( function_exists( $action_callback ) && is_callable( $action_callback ) ) {

			$action_callback();

			return true;
		}

		Utils::load_views( 'back.digits.users', compact( 'data', 'pagenum', 'num_of_pages' ) );

		return true;
	}

	protected function priority(): int {

		return 40;
	}

	public function search_users(): bool {

		if ( ! current_user_can( 'manage_options' ) ) {

			return false;
		}

		global $wpdb;
		$search_type    = isset( $_POST['type'] ) ? $_POST['type'] : null;
		$search_content = ! empty( $_POST['search_content'] ) && isset( $_POST['search_content'] ) ? $_POST['search_content'] : null;
		switch ( $search_type ) {
			case 'all':
				$query = "
				SELECT meta_value , user_id FROM $wpdb->usermeta
				WHERE meta_key=%s
				GROUP BY meta_value
				ORDER BY user_id DESC 
				LIMIT 1,10
				";
				$users = $wpdb->get_results( $wpdb->prepare( $query, 'billing_phone' ) );
				break;
			case 'pre_num':
				$query = "
				SELECT meta_value , user_id FROM $wpdb->usermeta
				WHERE meta_value LIKE %s AND meta_key=%s
				GROUP BY meta_value
				ORDER BY user_id DESC 
				";
				$users = $wpdb->get_results( $wpdb->prepare( $query, '%' . $search_content . '%', 'billing_phone' ) );
				break;
		}

		if ( is_null( $users ) ) {
			return false;
		}
		$html = '<table class="widefat">
            <tr class="tbl-head">
                <th class="tbl-head-col"><strong>نام و نام خانوادگی</strong></th>
                <th class="tbl-head-col"><strong>شماره تلفن</strong></th>
                <th class="tbl-head-col"><strong>حذف کاربر</strong></th>
                <th class="tbl-head-col"><strong>ویرایش اطلاعات</strong></th>
                <th class="tbl-head-col"><strong>ارسال پیامک تکی</strong></th>
                <th class="tbl-head-col"><strong>انتخاب همه</strong></th>
                <th class="tbl-head-col">
                    <label class="switch">
                        <input type="checkbox" value="All" onClick="toggle(this)"/>
                        <span class="slider"></span>
                    </label>
                </th>
            </tr>';

		if ( ! empty( $users ) ) {
			foreach ( $users as $user ) {

				if ( ! isset( $user->meta_value, $user->user_id ) ) {

					continue;
				}

				$html .= '<tr class="exp-sms-user-rows">';
				$html .= '<td class="tbl-content-row" style="position: relative">
			<em>' . get_user_by( 'ID', $user->user_id )->display_name . '</em></td>';
				$html .= '<td class="tbl-content-row">
			<em>' . Utils::replace_persian_number( $user->meta_value ) . '</em>
		</td>';
				$html .= '<td class="tbl-content-row"><a
				href="' . esc_url( admin_url( 'admin.php?page=digits-users.php&action=user_delete_digits&id=' . $user->user_id ) ) . '"
				class="exsms-delete-user" title="حذف کاربر"><svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                     x="0px" y="0px"
                                     viewBox="0 0 27.965 27.965" style="enable-background:new 0 0 27.965 27.965;" xml:space="preserve">
<g>
    <g id="c142_x">
        <path d="M13.98,0C6.259,0,0,6.261,0,13.983c0,7.721,6.259,13.982,13.98,13.982c7.725,0,13.985-6.262,13.985-13.982
			C27.965,6.261,21.705,0,13.98,0z M19.992,17.769l-2.227,2.224c0,0-3.523-3.78-3.786-3.78c-0.259,0-3.783,3.78-3.783,3.78
			l-2.228-2.224c0,0,3.784-3.472,3.784-3.781c0-0.314-3.784-3.787-3.784-3.787l2.228-2.229c0,0,3.553,3.782,3.783,3.782
			c0.232,0,3.786-3.782,3.786-3.782l2.227,2.229c0,0-3.785,3.523-3.785,3.787C16.207,14.239,19.992,17.769,19.992,17.769z"/>
    </g>
    <g id="Capa_1_104_">
    </g>
</g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
</svg></a></td>';
				$html .= '<td class="tbl-content-row"><a
				href="' . esc_url( admin_url( 'admin.php?page=download-users.php&action=user_edit_digits&id=' . $user->user_id ) ) . '"
				class="exsms-edit-user" title="ویرایش اطلاعات"><svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                     x="0px" y="0px"
                                     width="494.936px" height="494.936px" viewBox="0 0 494.936 494.936"
                                     style="enable-background:new 0 0 494.936 494.936;"
                                     xml:space="preserve">
<g>
    <g>
        <path d="M389.844,182.85c-6.743,0-12.21,5.467-12.21,12.21v222.968c0,23.562-19.174,42.735-42.736,42.735H67.157
			c-23.562,0-42.736-19.174-42.736-42.735V150.285c0-23.562,19.174-42.735,42.736-42.735h267.741c6.743,0,12.21-5.467,12.21-12.21
			s-5.467-12.21-12.21-12.21H67.157C30.126,83.13,0,113.255,0,150.285v267.743c0,37.029,30.126,67.155,67.157,67.155h267.741
			c37.03,0,67.156-30.126,67.156-67.155V195.061C402.054,188.318,396.587,182.85,389.844,182.85z"/>
        <path d="M483.876,20.791c-14.72-14.72-38.669-14.714-53.377,0L221.352,229.944c-0.28,0.28-3.434,3.559-4.251,5.396l-28.963,65.069
			c-2.057,4.619-1.056,10.027,2.521,13.6c2.337,2.336,5.461,3.576,8.639,3.576c1.675,0,3.362-0.346,4.96-1.057l65.07-28.963
			c1.83-0.815,5.114-3.97,5.396-4.25L483.876,74.169c7.131-7.131,11.06-16.61,11.06-26.692
			C494.936,37.396,491.007,27.915,483.876,20.791z M466.61,56.897L257.457,266.05c-0.035,0.036-0.055,0.078-0.089,0.107
			l-33.989,15.131L238.51,247.3c0.03-0.036,0.071-0.055,0.107-0.09L447.765,38.058c5.038-5.039,13.819-5.033,18.846,0.005
			c2.518,2.51,3.905,5.855,3.905,9.414C470.516,51.036,469.127,54.38,466.61,56.897z"/>
    </g>
</g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
</svg></a></td>';
				$html .= '<td class="tbl-content-row"><a
				href="' . esc_url( admin_url( 'admin.php?page=digits-users.php&action=send_sms_digits&id=' . $user->user_id ) ) . '"
				class="exsms-send-to-user" title="ارسال پیامک"><svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                     x="0px" y="0px"
                                     viewBox="0 0 495.003 495.003" style="enable-background:new 0 0 495.003 495.003;" xml:space="preserve">
<g id="XMLID_51_">
    <path id="XMLID_53_" d="M164.711,456.687c0,2.966,1.647,5.686,4.266,7.072c2.617,1.385,5.799,1.207,8.245-0.468l55.09-37.616
		l-67.6-32.22V456.687z"/>
    <path id="XMLID_52_" d="M492.431,32.443c-1.513-1.395-3.466-2.125-5.44-2.125c-1.19,0-2.377,0.264-3.5,0.816L7.905,264.422
		c-4.861,2.389-7.937,7.353-7.904,12.783c0.033,5.423,3.161,10.353,8.057,12.689l125.342,59.724l250.62-205.99L164.455,364.414
		l156.145,74.4c1.918,0.919,4.012,1.376,6.084,1.376c1.768,0,3.519-0.322,5.186-0.977c3.637-1.438,6.527-4.318,7.97-7.956
		L494.436,41.257C495.66,38.188,494.862,34.679,492.431,32.443z"/>
</g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
</svg></a></td>';
				$html .= '<td class="tbl-content-row">
			<label class="switch">
				<input type="checkbox" name="contact[]" id="contact"
				       value="' . $user->meta_value . '">';
				$html .= '<span class="slider"></span>
			</label>
		</td>
		<td class="tbl-content-row"></td></tr>';
			}
			$html .= '</table>';
			wp_send_json( [
				'success'      => true,
				'render_users' => $html
			] );
		} else {
			$html .= '<tr class="exp-sms-user-rows"><td style="width: 300px" class="tbl-content-row name-col">متاسفانه هیچ رکوردی یافت نشد .</td></tr>';
			wp_send_json( [
				'success'      => false,
				'render_users' => $html
			] );
		}

		return true;
	}

	protected function id(): string {

		return 'digits';
	}
}