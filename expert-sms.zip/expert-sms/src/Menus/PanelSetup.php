<?php


namespace ExpertSMS\Menus;

use ExpertSMS\Controllers\HooksController;
use ExpertSMS\Core\Rest\RestSetup;
use ExpertSMS\Core\Utils;
use ExpertSMS\Rest\Sender;

/**
 * Class PanelController
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Menus
 */
abstract class PanelSetup {

	/**
	 * Store the instance of Hooks controller.
	 *
	 * @var HooksController
	 */
	protected $hooks_controller;


	public function __construct( HooksController $hooks_controller ) {

		$this->hooks_controller = $hooks_controller;

		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ] );

		add_action( 'admin_menu', [ $this, 'register' ], $this->priority() );

		add_action( 'wp_ajax_send_from_campaigns', [ $this, 'send_sms' ] );
		add_action( 'wp_ajax_send_cat_sms_post', [ $this, 'send_sms' ] );
	}

	public function enqueue(): void {

		global $hook_suffix;

		$patterns = [
			'post_users',
			'category-post-users',
			'download-users',
			'category-download-users',
			'product-users',
			'category-product-users',
			'digits-users'
		];

		$preg_match = preg_match(
			sprintf(
				'/%s/', implode( '|', $patterns )
			),
			$hook_suffix,
			$matches
		);

		if ( ! $preg_match ) {

			return;
		}

		wp_enqueue_script(
			'posts-category-js',
			SMS_SRC . 'Menus/assets/js/admin-scripts.js',
			[],
			SMS_VER,
			true
		);

		wp_localize_script(
			'posts-category-js',
			'AdminL10n',
			[
				'admin_ajax' => admin_url( 'admin-ajax.php' ),
			]
		);
	}

	/**
	 * Register custom admin menu.
	 *
	 * @since 6.0.0
	 * @return void
	 */
	abstract public function register(): void;

	public function display_category(): void {

		$categories = get_categories( [ 'taxonomy' => 'category' ] );

		$html = '<div class="wrap exp-sms"><h1>' . __( 'کاربران دسته بندی نوشته ها', 'expert-sms' ) . '</h1>';
		$html .= '<div class="select-section">';
		$html .= '<label name="terms">' . __( 'انتخاب یک دسته بندی : ', 'expert-sms' ) . '</label>';
		$html .= '<select id="sections" name="terms">';

		foreach ( $categories as $key => $category ) {
			$html .= '<option value="' . $key . '">' . $category->name . '</option>';
		}

		$html .= '</select><br><br>';
		$html .= '<input  class="button-primary section-' . $this->id() . '" type="button" value="' . __( 'نمایش کاربران', 'expert-sms' ) . '">';
		$html .= '</div>';
		$html .= '</div> <input style="display: none;" id="post_cat_sms" class="group-send" type="submit" name="send_sms" value="' . __( 'ارسال پیامک', 'expert-sms' ) . '">';

		echo $html;
	}

	public function update_display_category(): bool {

		global $wpdb, $_POST;

		if ( empty( $_POST['table'] ) ) {

			echo '<h3 class="exp-sms-404">کاربری یافت نشد !</h3>';
			exit;
		}

		$query = sprintf( "
    SELECT * FROM {$wpdb->prefix}smsnews_%ss
    GROUP BY mobile
    ", $_POST['table'] );

		$users = $wpdb->get_results( $query );
		if ( is_null( $users ) ) {
			return false;
		}

		if ( isset( $_POST['group-send'] ) ) {
			add_action( 'wp_ajax_send_cat_sms_post', 'expert_sms_send_cat_sms_post' );
		}

		$_post = $_POST;

		Utils::load_views( 'back.category.users', compact( '_post', 'users' ) );

		return true;
	}

	public function send_sms(): void {

		if ( ! current_user_can( 'manage_options' ) ) {

			return;
		}

		$mobiles   = isset( $_POST['mobile'] ) && ! empty( $_POST['mobile'] ) ? $_POST['mobile'] : null;
		$user_name = isset( $_POST['user_name'] ) && ! empty( $_POST['user_name'] ) ? $_POST['user_name'] : null;
		$message   = isset( $_POST['message'] ) && ! empty( $_POST['message'] ) ? $_POST['message'] : null;
		$i         = 0;

		if ( ! $message || empty( trim( $message ) ) ) {

			$html = __( 'پیام ارسال نشد ! امکان ارسال پیامک خالی وجود ندارد .', 'expert-sms' );

			wp_send_json( [
				'success' => false,
				'message' => $html,
			] );

			return;
		} else if ( ! $mobiles ) {

			$html = __( 'کاربری جهت ارسال پیام انتخاب نشده است !', 'expert-sms' );

			wp_send_json( [
				'success' => false,
				'message' => $html,
			] );

			return;
		}


		foreach ( $mobiles as $mobile ) {

			$request = new \WP_REST_Request( 'POST',
				sprintf(
					'%1$s/%2$s',
					RestSetup::NAMESPACE,
					Sender::getInstance()->end_point()
				)
			);
			$request->set_body_params(
				[
					'mobile'  => $mobile,
					'message' => $message,
					'user'    => $user_name[ $i ],
				]
			);

			$response = Sender::getInstance()->handler( $request );

			$statuses[ $mobile ] = $response->get_data();
			$i ++;
		}

		$html = __( 'عملیات موفقیت آمیز! وضعیت ارسال پیام برای هر کاربر بروز رسانی شد. ', 'expert-sms' );
		wp_send_json( [
			'success'  => true,
			'message'  => $html,
			'statuses' => $statuses ?? [],
		] );
	}

	abstract protected function priority(): int;

	abstract protected function id(): string;
}
