<?php

namespace ExpertSMS\Core;

use RuntimeException;

/**
 * Trait Singleton
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Core
 */
trait Singleton {

	/**
	 * Store instance of self class or null.
	 *
	 * @var null
	 */
	private static $instance = null;

	/**
	 * gets the instance via lazy initialization (created on first usage)
	 *
	 * @since 6.0.0
	 * @return self
	 */
	public static function getInstance(): self {

		if ( self::$instance === null ) {

			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * prevent from being unserialized (which would create a second instance of it)
	 * @throws RuntimeException
	 *
	 * @since 6.0.0
	 * @return void
	 */
	public function __wakeup(): void {

		throw new RuntimeException( __( "Cannot unserialize singleton", 'expert-sms' ) );
	}
}
