<?php

namespace ExpertSMS\Core\Rest;

interface AllowBatch {

	/**
	 * @return array
	 */
	public function allow_batch(): array;
}
