<?php

namespace ExpertSMS\Core\Rest;

/**
 * API to Work with WordPress Rest API.
 *
 * @since   1.0.0
 * @package ExpertSMS\Core\Rest
 */
final class RestSetup {

	/**
	 * Store the routes list.
	 *
	 * @var array
	 * @since 1.0.0
	 */
	protected static $routes = [];

	/**
	 * Rest Route Namespace.
	 *
	 * @since 1.0.0
	 */
	public const NAMESPACE = 'expert-sms/v1';

	/**
	 * Initialize the rest module.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function setup(): bool {

		add_action( 'rest_api_init', [ self::class, 'init' ], 20 );

		return true;
	}

	/**
	 * Registers a REST API route.
	 *
	 * @param string|RestHandler $handler Handler classname or instance.
	 *
	 * @since 1.0.0
	 *
	 * @return bool true on success, false on error.
	 */
	public static function register( $handler ): bool {

		$classname = $handler instanceof RestHandler ? get_class( $handler ) : $handler;

		if ( ! in_array( $classname, self::$routes, true ) ) {

			self::$routes[] = $classname;

			return true;
		}

		return false;
	}

	/**
	 * Fires when preparing to serve an API request.
	 *
	 * @since 1.0.0
	 */
	public static function init(): void {

		/**
		 * @var string|RestHandler $handler Handler classname or instance
		 */
		foreach ( self::$routes as $handler ) {

			if ( ! $handler instanceof RestHandler ) {

				$handler = $handler::getInstance();
			}

			register_rest_route(
				self::NAMESPACE,
				$handler->end_point(),
				[
					'methods'             => $handler->methods(),
					'callback'            => [ $handler, 'rest_response' ],
					'permission_callback' => [ $handler, 'rest_permission' ],
					'allow_batch'         => $handler instanceof AllowBatch ? $handler->allow_batch() : [],

				],
				true
			);
		}
	}

	/**
	 * Flush registered routes.
	 *
	 * @since 1.0.0
	 */
	public static function flush(): void {

		self::$routes = [];
	}


	/**
	 * Get all registered routes.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function routes(): array {

		return self::$routes;
	}
}
