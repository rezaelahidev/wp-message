<?php

namespace ExpertSMS\Core\Rest;

/**
 * Rest Endpoint Handler Base Class.
 *
 * @since   1.0.0
 * @package BetterStudio\Core\Rest
 */
abstract class RestHandler {

	/**
	 * Rest route callback handler.
	 *
	 * @param \WP_REST_Request $request
	 *
	 * @since 1.0.0
	 * @throws \Exception
	 * @return \WP_REST_Response
	 */
	abstract public function handler( \WP_REST_Request $request ): \WP_REST_Response;

	/**
	 * Check user permission.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	abstract public function permission(): bool;

	/**
	 * Get endpoint name.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	abstract public function end_point(): string;


	/**
	 * The rest endpoint method.
	 *
	 * @since 1.0.0
	 * @return string GET or POST
	 */
	abstract public function methods(): string;

	/**
	 * The rest url.
	 *
	 * @since 1.0.3
	 * @return string
	 */
	public static function url(): string {

		return rest_url( trailingslashit( RestSetup::NAMESPACE ) . static::getInstance()->end_point() );
	}

	/**
	 * @param \WP_REST_Request $request
	 *
	 * @since 1.0.0
	 *
	 * @return \WP_REST_Response
	 */
	final public function response( \WP_REST_Request $request ): \WP_REST_Response {

		try {

			return $this->handler( $request );

		} catch ( \Exception $e ) {

			return new \WP_REST_Response( [

				'success' => false,
				'code'    => $e->getMessage(),
				'message' => $e->getTraceAsString(),
			] );
		}
	}
}
