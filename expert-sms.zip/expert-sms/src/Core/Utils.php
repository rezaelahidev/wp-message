<?php


namespace ExpertSMS\Core;

/**
 * Class Utils
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Core
 */
class Utils {

	/**
	 * Load model view
	 *
	 * @param string $view
	 * @param array  $params
	 *
	 * @since 6.0.0
	 */
	public static function load_views( string $view, array $params = array() ): void {

		$view      = str_replace( '.', DIRECTORY_SEPARATOR, $view );
		$view_file = SMS_TMP . $view . '.php';

		if ( ! file_exists( $view_file ) || ! is_readable( $view_file ) ) {

			return;
		}

		! empty( $params ) && extract( $params, EXTR_OVERWRITE );

		include $view_file;
	}

	/**
	 * Replace persian number with latin number.
	 *
	 * @param $number
	 *
	 * @since 6.0.0
	 * @return array|string|string[]
	 */
	public static function replace_persian_number( $number ) {

		$persian_num = [
			'۰',
			'۱',
			'۲',
			'۳',
			'۴',
			'۵',
			'۶',
			'۷',
			'۸',
			'۹'
		];
		$en_num      = [
			'0',
			'1',
			'2',
			'3',
			'4',
			'5',
			'6',
			'7',
			'8',
			'9'
		];

		$number = str_replace( $en_num, $persian_num, $number );

		return ! $number ? 'صفر' : $number;
	}
}