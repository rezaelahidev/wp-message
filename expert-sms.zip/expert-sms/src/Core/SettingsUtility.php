<?php


namespace ExpertSMS\Core;

use ExpertSMS\Rest\Gateway\Services\CandoService;
use ExpertSMS\Rest\Gateway\Services\GeneralService;
use ExpertSMS\Rest\Gateway\Services\IPPanelService;
use ExpertSMS\Rest\Gateway\Services\NewSMSIRService;
use ExpertSMS\Rest\Gateway\Services\NiazpardazSMS;
use ExpertSMS\Rest\Gateway\Services\PayamResanService;
use ExpertSMS\Rest\Gateway\Services\RayganSMSService;
use ExpertSMS\Rest\Gateway\Services\RelaxService;
use ExpertSMS\Rest\Gateway\Services\SibSMSPanelService;
use ExpertSMS\Rest\Gateway\Services\SMSIRService;
use ExpertSMS\Rest\Gateway\Services\SunWayService;

/**
 * Class SettingsUtility
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Core
 */
class SettingsUtility {

	/**
	 * Get field value of settings by index.
	 *
	 * @param string $index
	 *
	 * @since 6.0.0
	 * @return mixed
	 */
	public static function get_by_index( string $index ) {

		$settings = get_option( 'expert_sms_settings', [] );

		return $settings[ $index ] ?? false;
	}

	/**
	 * Get all settings as array.
	 *
	 * @since 6.0.0
	 * @return array
	 */
	public static function get(): array {

		return get_option( 'expert_sms_settings', [] );
	}

	/**
	 * Get current setup webservice object.
	 *
	 * @since 6.0.0
	 */
	public static function get_webservice_object(): string {

		$webservice = self::get_by_index( 'webservice' );

		if ( ! $webservice ) {

			return '';
		}

		switch ( $webservice ) {

			case 'sunway':
				$object = SunWayService::class;
				break;

			case 'faraz':
			case 'farapayamak':
			case 'melipayamak':
				$object = GeneralService::class;
				break;

			case 'smsir':
				$object = SMSIRService::class;
				break;

			case 'cando':
				$object = CandoService::class;
				break;

			case 'newsmsir':
				$object = NewSMSIRService::class;
				break;
			case 'modirpayamak.com':
			case 'ippanel.com':
				$object = IPPanelService::class;
				break;
			case 'sms.rangine.ir':
			case 'shahvarpayam':
			case 'mediana':
			case 'sms.zhiak.com':
			case 'payamnam':
			case 'sibsmspanel':
				$object = SibSMSPanelService::class;
				break;
			case 'relax':
				$object = RelaxService::class;
				break;
			case 'raygansms':
				$object = RayganSMSService::class;
				break;
			case 'payam-resan':
				$object = PayamResanService::class;
				break;
			case 'niazpardaz':
				$object = NiazpardazSMS::class;
				break;
		}

		return $object ?? '';
	}
}
