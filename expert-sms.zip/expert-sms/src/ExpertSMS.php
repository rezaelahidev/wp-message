<?php

namespace ExpertSMS;

use RuntimeException;
use ExpertSMS\Compatibility\Edd;
use ExpertSMS\Compatibility\Woocommerce;
use ExpertSMS\Controllers\AssetsController;
use ExpertSMS\Controllers\HooksController;
use ExpertSMS\Core\Rest\RestSetup;
use ExpertSMS\Core\Singleton;
use ExpertSMS\Menus\Digits;
use ExpertSMS\Menus\Generals;
use ExpertSMS\MetaBoxes\Downloads;
use ExpertSMS\MetaBoxes\Posts;
use ExpertSMS\MetaBoxes\Products;
use ExpertSMS\Rest\Sender;
use ExpertSMS\Shortcodes\DownloadsType;
use ExpertSMS\Shortcodes\PostsType;
use ExpertSMS\Shortcodes\ProductsType;
use ExpertSMS\Shortcodes\SignIn;
use ExpertSMS\Shortcodes\Signup;

/**
 * Class ExpertSMS
 *
 * @since   6.0.0
 *
 * @package ExpertSMS
 */
class ExpertSMS {

	use Singleton;

	/**
	 * PluginSetup constructor.
	 *
	 * @throws RuntimeException
	 * @since 6.0.0
	 */
	private function __construct() {

		if ( ! self::setup() ) {

			throw new RuntimeException( __( "Cannot setup this plugin!", 'expert-sms' ) );
		}

		register_activation_hook( SMS__FILE__, [ $this, 'activation_callback' ] );
	}

	/**
	 * Setup expert sms plugin.
	 *
	 * @since 6.0.0
	 * @return bool
	 */
	public static function setup(): bool {

		///
		/// Setup Controllers
		///
		AssetsController::getInstance();
		$hooks = HooksController::getInstance();

		///
		/// Setup shortcodes
		///
		new SignIn( $hooks );
		new Signup( $hooks );
		PostsType::getInstance();
		ProductsType::getInstance();
		DownloadsType::getInstance();

		///
		/// Setup MetaBoxes
		///
//		Posts::getInstance();
//		Products::getInstance();
//		Downloads::getInstance();

		///
		/// Rest API Setup
		///
		RestSetup::register( Sender::class );

		///
		/// Setup Panel
		///
		new Menus\Posts( $hooks );
		new Menus\Downloads( $hooks );
		new Menus\Products( $hooks );
		new Digits( $hooks );
		new Generals( $hooks );

		///
		/// Setup Compatibilities for edd, and woocommerce plugins.
		///
		new Edd( $hooks );
		new Woocommerce( $hooks );

		return true;
	}

	/**
	 * Activation callback.
	 *
	 * @since 6.0.0
	 * @return void
	 */
	public function activation_callback(): void {

		global $wpdb;
		$download_query = "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}smsnews_downloads` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `download_id` bigint(20) NOT NULL,
  `term_id` longtext COLLATE utf8_persian_ci NOT NULL,
  `term_name` longtext COLLATE utf8_persian_ci NOT NULL,
  `mobile` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `user_name` longtext COLLATE utf8_persian_ci,
  `download_name` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `purchase_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;
COMMIT;
";

		$post_query = "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}smsnews_posts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) NOT NULL,
  `term_id` longtext COLLATE utf8_persian_ci NOT NULL,
  `mobile` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `user_name` varchar(300) COLLATE utf8_persian_ci DEFAULT NULL,
  `term_name` longtext COLLATE utf8_persian_ci NOT NULL,
  `post_name` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;
COMMIT;
";

		$product_query = "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}smsnews_products` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) NOT NULL,
  `term_id` longtext COLLATE utf8_persian_ci NOT NULL,
  `mobile` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `user_name` varchar(300) COLLATE utf8_persian_ci NOT NULL,
  `term_name` longtext COLLATE utf8_persian_ci NOT NULL,
  `product_name` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `purchase_status` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;
COMMIT;
";

		$user_query = "DROP TABLE IF EXISTS `{$wpdb->prefix}user_verification`;
CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}user_verification` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(11) COLLATE utf8_persian_ci NOT NULL,
  `code` varchar(4) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;
COMMIT;";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $download_query );
		dbDelta( $post_query );
		dbDelta( $product_query );
		dbDelta( $user_query );
	}
}