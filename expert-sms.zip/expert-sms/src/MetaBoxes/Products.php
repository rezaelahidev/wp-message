<?php


namespace ExpertSMS\MetaBoxes;

use ExpertSMS\Core\Singleton;
use ExpertSMS\Core\Utils;

/**
 * Class Posts
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\MetaBoxes
 */
class Products extends MetaBoxSetup {

	use Singleton;

	public function register(): void {

		add_meta_box(
			'expert_sms_download_meta_box',
			__( 'ارسال پیام کوتاه اطلاع رسانی', 'expert-sms' ),
			[ $this, 'callback' ],
			'product',
			'normal',
			'high'
		);
	}

	public function callback(): bool {

		global $wpdb, $post;
		$product_id = $post->ID;
		$users      = $wpdb->get_results( $wpdb->prepare( "
	SELECT COUNT(sp.mobile) as total FROM {$wpdb->prefix}expert_sms_products sp
	WHERE sp.product_id = %d
	", $product_id ) );
		if ( is_null( $users ) ) {
			return false;
		}
		Utils::load_views( 'back.metaboxes.product-meta-box', compact( 'users', 'product_id' ) );

		return true;
	}
}