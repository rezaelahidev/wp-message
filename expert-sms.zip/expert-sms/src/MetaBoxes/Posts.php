<?php


namespace ExpertSMS\MetaBoxes;

use ExpertSMS\Core\Singleton;
use ExpertSMS\Core\Utils;

/**
 * Class Posts
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\MetaBoxes
 */
class Posts extends MetaBoxSetup {

	use Singleton;

	public function register(): void {

		add_meta_box(
			'expert_sms_meta_box',
			__( 'ارسال پیام کوتاه اطلاع رسانی', 'expert-sms' ),
			[ $this, 'callback' ],
			'post',
			'normal',
			'high'
		);
	}

	public function callback(): bool {

		global $wpdb, $_POST, $post;
		
		$post_id    = $post->ID;
		$downlod_id = (int) get_post_meta( $post_id, 'eddid', true );
		$users      = $wpdb->get_results( $wpdb->prepare( "
    SELECT COUNT(sp.mobile) as total FROM {$wpdb->prefix}smsnews_posts sp
    WHERE sp.post_id = %d 
    ", $post_id ) );
		if ( is_null( $users ) ) {
			return false;
		}
		$dl_users = $wpdb->get_results( $wpdb->prepare( "
	SELECT COUNT(sd.mobile) as total FROM {$wpdb->prefix}smsnews_downloads sd
	WHERE sd.download_id = %d
	", $downlod_id ) );
		if ( is_null( $dl_users ) ) {
			return false;
		}
		Utils::load_views( 'back.metaboxes.post-meta-box', compact( 'users', 'dl_users', 'post_id' ) );

		return true;
	}
}