<?php

namespace ExpertSMS\MetaBoxes;

/**
 * Class MetaBoxSetup
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\MetaBoxes
 */
abstract class MetaBoxSetup {

	protected function __construct() {

		add_action( 'add_meta_boxes', [ $this, 'register' ] );
	}

	/**
	 * Register custom meta-boxes
	 *
	 * @since 6.0.0
	 * @return void
	 */
	abstract public function register(): void;

	/**
	 * The callback for handle custom meta box functionality.
	 *
	 * @since 6.0.0
	 * @return bool false when failure, true on success.
	 */
	abstract public function callback(): bool;
}