<?php


namespace ExpertSMS\MetaBoxes;

use ExpertSMS\Core\Singleton;
use ExpertSMS\Core\Utils;

/**
 * Class Downloads
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\MetaBoxes
 */
class Downloads extends MetaBoxSetup {

	use Singleton;

	public function register(): void {

		add_meta_box(
			'expert_sms_download_meta_box',
			__( 'ارسال پیام کوتاه اطلاع رسانی', 'expert-sms' ),
			[ $this, 'callback' ],
			'download',
			'normal',
			'high'
		);
	}

	public function callback(): bool {

		global $wpdb, $post;
		$download_id = $post->ID;
		$users       = $wpdb->get_results( $wpdb->prepare( "
	SELECT COUNT(sd.mobile) as total FROM {$wpdb->prefix}expert_sms_downloads sd
	WHERE sd.download_id = %d
	", $download_id ) );
		if ( is_null( $users ) ) {
			return false;
		}
		Utils::load_views( 'back.metaboxes.download-meta-box', compact( 'users', 'download_id' ) );

		return true;
	}
}