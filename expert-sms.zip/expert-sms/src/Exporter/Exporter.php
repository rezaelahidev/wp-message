<?php

namespace ExpertSMS\Exporter;

/**
 * Class Exporter
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Exporter
 */
abstract class Exporter {
	private $postsData;
	private $productsData;
	private $downloadsData;
	private $digitsData;

	public function __construct() {
		$this->prepareData();
	}

	public function prepareData() {
		global $wpdb;
		$this->postsData = $wpdb->get_results( "
		SELECT * FROM {$wpdb->prefix}smsnews_posts
		" );
		if ( is_null( $this->postsData ) ) {
			return false;
		}

		$this->productsData = $wpdb->get_results( "
		SELECT * FROM {$wpdb->prefix}smsnews_products
		" );
		if ( is_null( $this->productsData ) ) {
			return false;
		}

		$this->downloadsData = $wpdb->get_results( "
		SELECT * FROM {$wpdb->prefix}smsnews_downloads
		" );
		if ( is_null( $this->downloadsData ) ) {
			return false;
		}
		$this->digitsData = $wpdb->get_results( $wpdb->prepare( "
	SELECT meta_value , user_id FROM $wpdb->usermeta
	WHERE meta_key=%s
	GROUP BY meta_value
	ORDER BY user_id DESC 
	", 'billing_phone' ) );
		if ( is_null( $this->digitsData ) ) {
			return false;
		}
	}

	public function getPostsData() {
		return $this->postsData;
	}

	public function getProductsData() {
		return $this->productsData;
	}

	public function getDownloadsData() {
		return $this->downloadsData;
	}

	public function getDigitsData() {
		return $this->digitsData;
	}

	abstract public function export( $action ): void;
}