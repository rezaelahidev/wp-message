<?php

namespace ExpertSMS\Exporter;

/**
 * Class CsvExporter
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Exporter
 */
class CsvExporter extends Exporter {

	public function export( $action ): void {
		include SMS_INC . '/Exporter/classes/php-export-data.php';
		switch ( $action ) {
			case 'postsExporter':
				$data     = $this->getPostsData();
				$row      = [
					'id',
					'post_id',
					'term_id',
					'mobile',
					'user_name',
					'term_name',
					'post_name'
				];
				$exporter = new ExportDataExcel( 'browser', 'postExport.xls' );
				$exporter->initialize();
				$exporter->addRow( $row );
				foreach ( $data as $user ) {
					$content = [
						$user->id,
						$user->post_id,
						$user->term_id,
						$user->mobile,
						$user->user_name,
						$user->term_name,
						$user->post_name
					];
					$exporter->addRow( $content );
				}
				$exporter->addRow( array( "user" ) );
				$exporter->finalize();
				break;
			case 'productsExporter':
				$data     = $this->getProductsData();
				$row      = [
					'id',
					'product_id',
					'term_id',
					'mobile',
					'user_name',
					'term_name',
					'product_name',
					'purchase_status'
				];
				$exporter = new ExportDataExcel( 'browser', 'productExport.xls' );
				$exporter->initialize();
				$exporter->addRow( $row );
				foreach ( $data as $user ) {
					$content = [
						$user->id,
						$user->product_id,
						$user->term_id,
						$user->mobile,
						$user->user_name,
						$user->term_name,
						$user->product_name,
						$user->purchase_status
					];
					$exporter->addRow( $content );
				}
				$exporter->addRow( array( "user" ) );
				$exporter->finalize();
				break;
			case 'downloadsExporter':
				$data     = $this->getDownloadsData();
				$row      = [
					'id',
					'download_id',
					'term_id',
					'mobile',
					'user_name',
					'term_name',
					'download_name',
					'purchase_status'
				];
				$exporter = new ExportDataExcel( 'browser', 'downloadExport.xls' );
				$exporter->initialize();
				$exporter->addRow( $row );
				foreach ( $data as $user ) {
					$content = [
						$user->id,
						$user->download_id,
						$user->term_id,
						$user->mobile,
						$user->user_name,
						$user->term_name,
						$user->download_name,
						$user->purchase_status
					];
					$exporter->addRow( $content );
				}
				$exporter->addRow( array( "user" ) );
				$exporter->finalize();
				break;
		}
	}
}