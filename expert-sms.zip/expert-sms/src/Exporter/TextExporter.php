<?php

namespace ExpertSMS\Exporter;

/**
 * Class TextExporter
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Exporter
 */
class TextExporter extends Exporter {

	public function export( $action ): void {
		switch ( $action ) {
			case 'postsExporter':
				$data = $this->getPostsData();

				if (!$data){

					return;
				}

				foreach ( $data as $user ) {
					$content = 'id => ' . $user->id . ',' . PHP_EOL;
					$content .= 'post_name => ' . $user->post_name . ',' . PHP_EOL;
					$content .= 'post_id => ' . $user->post_id . ',' . PHP_EOL;
					$content .= 'term_name => ' . $user->term_name . ',' . PHP_EOL;
					$content .= 'term_id => ' . $user->term_id . ',' . PHP_EOL;
					$content .= 'user_name => ' . $user->user_name . ',' . PHP_EOL;
					$content .= $user->mobile . ',' . PHP_EOL;
					$content .= '=============================================' . PHP_EOL;
					print $content;
				}
				header( 'Content-type: octet/stream; charset=UTF8' );
				header( 'Content-Disposition: attachment; filename="postsExport.txt"' );

				break;
			case 'productsExporter':
				$data = $this->getProductsData();

				if (!$data){

					return;
				}

				foreach ( $data as $user ) {
					$content = 'id => ' . $user->id . ',' . PHP_EOL;
					$content .= 'product_name => ' . $user->product_name . ',' . PHP_EOL;
					$content .= 'product_id => ' . $user->product_id . ',' . PHP_EOL;
					$content .= 'term_name => ' . $user->term_name . ',' . PHP_EOL;
					$content .= 'term_id => ' . $user->term_id . ',' . PHP_EOL;
					$content .= 'purchase_status => ' . $user->purchase_status . ',' . PHP_EOL;
					$content .= 'user_name => ' . $user->user_name . ',' . PHP_EOL;
					$content .= $user->mobile . ',' . PHP_EOL;
					$content .= '=============================================' . PHP_EOL;
					print $content;
				}
				header( 'Content-type: octet/stream; charset=UTF8' );
				header( 'Content-Disposition: attachment; filename="productsExport.txt"' );
				break;
			case 'downloadsExporter':
				$data = $this->getDownloadsData();

				if (!$data){

					return;
				}

				foreach ( $data as $user ) {
					$content = 'id => ' . $user->id . ',' . PHP_EOL;
					$content .= 'download_name => ' . $user->download_name . ',' . PHP_EOL;
					$content .= 'download_id => ' . $user->download_id . ',' . PHP_EOL;
					$content .= 'term_name => ' . $user->term_name . ',' . PHP_EOL;
					$content .= 'term_id => ' . $user->term_id . ',' . PHP_EOL;
					$content .= 'purchase_status => ' . $user->purchase_status . ',' . PHP_EOL;
					$content .= 'user_name => ' . $user->user_name . ',' . PHP_EOL;
					$content .= $user->mobile . ',' . PHP_EOL;
					$content .= '=============================================' . PHP_EOL;
					print $content;
				}
				header( 'Content-type: octet/stream; charset=UTF8' );
				header( 'Content-Disposition: attachment; filename="downloadsExport.txt"' );
				break;
			case 'digitsExporter':
				$data = $this->getDigitsData();

				if (!$data){

					return;
				}

				foreach ( $data as $user ) {
					$content = 'id => ' . $user->id . ',' . PHP_EOL;
					$content .= 'download_name => ' . $user->download_name . ',' . PHP_EOL;
					$content .= 'download_id => ' . $user->download_id . ',' . PHP_EOL;
					$content .= 'term_name => ' . $user->term_name . ',' . PHP_EOL;
					$content .= 'term_id => ' . $user->term_id . ',' . PHP_EOL;
					$content .= 'purchase_status => ' . $user->purchase_status . ',' . PHP_EOL;
					$content .= 'user_name => ' . $user->user_name . ',' . PHP_EOL;
					$content .= $user->mobile . ',' . PHP_EOL;
					$content .= '=============================================' . PHP_EOL;
					print $content;
				}
				header( 'Content-type: octet/stream; charset=UTF8' );
				header( 'Content-Disposition: attachment; filename="digitsExport.txt"' );
				break;
		}
	}
}