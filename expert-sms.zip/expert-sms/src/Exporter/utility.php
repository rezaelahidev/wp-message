<?php
function dexp_load_views($view,$params = array()){
	$view = str_replace('.',DIRECTORY_SEPARATOR,$view);
	$view_file = DEXP_VIEW.$view.'.php';
	if (file_exists($view_file) && is_readable( $view_file )){
		!empty($params) ? extract($params) : null ;
		include $view_file;
	}
}