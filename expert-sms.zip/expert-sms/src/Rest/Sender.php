<?php

namespace ExpertSMS\Rest;

use ExpertSMS\Core\Rest\RestHandler;
use ExpertSMS\Core\SettingsUtility;
use ExpertSMS\Core\Singleton;
use ExpertSMS\Rest\Gateway\Gateway;

/**
 * Class Send
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Rest
 */
class Sender extends RestHandler {

	/**
	 * Implements singleton instance method
	 *
	 * @since 1.0.0
	 */
	use Singleton;

	/**
	 * Store instance of WP_REST_Request
	 *
	 * @var \WP_REST_Request $request
	 */
	protected $request;

	public function handler( \WP_REST_Request $request ): \WP_REST_Response {

		$this->request = $request;

		return $this->_response();
	}

	/**
	 * @since 1.0.0
	 * @return \WP_REST_Response
	 */
	protected function _response(): \WP_REST_Response {

		$webservice = SettingsUtility::get_webservice_object();

		if ( ! $webservice ) {

			return new \WP_REST_Response( [] );
		}

		$gateway = new Gateway( [ new $webservice, 'send' ], $this->request );

		$data = $gateway->get_response();

		if ( is_wp_error( $data ) ) {

			$data = [ 'success' => false, 'error' => $data->get_error_code() ];

		} else if ( is_bool( $data ) ) {

			$data = [
				'success' => $data,
			];

		} else if ( is_array( $data ) ) {

			$data = array_merge( [ 'success' => true ], $data );
		}

		return new \WP_REST_Response( $data );
	}

	public function permission(): bool {

		return current_user_can( 'edit_posts' );
	}

	public function end_point(): string {

		return 'send-sms';
	}

	public function methods(): string {

		return 'POST';
	}
}
