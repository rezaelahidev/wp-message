<?php

namespace ExpertSMS\Rest\Gateway\Services;

/**
 * Class RayganSMSService
 *
 * @since 6.0.0
 *
 * @package ExpertSMS\Rest\Gateway\Services
 */
class RayganSMSService implements AllowSMS {

	/**
	 * @inhertDoc
	 *
	 * @param string $mobile
	 * @param string $username
	 * @param string $message
	 *
	 * @return bool
	 */
	public function send( string $mobile, string $username, string $message ): bool {

		global $expert_sms_options;

		if ( is_null( $message ) ) {

			return false;
		}

		try {

			$user    = $expert_sms_options['webservice_username'];
			$pass    = $expert_sms_options['webservice_password'];
			$from    = $expert_sms_options['webservice_number'];
			$message = str_replace( '%name%', $username, $message );
			$message = str_replace( "%E", PHP_EOL, $message );
			$url     = 'https://raygansms.com/SendMessageWithUrl.ashx';

			$remote = wp_remote_get( add_query_arg( [
				'Username'    => $user,
				'Password'    => $pass,
				'PhoneNumber' => $from,
				'MessageBody' => $message,
				'RecNumber'   => $mobile,
				'Smsclass'    => 1,
			], $url ) );

			if ( is_wp_error( $remote ) ) {

				return false;
			}

		} catch ( \Exception $e ) {

			return false;
		}

		return wp_remote_retrieve_body( $remote );
	}
}