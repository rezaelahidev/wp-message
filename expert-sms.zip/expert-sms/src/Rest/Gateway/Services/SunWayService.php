<?php

namespace ExpertSMS\Rest\Gateway\Services;

/**
 * Class SunWay
 *
 * @since   1.0.0
 *
 * @package ExpertSMS\Rest\Gateway\Services
 */
class SunWayService implements AllowSMS {

	public $Username = '';
	public $Password = '';

	private $SoapAddress = 'http://sms.sunwaysms.com/SMSWS/SOAP.asmx?wsdl';
	private $client;

	function __construct() {
		$this->client = new SoapClient( $this->SoapAddress );
	}

	public function GetClient() {
		return $this->client;
	}

	public function GetClientEx( $option ) {
		return new SoapClient( $this->SoapAddress, $option );
	}

	public function GetMethods() {
		$arr    = array();
		$client = GetClient();

		return $client->__getFunctions();
	}

	public function GetCredit() {
		$option = array( 'UserName' => $this->Username, 'Password' => $this->Password );
		$client = $this->GetClient();

		return $client->GetCredit( $option )->GetCreditResult;
	}

	public function SendArray( $MobileNumbersArray, $Message, $SpecialNumber, $IsFlashMessage = true, $CheckingMessageID = 0 ) {

		$option = array(
			'UserName'          => $this->Username,
			'Password'          => $this->Password,
			'RecipientNumber'   => $MobileNumbersArray,
			'MessageBody'       => $Message,
			'SpecialNumber'     => $SpecialNumber,
			'IsFlashMessage'    => $IsFlashMessage,
			'CheckingMessageID' => $CheckingMessageID
		);

		$client = $this->GetClient();

		return $client->SendArray( $option )->SendArrayResult;
	}

	public function SendArraySchedule( $MobileNumbersArray, $Message, $SpecialNumber, $IsFlashMessage, $CheckingMessageID, $Year, $Month, $Day, $Hour, $Minute ) {
		$option = array(
			'UserName'          => $this->Username,
			'Password'          => $this->Password,
			'RecipientNumber'   => $MobileNumbersArray,
			'MessageBody'       => $Message,
			'SpecialNumber'     => $SpecialNumber,
			'IsFlashMessage'    => $IsFlashMessage,
			'CheckingMessageID' => $CheckingMessageID,
			'Year'              => $Year,
			'Month'             => $Month,
			'Day'               => $Day,
			'Hour'              => $Hour,
			'Minute'            => $Minute
		);
		$client = $this->GetClient();

		return $client->SendArraySchedule( $option )->SendArrayScheduleResult;
	}

	public function GetMessageID( $CheckingMessageIDArray ) {
		$option = array(
			'UserName'          => $this->Username,
			'Password'          => $this->Password,
			'CheckingMessageID' => $CheckingMessageIDArray
		);
		$client = $this->GetClient();

		return $client->GetMessageID( $option )->GetMessageIDResult;
	}

	public function GetMessageStatus( $MessageIDArray ) {
		$option = array( 'UserName' => $this->Username, 'Password' => $this->Password, 'MessageID' => $MessageIDArray );
		$client = $this->GetClient();

		return $client->GetMessageStatus( $option )->GetMessageStatusResult;
	}

	public function GetNumberGroupData() {
		$option = array( 'UserName' => $this->Username, 'Password' => $this->Password );
		$client = $this->GetClient();

		return $client->GetNumberGroupData( $option )->GetNumberGroupDataResult;
	}

	public function SendNumberGroup( $NumberGroupIDArray, $MessageBody, $SpecialNumber, $IsFlashMessage, $DontSendToRepeatedNumber ) {
		$option = array(
			'UserName'                 => $this->Username,
			'Password'                 => $this->Password,
			'NumberGroupID'            => $NumberGroupIDArray,
			'MessageBody'              => $MessageBody,
			'SpecialNumber'            => $SpecialNumber,
			'IsFlashMessage'           => $IsFlashMessage,
			'DontSendToRepeatedNumber' => $DontSendToRepeatedNumber
		);

		$client = $this->GetClient();

		return $client->SendNumberGroup( $option )->SendNumberGroupResult;
	}

	public function SendNumberGroupSchedule( $NumberGroupIDArray, $MessageBody, $SpecialNumber, $IsFlashMessage, $DontSendToRepeatedNumber, $Year, $Month, $Day, $Hour, $Minute ) {
		$option = array(
			'UserName'                 => $this->Username,
			'Password'                 => $this->Password,
			'NumberGroupID'            => $NumberGroupIDArray,
			'MessageBody'              => $MessageBody,
			'SpecialNumber'            => $SpecialNumber,
			'IsFlashMessage'           => $IsFlashMessage,
			'DontSendToRepeatedNumber' => $DontSendToRepeatedNumber,
			'Year'                     => $Year,
			'Month'                    => $Month,
			'Day'                      => $Day,
			'Hour'                     => $Hour,
			'Minute'                   => $Minute
		);

		$client = $this->GetClient();

		return $client->SendNumberGroupSchedule( $option )->SendNumberGroupScheduleResult;
	}

	public function InsertNumberInNumberGroup( $NumberGroupID, $PersonNumberArray, $PersonNameArray ) {
		$option = array(
			'UserName'      => $this->Username,
			'Password'      => $this->Password,
			'NumberGroupID' => $NumberGroupID,
			'PersonNumber'  => $PersonNumberArray,
			'PersonName'    => $PersonNameArray
		);

		$client = $this->GetClient();

		return $client->InsertNumberInNumberGroup( $option )->InsertNumberInNumberGroupResult;
	}

	public function GetInboxMessage( $NumberOfMessage ) {
		$option = array(
			'UserName'        => $this->Username,
			'Password'        => $this->Password,
			'NumberOfMessage' => $NumberOfMessage
		);

		$client = $this->GetClient();

		return $client->GetInboxMessage( $option )->GetInboxMessageResult;
	}

	public function GetInboxMessageWithNumber( $NumberOfMessage, $SpecialNumber ) {
		$option = array(
			'UserName'        => $this->Username,
			'Password'        => $this->Password,
			'NumberOfMessage' => $NumberOfMessage,
			'SpecialNumber'   => $SpecialNumber
		);

		$client = $this->GetClient();

		return $client->GetInboxMessageWithNumber( $option )->GetInboxMessageWithNumberResult;
	}

	public function GetInboxMessageWithInboxID( $NumberOfMessage, $InboxID, $IsReaded ) {
		$option = array(
			'UserName'        => $this->Username,
			'Password'        => $this->Password,
			'NumberOfMessage' => $NumberOfMessage,
			'InboxID'         => $InboxID,
			'IsReaded'        => IsReaded
		);

		$client = $this->GetClient();

		return $client->GetInboxMessageWithInboxID( $option )->GetInboxMessageWithInboxIDResult;
	}

	public function GetUserInfo() {
		$option = array( 'UserName' => $this->Username, 'Password' => $this->Password );

		$client = $this->GetClient();

		return $client->GetUserInfo( $option )->GetUserInfoResult;
	}

	/**
	 * @param string $Username
	 */
	public function setUsername( $Username ) {

		$this->Username = $Username;
	}

	/**
	 * @return string
	 */
	public function getPassword() {

		return $this->Password;
	}

	/**
	 * @param string $Password
	 */
	public function setPassword( $Password ) {

		$this->Password = $Password;
	}

	/**
	 * @return string
	 */
	public function getUsername() {

		return $this->Username;
	}

	/**
	 * @inhertDoc
	 *
	 * @param string $mobile
	 * @param string $username
	 * @param string $message
	 *
	 * @return bool
	 */
	public function send( string $mobile, string $username, string $message ): bool {

		$expert_sms_options = get_option( 'save_settings' ) ? : get_option('expert_sms_settings');

		if ( is_null( $message ) ) {
			return false;
		}

		$sun_way = new SunWayService();

		$message = str_replace( '%name%', $username, $message );
		$message = str_replace( "%E", PHP_EOL, $message );

		$sun_way->setUsername( $expert_sms_options['webservice_username'] );

		$sun_way->setPassword( $expert_sms_options['webservice_password'] );

		$sun_way->SendArray( [ $mobile ], $message, $expert_sms_options['webservice_number'] );

		return true;
	}
}

