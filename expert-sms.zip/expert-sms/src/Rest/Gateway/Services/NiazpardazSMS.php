<?php

namespace ExpertSMS\Rest\Gateway\Services;

/**
 * Class NiazpardazSMS
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Rest\Gateway\Services
 */
class NiazpardazSMS implements AllowSMS {

	public function send( string $mobile, string $username, string $message ): bool {

		ini_set( "soap.wsdl_cache_enabled", "0" );

		$expert_sms_options = get_option( 'save_settings' ) ? : get_option( 'expert_sms_settings' );

		if ( is_null( $message ) ) {

			return false;
		}

		$text = str_replace( [ '%name%', "%E" ], [ $username, PHP_EOL ], $message );

		$sms_client = new \SoapClient( 'http://payamak-service.ir/SendService.svc?wsdl', [ 'encoding' => 'UTF-8' ] );

		try {

			$parameters['userName']       = $expert_sms_options['webservice_username'];
			$parameters['password']       = $expert_sms_options['webservice_password'];
			$parameters['fromNumber']     = $expert_sms_options['webservice_number'];
			$parameters['toNumbers']      = [ $mobile ];
			$parameters['messageContent'] = $text;
			$parameters['isFlash']        = false;

			$sms_client->SendSMS( $parameters );

		} catch ( \Exception $e ) {
			
			return false;
		}

		return true;
	}
}