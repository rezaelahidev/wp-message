<?php

namespace ExpertSMS\Rest\Gateway\Services;

/**
 * Class PayamResan
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Rest\Gateway\Services
 */
class PayamResanService implements AllowSMS {

	/**
	 * @inhertDoc
	 *
	 * @param string $mobile
	 * @param string $username
	 * @param string $message
	 *
	 * @return bool
	 */
	public function send( string $mobile, string $username, string $message ): bool {

		$expert_sms_options = get_option( 'save_settings' ) ? : get_option('expert_sms_settings');

		try {

			$client = new \SoapClient( 'https://www.payam-resan.com/ws/v2/ws.asmx?WSDL' );

			$parameters['Username']         = $expert_sms_options['webservice_username'];
			$parameters['PassWord']         = $expert_sms_options['webservice_password'];
			$parameters['SenderNumber']     = $expert_sms_options['webservice_number'];
			$parameters['RecipientNumbers'] = array( $mobile );
			$parameters['MessageBodie']     = str_replace( '%name%', $username, $message );
			$parameters['MessageBodie']     = str_replace( "%E", PHP_EOL, $parameters['MessageBodie'] );
			$parameters['Type']             = 1;
			$parameters['AllowedDelay']     = 0;

			$client->SendMessage( $parameters );

		} catch ( \SoapFault $ex ) {

			echo $ex->getMessage();

			return false;
		}

		return true;
	}
}
