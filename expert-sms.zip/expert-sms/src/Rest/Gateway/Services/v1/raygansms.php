<?php
//http://newsms.ir/API/default.aspx
$expert_sms_options = get_option( 'save_settings' ) ? : get_option('expert_sms_settings');
// turn off the WSDL cache
ini_set( "soap.wsdl_cache_enabled", "0" );
function expert_sms_send_sms_simple( $mobile, $username, $message ) {

	global $expert_sms_options;

	if ( is_null( $message ) ) {

		return false;
	}

	try {

		$user    = $expert_sms_options['webservice_username'];
		$pass    = $expert_sms_options['webservice_password'];
		$from    = $expert_sms_options['webservice_number'];
		$message = str_replace( '%name%', $username, $message );
		$message = str_replace( "%E", PHP_EOL, $message );
		$url     = 'https://raygansms.com/SendMessageWithUrl.ashx';

		$remote = wp_remote_get( add_query_arg( [
			'Username'    => $user,
			'Password'    => $pass,
			'PhoneNumber' => $from,
			'MessageBody' => $message,
			'RecNumber'   => $mobile,
			'Smsclass'    => 1,
		], $url ) );

		if ( is_wp_error( $remote ) ) {

			return false;
		}

		return wp_remote_retrieve_body( $remote );

	} catch ( Exception $e ) {

		return $e;
	}
}
