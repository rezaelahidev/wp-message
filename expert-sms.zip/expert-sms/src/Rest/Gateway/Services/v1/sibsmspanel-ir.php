<?php
$expert_sms_options = get_option( 'save_settings' ) ? : get_option('expert_sms_settings');
// turn off the WSDL cache
ini_set( "soap.wsdl_cache_enabled", "0" );
function expert_sms_send_sms_simple( $mobile, $username, $message ) {
	global $expert_sms_options;
	if ( is_null( $message ) ) {
		return false;
	}
	try {
		$client                 = new SoapClient( 'http://ippanel.com/class/sms/wsdlservice/server.php?wsdl', array( 'encoding' => 'UTF-8' ) );
		$parameters['fromNum']     = $expert_sms_options['webservice_number'];
		$parameters['toNum']       = [ $mobile ];
		$parameters['user'] = $expert_sms_options['webservice_username'];
		$parameters['pass'] = $expert_sms_options['webservice_password'];
		$parameters['messageContent']     = str_replace( '%name%', $username, $message );
		$parameters['messageContent']     = str_replace( "%E", PHP_EOL, $parameters['messageContent'] );
		$parameters['isflash']  = true;
		$parameters['udh']      = "";
		$parameters['recId']    = array( 0 );
		$parameters['status']   = 0x0;
		$patternCode = "104";
		$inputData = [
			'validation_code' => '12588',
			'login_code' => 'rewwwe14',
			'tracking_code' => 'qxq3ecv'
		];
		echo $client->SendSms(
			$parameters['fromNum'],
			$parameters['toNum'],
			$parameters['messageContent'],
			$parameters['user'],
			$parameters['pass']
		)->SendSmsResult;

		return true;
	} catch ( SoapFault $ex ) {
		echo $ex->faultstring;
	}
}