<?php
//http://newsms.ir/API/default.aspx
$expert_sms_options = get_option( 'save_settings' ) ? : get_option('expert_sms_settings');
// turn off the WSDL cache
ini_set( "soap.wsdl_cache_enabled", "0" );
function expert_sms_send_sms_simple( $mobile, $username, $message ) {
	global $expert_sms_options;
	if ( is_null( $message ) ) {
		return false;
	}
	$user = $expert_sms_options['webservice_username'];
	$pass = $expert_sms_options['webservice_password'];
	$from    = $expert_sms_options['webservice_number'];
	$text     = str_replace( '%name%', $username, $message );
	$text     = str_replace( "%E", PHP_EOL, $text );
	$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL,"http://newsms.ir/api/");
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS,
		"action=SMS_SEND&username=$user&password=$pass&api=1&from=$from&API_CHANGE_ALLOW=true&to=$mobile&FLASH=0&text=$text");

// Receive server response ...
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	$server_output = curl_exec($ch);

	curl_close ($ch);
	return $server_output;
}

//http://newsms.ir/api/?action=SMS_SEND&username=user&password=110110&api=1&from=30001699&API_CHANGE_ALLOW=true&to=+989104457956&FLASH=0&text=test

