<?php
$expert_sms_options = get_option( 'save_settings' ) ? : get_option('expert_sms_settings');
// turn off the WSDL cache
ini_set( "soap.wsdl_cache_enabled", "0" );
function expert_sms_send_sms_simple( $mobile, $username, $message ) {
	global $expert_sms_options;
	if ( is_null( $message ) ) {
		return false;
	}
	try {
		$client                 = new SoapClient( 'http://87.107.121.52/post/send.asmx?wsdl', array( 'encoding' => 'UTF-8' ) );
		$parameters['username'] = $expert_sms_options['webservice_username'];
		$parameters['password'] = $expert_sms_options['webservice_password'];
		$parameters['from']     = $expert_sms_options['webservice_number'];
		$parameters['to']       = [ $mobile ];
		$parameters['text']     = str_replace( '%name%', $username, $message );
		$parameters['text']     = str_replace( "%E", PHP_EOL, $parameters['text'] );
		$parameters['isflash']  = true;
		$parameters['udh']      = "";
		$parameters['recId']    = array( 0 );
		$parameters['status']   = 0x0;
		$client->SendSms( $parameters )->SendSmsResult;

		return true;
	} catch ( SoapFault $ex ) {
		echo $ex->faultstring;
	}
}