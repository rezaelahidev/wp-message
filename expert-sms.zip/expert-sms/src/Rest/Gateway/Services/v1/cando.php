<?php
$expert_sms_options = get_option( 'save_settings' ) ? : get_option('expert_sms_settings');
require_once SMS_INC . 'nusoap.php';
function expert_sms_cando_send( $mobile, $username, $message ) {
	global $expert_sms_options;
	if ( is_null( $message ) ) {
		return false;
	}

	$client                   = new nusoap_client( 'http://my.candoosms.com/services/?wsdl', true );
	$client->soap_defencoding = 'UTF-8';
	$client->decode_utf8      = true;
	$err                      = $client->getError();
	if ( $err ) {
		echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
	}
//		Init Variables
	$srcNumbers[] = '9830007904168253';
	$bodys      = str_replace( [ '%name%', '%E' ], [ $username, PHP_EOL ], $message );
	$flashs[]     = '0';

// /* == send multiple ==============
//	foreach ( $bodys as $body ) {
//		foreach ( $mobile as $value ) {
//			$result = $client->call(
//				'Send',
//				array(
//					'username'  => $expert_sms_options['webservice_username'],
//					'password'  => $expert_sms_options['webservice_password'],
//					'srcNumber' => $expert_sms_options['webservice_number'],
//					'body'      => $body,
//					'destNo'    => $value,
//					'flash'     => '0'
//				)
//			);
//		}
//	}
		$result = $client->call(
			'Send',
			array(
				'username'  => $expert_sms_options['webservice_username'],
				'password'  => $expert_sms_options['webservice_password'],
				'srcNumber' => $expert_sms_options['webservice_number'],
				'body'      => $bodys,
				'destNo'    => [$mobile],
				'flash'     => '0'
			)
		);
// */


//end send sample


	/*

	//get Balance Sample...

	$result = $client->call ( 'Balance',array('username'=>'test','password'=>'test'));

	if ($client->fault) {
		echo '<h2>Fault</h2><pre>';
		print_r($result);
		echo '</pre>';
	} else {
		$err = $client->getError();
		if ($err) {
			echo '<h2>Error</h2><pre>' . $err . '</pre>';
		} else {
			echo $result;
		}
	}
	*/

	return true;
	if ( $client->fault ) {
		echo '<h2>Fault</h2><pre>';
		print_r( $result );
		echo '</pre>';
	} else {
		$err = $client->getError();
		if ( $err ) {
			echo '<h2>Error</h2><pre>' . $err . '</pre>';
		} else {
			foreach ( $result as $value ) {
				print_r( $value );
			}
		}
	}


}
