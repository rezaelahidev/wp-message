<?php

$expert_sms_options = get_option( 'save_settings' ) ? : get_option('expert_sms_settings');

ini_set( "soap.wsdl_cache_enabled", "0" );
function expert_sms_send_sms_simple( $mobile, $username, $message ) {

	global $expert_sms_options;


	if ( empty( $message ) ) {

		return false;
	}

	try {

		$user    = $expert_sms_options['webservice_username'];
		$pass    = $expert_sms_options['webservice_password'];
		$fromNum = $expert_sms_options['webservice_number'];
		$toNum   = [ $mobile ];

		if ( $expert_sms_options['pattern'] ) {

			$client = new SoapClient( "http://ippanel.com/class/sms/wsdlservice/server.php?wsdl" );

			$input_data = array( "verification-code" => $message, "name" => $username );

			ob_start();

			echo $client->sendPatternSms(
				$fromNum,
				$toNum,
				$user,
				$pass,
				$expert_sms_options['code_pattern'],
				$input_data
			);

			$status = ob_get_clean();

		} else {

			$client = new SoapClient( "http://ippanel.com/class/sms/wsdlservice/server.php?wsdl" );

			$message        = str_replace( '%name%', $username, $message );
			$messageContent = str_replace( "%E", PHP_EOL, $message );
			$op             = "send";
			//If you want to send in the future  ==> $time = '2016-07-30' //$time = '2016-07-30 12:50:50'

			$time = strtotime( "-5 minutes" );

			$status = $client->SendSMS( $fromNum, $toNum, $messageContent, $user, $pass, $time, $op );
		}

		return true;

	} catch ( SoapFault $ex ) {
		echo $ex->faultstring;
	}

	return false;
}
