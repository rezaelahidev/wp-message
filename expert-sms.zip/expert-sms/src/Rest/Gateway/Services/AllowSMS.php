<?php

namespace ExpertSMS\Rest\Gateway\Services;

/**
 * Interface AllowSMS
 * @package ExpertSMS\Rest\Gateway\Services
 */
interface AllowSMS {

	/**
	 * Send sms message with user info.
	 *
	 * @param string $mobile
	 * @param string $username
	 * @param string $message
	 *
	 * @since 6.0.0
	 * @return bool
	 */
	public function send( string $mobile, string $username, string $message ): bool;
}