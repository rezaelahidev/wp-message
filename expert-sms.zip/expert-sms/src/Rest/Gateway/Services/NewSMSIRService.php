<?php

namespace ExpertSMS\Rest\Gateway\Services;

/**
 * Class NewSMSIRService
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Rest\Gateway\Services
 */
class NewSMSIRService implements AllowSMS {

	/**
	 * @inhertDoc
	 *
	 * @param string $mobile
	 * @param string $username
	 * @param string $message
	 *
	 * @return bool
	 */
	public function send( string $mobile, string $username, string $message ): bool {

		$expert_sms_options = get_option( 'save_settings' ) ? : get_option('expert_sms_settings');

		if ( is_null( $message ) ) {
			return false;
		}
		$user = $expert_sms_options['webservice_username'];
		$pass = $expert_sms_options['webservice_password'];
		$from = $expert_sms_options['webservice_number'];
		$text = str_replace( '%name%', $username, $message );
		$text = str_replace( "%E", PHP_EOL, $text );
		$ch   = curl_init();

		curl_setopt( $ch, CURLOPT_URL, "http://newsms.ir/api/" );
		curl_setopt( $ch, CURLOPT_POST, 1 );
		curl_setopt( $ch, CURLOPT_POSTFIELDS,
			"action=SMS_SEND&username=$user&password=$pass&api=1&from=$from&API_CHANGE_ALLOW=true&to=$mobile&FLASH=0&text=$text" );

		// Receive server response ...
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );

		$server_output = curl_exec( $ch );

		curl_close( $ch );

		return $server_output;

		return true;
	}
}