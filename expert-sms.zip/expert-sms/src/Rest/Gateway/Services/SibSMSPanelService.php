<?php

namespace ExpertSMS\Rest\Gateway\Services;

/**
 * Class SibSMSPanelService
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Rest\Gateway\Services
 */
class SibSMSPanelService implements AllowSMS {

	/**
	 * @inhertDoc
	 *
	 * @param string $mobile
	 * @param string $username
	 * @param string $message
	 *
	 * @return bool
	 */
	public function send( string $mobile, string $username, string $message ): bool {

		$expert_sms_options = get_option( 'save_settings' ) ? : get_option('expert_sms_settings');

		if ( is_null( $message ) ) {
			return false;
		}
		try {
			$client                       = new \SoapClient( 'http://ippanel.com/class/sms/wsdlservice/server.php?wsdl', array( 'encoding' => 'UTF-8' ) );
			$parameters['fromNum']        = $expert_sms_options['webservice_number'];
			$parameters['toNum']          = [ $mobile ];
			$parameters['user']           = $expert_sms_options['webservice_username'];
			$parameters['pass']           = $expert_sms_options['webservice_password'];
			$parameters['messageContent'] = str_replace( '%name%', $username, $message );
			$parameters['messageContent'] = str_replace( "%E", PHP_EOL, $parameters['messageContent'] );
			$parameters['isflash']        = true;
			$parameters['udh']            = "";
			$parameters['recId']          = array( 0 );
			$parameters['status']         = 0x0;
			$patternCode                  = "104";
			$inputData                    = [
				'validation_code' => '12588',
				'login_code'      => 'rewwwe14',
				'tracking_code'   => 'qxq3ecv'
			];
			echo $client->SendSms(
				$parameters['fromNum'],
				$parameters['toNum'],
				$parameters['messageContent'],
				$parameters['user'],
				$parameters['pass']
			)->SendSmsResult;

		} catch ( \SoapFault $ex ) {
			echo $ex->faultstring;

			return false;
		}

		return true;
	}
}