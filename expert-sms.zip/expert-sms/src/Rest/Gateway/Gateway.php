<?php

namespace ExpertSMS\Rest\Gateway;

/**
 * Class Gateway
 *
 * @since   6.0.0
 *
 * @package ExpertSMS\Rest\Gateway
 */
final class Gateway {

	/**
	 *
	 * TODO
	 *
	 * @var
	 */
	protected $response;

	/**
	 * Gateway constructor.
	 *
	 * @param callable         $callback
	 * @param \WP_REST_Request $request
	 *
	 * @since 6.0.0
	 */
	public function __construct( callable $callback, \WP_REST_Request $request ) {

		if ( ! is_callable( $callback ) ) {

			throw new \RuntimeException( __( sprintf(
				'Fatal Error: call to undefined function "%s" from %s Class',
				$callback[1] ?? 'Not Founded',
				$callback[0] ?? 'Not Founded'
			), 'expert-sms' ) );
		}

		// turn off the WSDL cache
		ini_set( "soap.wsdl_cache_enabled", "0" );

		$this->response = call_user_func(
			$callback,
			(string) $request->get_param( 'mobile' ),
			(string) $request->get_param( 'user' ),
			(string) $request->get_param( 'message' )
		);
	}

	public function get_response() {

		return $this->response;
	}
}