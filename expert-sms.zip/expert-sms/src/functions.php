<?php


/**
 * Registration all short codes.
 *
 * @since 5.0.0
 */
function expert_sms_register_short_codes() {

	include SMS_INC . 'shortcodes/post-shortcode.php';
	include SMS_INC . 'shortcodes/download-shortcode.php';
	include SMS_INC . 'shortcodes/product-shortcode.php';
	include SMS_INC . 'shortcodes/signin-shortcode.php';
	include SMS_INC . 'shortcodes/signup-shortcode.php';
}


/**
 * Create Random number
 *
 * @param $length
 *
 * @since 5.3.0
 *
 * @return string
 */
function random_number( $length ) {

	$result = '';

	for ( $i = 0; $i < $length; $i ++ ) {

		$result .= mt_rand( 0, 9 );
	}

	return $result;
}

/**
 * @param $mobile
 * @param $code
 *
 * @since 5.3.0
 *
 * @return bool true | false
 */
function send_verify_code( $mobile, $code, \ExpertSMS\Controllers\HooksController $hooks ) {

	global $wpdb, $expert_sms_options;

	$result = false;

	if ( empty( $mobile ) ) {

		return false;
	}

	$username = get_user_by( 'login', $mobile );

	if ( ! $username ) {

		return false;
	}

	$message = 'کد تایید برای ورود به ' . get_bloginfo( 'name' ) . ' : ' . PHP_EOL . $code;

	if ( ! empty( $expert_sms_options['pattern'] ) ) {

		$message = $code;
	}

	$tracked_mobile = $wpdb->get_row( $wpdb->prepare( "
						SELECT mobile FROM {$wpdb->prefix}user_verification
						WHERE mobile LIKE %s
						", $mobile ) );

	$result = $hooks->send(
		[
			'mobile'    => $mobile,
			'message'   => $message,
			'user_name' => $username->display_name,
		]
	);

	if ( $result ) {

		if ( is_null( $tracked_mobile ) ) {

			$record = $wpdb->insert( $wpdb->prefix . 'user_verification', [
				'mobile' => $mobile,
				'code'   => $code,
			], [ '%s', '%s' ] );

		} else {

			$record = $wpdb->update( $wpdb->prefix . 'user_verification', [
				'mobile' => $mobile,
				'code'   => $code,
			], [ 'mobile' => $mobile ], [ '%s', '%s' ] );
		}

		if ( is_wp_error( $record ) ) {

			return false;
		}

		return true;
	}

	return false;
}

/**
 * @param $mobile
 *
 * @since 5.3.0
 * @return bool
 */
function validate_mobile_number( $mobile ) {

	if ( empty( $mobile ) || strlen( $mobile ) < 11 ) {

		return false;
	}

	$pattern = '/^[0-9\-\(\)\/\+\s]*$/';

	if ( ! preg_match( $pattern, $mobile ) ) {

		return false;
	}

	return true;
}

/**
 * @param $product_id
 *
 * @since 1.0.0
 * @return bool true on success,false when otherwise.
 */
function is_product_quantity_status( $product_id ) {

	$product = wc_get_product( $product_id );

	// Default value true
	$status = true;

	$stock_quantity = $product->get_stock_quantity();

	if ( is_null( $stock_quantity ) || $stock_quantity === 0 ) {

		$status = false;
	}

	if ( $product->get_stock_status() === 'instock' ) {

		$status = true;
	}

	return $status;
}

if ( ! function_exists( 'update_post_followers' ) ) {

	/**
	 * @param $post_id
	 * @param $followers
	 *
	 * @since 5.8.2
	 */
	function update_post_followers( $post_id, $followers ) {

		update_post_meta( $post_id, 'user_count', $followers );

		if ( $followers >= 1 && $followers <= 100 ) {

			update_post_meta( $post_id, 'range_of_count_users', 'range_1_100' );
		}
		if ( $followers >= 101 && $followers <= 200 ) {

			update_post_meta( $post_id, 'range_of_count_users', 'range_101_200' );
		}
		if ( $followers >= 201 && $followers <= 300 ) {

			update_post_meta( $post_id, 'range_of_count_users', 'range_201_300' );
		}
		if ( $followers >= 301 ) {

			update_post_meta( $post_id, 'range_of_count_users', 'range_300_up' );
		}
	}
}
