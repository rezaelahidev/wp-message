<a href="#" id="newsletter-btn"
   class="<?php echo $expert_sms_options['theme'] ?> newsletter-btn-class"><?php echo $attrs['title'] ?></a>
<div aria-labelledby="dialog_title" class="dialog" role="dialog">
	<div class="dialog__window" role="document">
		<header class="<?php echo $expert_sms_options['theme'] . '-header' ?> dialog__header" role="banner">
			<h2 class="dialog__title"><?php echo !empty($expert_sms_options['popup_title']) ? $expert_sms_options['popup_title'] : $attrs['dialog_heading'] ?></h2>
            <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                 viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
<g>
    <g>
        <polygon points="512,59.076 452.922,0 256,196.922 59.076,0 0,59.076 196.922,256 0,452.922 59.076,512 256,315.076 452.922,512
			512,452.922 315.076,256 		"/>
    </g>
</g>
                <g>
                </g>
                <g>
                </g>
                <g>
                </g>
                <g>
                </g>
                <g>
                </g>
                <g>
                </g>
                <g>
                </g>
                <g>
                </g>
                <g>
                </g>
                <g>
                </g>
                <g>
                </g>
                <g>
                </g>
                <g>
                </g>
                <g>
                </g>
                <g>
                </g>
</svg>
		</header>
		<div class="dialog__body">
			<form id="post_newsletter" action="<?php echo $_SERVER['REQUEST_URI'] ?>" method="post">
				<p id="edd-phone-wrap">
				<div id="myDIV">
					<span class="edd-description exp-sms-desc-field"><?php echo $attrs['description'] ?></span>
					<?php if ( $attrs['name'] == true && ! is_user_logged_in() ): ?>
						<input class="edd-input exp-sms-mobile-input" type="text" id="sms_username" name="sms_username"
						       placeholder="<?php echo 'نام و نام خانوادگی (الزامی)' ?>">
					<?php endif; ?>
					<input class="edd-input exp-sms-mobile-input" type="text" name="mobile" id="mobile"
					       placeholder="0912 XXX XX XX"/>
					<?php wp_nonce_field( 'register_mobile', 'register_mobile_nonce' ); ?>
					<button
						data-username="
                    <?php $user = wp_get_current_user();
						echo empty( $user ) ? false : $user->user_login; ?>"
						data-did="<?php echo get_the_ID(); ?>"
						name="submit"
						id="register_download_news"
						class="<?php echo isset($expert_sms_options['theme']) ? $expert_sms_options['theme'] : '' ?> submit-subscribe"
						style="display: inline-block"
					>
						 عضویت در خبرنامه پیامکی
					</button>
					<img class="loading" src="<?php echo SMS_ASS_IMG . 'ajax-loader.gif' ?>" alt="loading">
					<div id="loadFacebookG">
						<div id="blockG_1" class="facebook_blockG"></div>
						<div id="blockG_2" class="facebook_blockG"></div>
						<div id="blockG_3" class="facebook_blockG"></div>
					</div>
					<div class="alert-success"></div>
					<div class="alert-danger"></div>
				</div>
				</p>
			</form>
		</div>
	</div>
	<div class="dialog__mask"></div>
</div>