<style>
    * {
        direction: rtl
    }

    .about-wrap {
        margin: 15px;
        background-color: #fff;
        border: 1px solid #ccc;
        width: auto;
        font-family: 'IRANSans', Arial, sans-serif, tahoma;
    }

    a {
        text-decoration: none;
    }

    .wpbadge {
        padding: 10px;
        border-bottom: 1px solid #ccc;
        overflow: hidden;
        line-height: 1.7;
    }

    .wpbadge h1 {
        font-size: 24px;
        font-family: 'IRANSans', Arial, sans-serif, tahoma !important;
        color: #27ae60;
        line-height: 152px;
    }

    .wpbadge img {
        float: left;
        border: 1px solid #ccc;
        -webkit-border-radius: 50%;
        -moz-border-radius: 50%;
        border-radius: 50%;
    }

    .help-panel-content {
        padding: 10px 15px;
        overflow: hidden;
        line-height: 1.7;
        font-size: 10pt;
        text-align: justify;
    }

    .help-panel-content p {
        font-size: 10pt;
        line-height: 1.7;
    }

    .help-panel-content h2 {
        font-family: 'IRANSans', Arial, sans-serif, tahoma;
        color: #27ae60;
    }

    .code {
        margin: 5px 0;
        text-align: left;
    }

    .code span {
        background-color: #e5e5e5;
        padding: 3px;
    }

    .about-wrap h2 {
        text-align: right !important;
    }
</style>
<div id="welcome-panel" class="about-wrap">
    <div class="wpbadge">
        <img src="why-sms-panel.png" width="152"/>

        <h1>راهنمای تنظیمات و استفاده از افزونه خبرنامه ارسال SMS</h1>
    </div>
    <div class="help-panel-content">
        <h2>پیشگفتار</h2>
        <strong>قبل از هرچیزی ذکر این نکته ضروریست که در زمانی که افزونه را فعالسازی کردید ممکن است در منوی "سیستم پیام
            کوتاه" و "دانلودها" هیچ آیتمی وجود نداشته باشد برای مشاهده فقط کافیست اطلاعات وارد کنید .</strong>
        <p>با سلام خدمت شما کاربر گرامی لطفا با دنبال کردن این راهنما افزونه را به خوبی اجرا و راه اندازی کنید .این
            افزونه که با نام "خبرنامه ارسال SMS" ارائه شده است ، دارای 2 جدول در دیتا بیس می باشد یکی برای خبرنامه نوشته
            ها و یکی برای خبرنامه دانلود ها می باشد . برای درج اطلاعات توسط کاربران در دیتابیس این افزونه شورتکدهایی را
            در اختیار شما می گذارد .
            <br>
            شورتکد : <code>[smsNewsletters title="لطفاً عنوان خبرنامه را وارد کنید " name="false" description="متن
                توضیحات
                "]</code>
            برای نمایش خبرنامه در صفحه نوشته ها به کار میرود .
        </p>
        <br>
        شورتکد : <code>[smsNewslettersDownload title="لطفاً عنوان خبرنامه را وارد کنید " name="false" description="متن
            توضیحات "]</code>
        برای نمایش خبرنامه در صفحه دانلود ها به کار گرفته شده است .
        </p>
        <h2>استفاده از شورتکدها</h2>
        <p>
            شورتکد نوشته ها در آیتم مربوط به افزودن نوشته در بالای نوار ابزار ویرایشگر وردپرس با استفاده از منوی خبرنامه
            قابل دسترس می باشد .لذا برای کپی کردن شورتکد کافیست بر روی منوی خبرنامه و "خبرنامه نوشته ها" کلیک شود . پس
            از آن شما می توانید با وارد کردن دیتا های خواسته شده شورتکد خود را سفارشی سازی کنید .
            در رابطه با شورتکد مربوط به محصولات دانلودی کافیست رویه ی قبل را در آیتم افزودن دانلود دنبال کنید و با
            استفاده از منو خبرنامه بخش "خبرنامه دانلود" را کلیک و کپی کنید .
        </p>
        <h2>آیتم های افزونه</h2>
        <strong>متاباکس "نمایش کاربران یک دسته بندی"</strong>
        <ol>
            <li><b>بخش افزودن نوشته</b><br>
                شما از طریق این متاباکس می توانید کلیه کاربران عضو یک دسته بندی خاص را از دیتابیس دریافت کنید و بصورت
                دلخواه به هریک از کاربران پیامک ارسال کنید و یا اینکه همه ی کاربران عضو آن دسته بندی را انتخاب کرده و یک
                پیامکی کلی پس بروز رسانی نوشته برای آن ها ارسال کنید .
            </li>
            <li><b>بخش افزودن دانلود</b><br/>
                متاباکس مربوط به این صفحه نیز کاملاً مشابه قسمت قبلی عمل می کند .
            </li>
        </ol>
        <strong>سیستم پیام کوتاه و منوی "دانلودها" در منوی اصلی افزونه</strong>
        <ol>
            <li><b>نمایش کلیه کاربران عضو نوشته ها و دانلود ها</b><br>
                در این بخش همانند متاباکس ها می توانید پیام کوتاه ارسال کنید اما اصلی ترین تفائت این بخش این است که شما
                کلیه کاربران عضو در 2 بخش نوشته ها و دانلودها را در اختیار داشته و از طریق ابزارهای انتخاب ، حذف ،
                ویرایش و ارسال پیامک تکی می توانید عملیات مختلف را برای کاربران و پیام کوتاه انجام دهید .
            </li>
        </ol>
        <video width="400" controls>
            <source src="Rec 0013.mp4" type="video/mp4">
            ویدیوی آموزشی
        </video>
        <strong style="color: #8BC34A">نکته قابل توجه !! از شورتکد دانلود می توانید برای بخش صفحه پرداخت استفاده کنید .
            در ضمن ویژگی name را با مقدار دهی True می توانید به کاربرانی که در سایت لاگین نکرده اند نمایش بدهید و به محض
            وارد کردن نام و نام خانوادگی توسط کاربر وی عضوی از کاربران اصلی سایت خواهد شد !</strong>
        <p style="text-align: center;">
            باتشکر از صبر و حوصله ی شما
            <strong style="color: #e91e63">Reza Wordpress Full Stack Developer</strong>
        </p>

    </div>
