<?php $expert_sms_options = get_option( 'expert_sms_settings' ); ?>
<div class="wrap exp-sms exp-sms-relative">
    <h1>تنظیمات خبرنامه پیامکی</h1>
    <nav class="nav-tab-wrapper">
		<?php foreach ( $tabs as $tab_name => $tab ): ?>
            <a href="<?php echo admin_url() . 'admin.php?page=sms_settings.php&tab=' . $tab_name; ?>"
               class="nav-tab <?php echo isset($_GET['tab']) && $tab_name === $_GET['tab'] ? 'nav-tab-active' : '' ?>">
				<?php echo $tab; ?>
            </a>
		<?php endforeach; ?>
    </nav>
    <form action="" method="post">
        <table class="form-table">
            <tbody>
            <tr>
                <th scope="row">
                    <label for="webservice_username">نام کاربری وب سرویس :</label>
                </th>
                <td>
                    <input
                            type="text"
                            class="input-text"
                            name="webservice_username"
                            id="webservice_username"
                            value="<?php echo isset($expert_sms_options['webservice_username']) ? $expert_sms_options['webservice_username'] : '' ?>"
                            placeholder="نام کاربری وب سرویس"
                    >
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="webservice_password">رمز عبور وب سرویس :</label>
                </th>
                <td>
                    <input
                            type="text"
                            class="input-text"
                            name="webservice_password"
                            id="webservice_password"
                            value="<?php echo isset($expert_sms_options['webservice_password']) ? $expert_sms_options['webservice_password'] : '' ?>"
                            placeholder="رمز عبور وب سرویس"
                    >
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="webservice_number">شماره خط وب سرویس :</label>
                </th>
                <td>
                    <input
                            type="text"
                            class="input-text"
                            name="webservice_number"
                            id="webservice_number"
                            value="<?php echo isset($expert_sms_options['webservice_number']) ? $expert_sms_options['webservice_number'] : '' ?>"
                            placeholder="شماره خط وب سرویس"
                    >
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="API_KEY">کلید API :</label>
                </th>
                <td>
                    <input
                            type="text"
                            class="input-text"
                            name="API_KEY"
                            id="API_KEY"
                            value="<?php echo isset($expert_sms_options['API_KEY']) ? $expert_sms_options['API_KEY'] : '' ?>"
                            placeholder="کلید API"
                    >
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="secret_key">کد امنیتی :</label>
                </th>
                <td>
                    <input
                            type="text"
                            class="input-text"
                            name="secret_key"
                            id="secret_key"
                            value="<?php echo isset( $expert_sms_options['secret_key']) ?  $expert_sms_options['secret_key'] : '' ?>"
                            placeholder="کد امنیتی"
                    >
                </td>
            </tr>
            <tr>
	            <th scope="row">
		            <label for="pattern">ارسال براساس پترن :</label>
	            </th>
	            <td>
		            <input
				            type="text"
				            class="input-text"
				            name="pattern"
				            id="pattern"
				            value="<?php echo isset( $expert_sms_options['pattern']) ?  $expert_sms_options['pattern'] : '' ?>"
				            placeholder="مثال : %name% کد تایید شما %verification-code% نام شرکت"
		            >
	            </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="pattern">کد پترن :</label>
                </th>
                <td>
                    <input
                            type="text"
                            class="input-text"
                            name="code_pattern"
                            id="code_pattern"
                            value="<?php echo isset( $expert_sms_options['code_pattern']) ?  $expert_sms_options['code_pattern'] : '' ?>"
                            placeholder="pattern code"
                    >
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="expert_sms_webservice">وب سرویس :</label>
                </th>
                <td class="exp-sms-webservices">
					<?php foreach ( $webservices as $webservice => $value ): ?>
                        <div class="switch-row">
                            <span class="label-switch"><?php echo $value ?></span>
                            <label class="switch">
                                <input
                                        type="radio"
                                        name="webservice"
                                        id="webservice"
                                        value="<?php echo $webservice ?>"
									<?php echo isset($expert_sms_options['webservice']) ? checked( $expert_sms_options['webservice'], $webservice ) : ''?>
                                >
                                <span class="slider"></span>
                            </label>
                        </div>
					<?php endforeach; ?>
                </td>
            </tr>
            </tbody>
			<?php wp_nonce_field( 'save_setting_action', 'save_setting_nonce' ); ?>
        </table>
		<?php submit_button( 'ذخیره تنظیمات', 'primary', 'save_settings' ); ?>
    </form>
</div>