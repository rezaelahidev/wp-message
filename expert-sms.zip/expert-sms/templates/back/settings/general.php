<?php $expert_sms_options = get_option( 'expert_sms_settings' ); ?>
<div class="wrap exp-sms exp-sms-relative">
    <h1>تنظیمات خبرنامه پیامکی</h1>
    <nav class="nav-tab-wrapper">
		<?php foreach ( $tabs as $tab_name => $tab ): ?>
            <a href="<?php echo admin_url() . 'admin.php?page=sms_settings.php&tab=' . $tab_name; ?>"
               class="nav-tab <?php echo ( isset( $_GET['tab'] ) && $tab_name === $_GET['tab'] ) || ( !isset( $_GET['tab'] ) && $tab_name === 'general' ) ? 'nav-tab-active' : '' ?>">
				<?php echo $tab; ?>
            </a>
		<?php endforeach; ?>
    </nav>
    <form action="" method="post">
        <table class="form-table">
            <tbody>
            <tr>
                <th scope="row">
                    <label for="expert_sms_theme">قالب خبرنامه :</label>
                </th>
                <td>
					<?php foreach ( $colors as $color => $value ): ?>
                        <div class="switch-row">
                            <span class="label-switch"><?php echo $value ?></span>
                            <label class="switch">
                                <input
                                        type="radio"
                                        name="theme"
                                        id="theme"
                                        value="<?php echo $color ?>"
									<?php echo isset( $expert_sms_options['theme'] ) ? checked( $expert_sms_options['theme'], $color ) : '' ?>
                                >
                                <span class="slider"></span>
                            </label>
                        </div>
					<?php endforeach; ?>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="admin_mobile_number">تعداد کاربران در هر صفحه:</label>
                </th>
                <td>
                    <input
                            type="number"
                            class="input-text"
                            name="users_per_page"
                            id="users_per_page"
                            value="<?php echo isset( $expert_sms_options['users_per_page'] ) ? $expert_sms_options['users_per_page'] : '' ?>"
                            placeholder="10"
                            min="1"
                            max="15"
                    >
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="admin_mobile_number">شماره همراه مديريت :</label>
                </th>
                <td>
                    <input
                            type="text"
                            class="input-text"
                            name="admin_mobile_number"
                            id="admin_mobile_number"
                            value="<?php echo isset( $expert_sms_options['admin_mobile_number'] ) ? $expert_sms_options['admin_mobile_number'] : '' ?>"
                            placeholder="09120000000"
                    >
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="title">عنوان خبرنامه :</label>
                </th>
                <td>
                    <input
                            type="text"
                            class="input-text"
                            name="title"
                            id="title"
                            value="<?php echo isset( $expert_sms_options['title'] ) ? $expert_sms_options['title'] : '' ?>"
                            placeholder="عنوان خبرنامه"
                    >
                </td>
            </tr>

            <tr>
                <th scope="row">
                    <label for="title">عنوان پاپ آپ :</label>
                </th>
                <td>
                    <input
                            type="text"
                            class="input-text"
                            name="popup_title"
                            id="popup_title"
                            value="<?php echo isset( $expert_sms_options['popup_title'] ) ? $expert_sms_options['popup_title'] : '' ?>"
                            placeholder="عنوان پاپ آپ"
                    >
                </td>
            </tr>

            <tr>
                <th scope="row">
                    <label for="desc">توضیحات خبرنامه :</label>
                </th>
                <td>
                    <input
                            type="text"
                            class="input-text"
                            name="desc"
                            id="desc"
                            value="<?php echo isset( $expert_sms_options['desc'] ) ? $expert_sms_options['desc'] : '' ?>"
                            placeholder="توضیحات خبرنامه"
                    >
                </td>
            </tr>
            </tbody>
			<?php wp_nonce_field( 'save_setting_action', 'save_setting_nonce' ); ?>
        </table>
		<?php submit_button( 'ذخیره تنظیمات', 'primary', 'save_settings' ); ?>
    </form>
</div>