<?php $expert_sms_options = get_option( 'expert_sms_settings' ); ?>
<div class="wrap exp-sms exp-sms-relative">
    <h1>تنظیمات خبرنامه پیامکی</h1>
    <nav class="nav-tab-wrapper">
		<?php foreach ( $tabs as $tab_name => $tab ): ?>
            <a href="<?php echo admin_url() . 'admin.php?page=sms_settings.php&tab=' . $tab_name; ?>"
               class="nav-tab <?php echo isset( $_GET['tab'] ) && $tab_name === $_GET['tab'] ? 'nav-tab-active' : '' ?>">
				<?php echo $tab; ?>
            </a>
		<?php endforeach; ?>
    </nav>
    <form action="" method="post">
        <table class="form-table">
            <tbody>
            <tr>
                <th scope="row">
                    <label for="new_order_notify">اعلان ثبت سفارش جدید :</label>
                </th>
                <td>
                    <div class="switch-row">
                        <span class="label-switch">فعال</span>
                        <label class="switch">
                            <input
                                    type="radio"
                                    name="new_order_notify"
                                    id="new_order_notify"
                                    value="1"
								<?php echo isset( $expert_sms_options['new_order_notify'] ) ? checked( $expert_sms_options['new_order_notify'], 1 ) : '' ?>
                            >
                            <span class="slider"></span>
                        </label>
                    </div>
                    <div class="switch-row">
                        <span class="label-switch">غیرفعال</span>
                        <label class="switch">
                            <input
                                    type="radio"
                                    name="new_order_notify"
                                    id="new_order_notify"
                                    value="0"
								<?php echo isset( $expert_sms_options['new_order_notify'] ) ? checked( $expert_sms_options['new_order_notify'], 0 ) : '' ?>
                            >
                            <span class="slider"></span>
                        </label>
                    </div>
                </td>

            </tr>
            <tr>
                <th scope="row">
                    <label for="active_newsletters">نمایش دکمه خبرنامه در تمامی محصولات :</label>
                </th>
                <td>
					<?php foreach ( [ 'فعال' => 'active', 'غیرفعال' => 'deactive' ] as $key => $status ) : ?>

                        <div class="switch-row">
                            <span class="label-switch"><?php echo $key ?></span>
                            <label class="switch">
                                <input
                                        type="radio"
                                        name="active_newsletters"
                                        id="active_newsletters"
                                        value="<?php echo $status ?>"
									<?php if ( isset( $expert_sms_options['active_newsletters'] ) ) :
										checked( $expert_sms_options['active_newsletters'], $status );
									endif; ?>
                                >
                                <span class="slider"></span>
                            </label>
                        </div>

					<?php endforeach; ?>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="stock_quantity">نمایش به هنگام ناموجود شدن محصول :</label>
                </th>
                <td>
                    <div class="switch-row">
                        <span class="label-switch">فعال</span>
                        <label class="switch">
                            <input
                                    type="radio"
                                    name="stock_quantity"
                                    id="stock_quantity"
                                    value="1"
								<?php echo isset( $expert_sms_options['stock_quantity'] ) && checked( $expert_sms_options['stock_quantity'], 1 ) ? 'CHECKED' : '' ?>
                            >
                            <span class="slider"></span>
                        </label>
                    </div>
                    <div class="switch-row">
                        <span class="label-switch">غیرفعال</span>
                        <label class="switch">
                            <input
                                    type="radio"
                                    name="stock_quantity"
                                    id="stock_quantity"
                                    value="0"
								<?php echo checked( $expert_sms_options['stock_quantity'] ?? '', '' ) ? 'CHECKED' : '' ?>
                            >
                            <span class="slider"></span>
                        </label>
                    </div>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="purchase_message">متن پیامک بعد از خرید :</label>
                    <p class="desc-form">برای ساخت متن پیامک از متغیر های زیر استفاده کنید:</p>
                    <em class="desc-form">
                        نام مشتری %name%
                        فاکتور %factor%
                        شماره سفارش %order%
                        رفتن به خط بعدی %enter%
                        نام فروشگاه %brand%
                    </em>
                </th>
                <td>
					<?php
					$default_value = '%name% عزیز
%enter%
%factor% با شماره پیگیری %order% در سایت %brand% با موفقیت خریداری شد.';
					?>
                    <textarea type="text" name="purchase_message" id="purchase_message" class="input-text" cols="70"
                              rows="10"><?php echo trim( $expert_sms_options['purchase_msg'] ?? $default_value ) ?></textarea>
                </td>
            </tr>
            </tbody>
			<?php wp_nonce_field( 'save_setting_action', 'save_setting_nonce' ); ?>
        </table>
		<?php submit_button( 'ذخیره تنظیمات', 'primary', 'save_settings' ); ?>
    </form>
</div>