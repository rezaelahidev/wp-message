<div id="sections_structure_box" class="postbox">
    <h3 class="hndle ui-sortable-handle"><span>مخاطبان دسته : <strong
                    style="color: #8BC34A">"<?php echo $_post['section'] ?? '' ?>"</strong></span></h3>
    <img class="loading" src="<?php echo SMS_ASS_IMG . 'ajax-loader.gif' ?>" alt="loading">
    <div id="loadFacebookG">
        <div id="blockG_1" class="facebook_blockG"></div>
        <div id="blockG_2" class="facebook_blockG"></div>
        <div id="blockG_3" class="facebook_blockG"></div>
    </div>
    <div class="danger" style="display: none"></div>
    <div class="success" style="display: none"></div>
    <div class="inside">
        <form action="" method="post">
            <table class="widefat" style="border: solid 1px #eee;margin-bottom: 35px;">
                <tr class="tbl-head">
                    <th class="tbl-head-col">نام و نام خانوادگی</th>
                    <th class="tbl-head-col">شماره همراه</th>
                    <th class="tbl-head-col">ارسال پیام</th>
                    <th class="tbl-head-col">انتخاب همه</th>
                    <th class="tbl-head-col">
                        <label class="switch">
                            <input type="checkbox" value="All" onClick="toggle(this)"/>
                            <span class="slider"></span>
                        </label>
                    </th>
                </tr>
                <tr>
					<?php foreach ( $users

					as $user ): ?>
					<?php $term_name = maybe_unserialize( $user->term_name ); ?>
					<?php if ( in_array( $_post['section'] ?? '', $term_name, true ) ): ?>
                    <td class="tbl-content-row">
						<?php echo empty( $user->user_name ) ? '<em style="color: #8bc34a">بدون نام</em>' : $user->user_name; ?>
                    </td>
                    <td class="tbl-content-row">
						<?php echo \ExpertSMS\Core\Utils::replace_persian_number( $user->mobile ); ?>
                    </td>
                    <td class="tbl-content-row">
                        <label class="switch">
                            <input
                                    type="checkbox"
                                    name="contact[]"
                                    id="contact"
                                    value="<?php echo $user->mobile ?>"
                                    data-username="<?php echo $user->user_name ?>"
                            >
                            <span class="slider"></span>
                        </label>
                    </td>
                    <td class="tbl-content-row"></td>
                    <td class="tbl-content-row"></td>
                </tr>
				<?php endif; ?>
				<?php endforeach; ?>
            </table>
            <label class="lbl-content" for="sms_content">متن پیامک</label>
            <textarea class="sms-content" name="sms_content"></textarea>

        </form>
    </div>
</div>
<script type="text/javascript">
    function toggle(source) {
        checkboxes_mobile = document.getElementsByName('contact[]');
        for (var i = 0, n = checkboxes_mobile.length; i < n; i++) {
            checkboxes_mobile[i].checked = source.checked;
        }
    }
</script>
