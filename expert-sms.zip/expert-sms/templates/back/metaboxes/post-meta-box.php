<div class="inside">
    <h3>
        تعداد کل کاربران:
        <strong style="color: #4caf50">
            <?php echo \ExpertSMS\Core\Utils::replace_persian_number(
			        ( ( $users[0]->total ?? 0 ) + ( $dl_users[0]->total ?? 0 ) )
		        ) . ' نفر'; ?>
        </strong>
    </h3>

    <div>
        <span>آیا پیام کوتاه ارسال شود ؟</span>
        <label class="switch">
            <input name="is_send_to" type="checkbox" value="enable" onClick="toggle(this)"/>
            <span class="slider"></span>
        </label>
    </div>

    <input class="sms-subject" type="hidden" name="subject" placeholder="لطفاً موضوع پیام را وارد کنید ">
    <label class="lbl-content" for="sms_content">متن پیامک</label>
    <textarea class="sms-content" name="sms_content"></textarea>
    <input class="group-send" type="submit" name="send_sms" value="بروز رسانی و ارسال پیامک">
</div>
