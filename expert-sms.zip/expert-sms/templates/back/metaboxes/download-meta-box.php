<div class="inside">
        <h3>تعداد کل کاربران <span style="color: #8bc34a;">"<?php echo get_the_title( $download_id ) ?>"</span>
            : <?php echo expert_sms_replace_persian_number( $users[0]->total ) . ' نفر'; ?></h3>
    <input class="sms-subject" type="hidden" name="subject" placeholder="لطفاً موضوع پیام را وارد کنید ">
    <label class="lbl-content" for="sms_content">متن پیامک</label>
    <textarea class="sms-content" name="sms_content"></textarea>
    <input class="group-send" type="submit" name="send_sms" value="بروز رسانی و ارسال پیامک">
</div>
