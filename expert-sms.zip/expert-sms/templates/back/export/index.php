<div class="wpar exp-sms">
    <h1>پشتیبان گیری از کاربران کمپین</h1>
    <form action="<?php echo admin_url( 'admin-post.php' ); ?>" method="post">
        <table class="form-table">
            <tr valign="top">
                <th scope="row">کاربران کمپین نوشته ها</th>
                <th scope="row">فرمت خروجی :</th>
            </tr>
            <tr valign="top">
                <td></td>
                <td>
                    <input type="hidden" name="action" value="postsExporter">
                    <label for="textExporter">متن :</label>
                    <input type="radio" name="format" id="textExporter" value="Text" checked>
                    <label for="csvExporter">اکسل :</label>
                    <input type="radio" name="format" id="csvExporter" value="Csv">
                </td>
                <td>
					<?php submit_button( 'دانلود فایل', 'primary', 'download_data' ); ?>
                </td>
            </tr>
        </table>
    </form>
    <form action="<?php echo admin_url( 'admin-post.php' ); ?>" method="post">
        <table class="form-table">
            <tr valign="top">
                <th scope="row">کاربران کمپین محصولات</th>
                <th scope="row">فرمت خروجی :</th>
            </tr>
            <tr valign="top">
                <td></td>
                <td>
                    <input type="hidden" name="action" value="productsExporter">
                    <label for="textExporter">متن :</label>
                    <input type="radio" name="format" id="textExporter" value="Text" checked>
                    <label for="csvExporter">اکسل :</label>
                    <input type="radio" name="format" id="csvExporter" value="Csv">
                </td>
                <td>
					<?php submit_button( 'دانلود فایل', 'primary', 'download_data' ); ?>
                </td>
            </tr>
        </table>
    </form>
    <form action="<?php echo admin_url( 'admin-post.php' ); ?>" method="post">
        <table class="form-table">
            <tr valign="top">
                <th scope="row">کاربران کمپین دانلودها</th>
                <th scope="row">فرمت خروجی :</th>
            </tr>
            <tr valign="top">
                <td></td>
                <td>
                    <input type="hidden" name="action" value="downloadsExporter">
                    <label for="textExporter">متن :</label>
                    <input type="radio" name="format" id="textExporter" value="Text" checked>
                    <label for="csvExporter">اکسل :</label>
                    <input type="radio" name="format" id="csvExporter" value="Csv">
                </td>
                <td>
					<?php submit_button( 'دانلود فایل', 'primary', 'download_data' ); ?>
                </td>
            </tr>
        </table>
    </form>
    <form action="<?php echo admin_url( 'admin-post.php' ); ?>" method="post">
        <table class="form-table">
            <tr valign="top">
                <th scope="row">کاربران کمپین دیجیتس</th>
                <th scope="row">فرمت خروجی :</th>
            </tr>
            <tr valign="top">
                <td></td>
                <td>
                    <input type="hidden" name="action" value="digitsExporter">
                    <label for="textExporter">متن :</label>
                    <input type="radio" name="format" id="textExporter" value="Text" checked>
                    <label for="csvExporter">اکسل :</label>
                    <input type="radio" name="format" id="csvExporter" value="Csv">
                </td>
                <td>
					<?php submit_button( 'دانلود فایل', 'primary', 'download_data' ); ?>
                </td>
            </tr>
        </table>
    </form>
</div>