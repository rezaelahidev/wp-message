<div class="wrap exp-sms">
    <h1>نمایش کاربران عضو محصولات ووکامرس</h1>
    <img class="loading" src="<?php echo SMS_ASS_IMG . 'ajax-loader.gif' ?>" alt="loading">
    <div id="loadFacebookG">
        <div id="blockG_1" class="facebook_blockG"></div>
        <div id="blockG_2" class="facebook_blockG"></div>
        <div id="blockG_3" class="facebook_blockG"></div>
    </div>
    <div class="danger" style="display: none"></div>
    <div class="success" style="display: none"></div>
    <form action="" method="post">
        <div class="tablenav top search-wrapper">
            <div class="alignleft actions bulkactions">
                <label class="lbl-search" for="search_content">متن جستجو : </label>
                <input class="input-search" type="text" name="search_content" id="search_content">
                <select name="type" id="type">
                    <option value="all">نمایش همه</option>
                    <option value="pre_num">براساس پیش شماره</option>
                    <option value="product_id">براساس شناسه محصول</option>
                    <option value="product_name">براساس نام محصول</option>
                </select>
                <button
                        class="button"
                        id="search_product_users">
                    جستجو
                </button>
            </div>
        </div>
    </form>
    <form action="" method="post">
        <table class="widefat">
            <tr class="tbl-head">
                <th class="tbl-head-col"><strong>ID و نام محصول</strong></th>
                <th class="tbl-head-col"><strong>نام و نام خانوادگی</strong></th>
                <th class="tbl-head-col"><strong>شماره تلفن</strong></th>
                <th class="tbl-head-col"><strong>حذف کاربر</strong></th>
                <th class="tbl-head-col"><strong>ویرایش اطلاعات</strong></th>
                <th class="tbl-head-col"><strong>ارسال پیامک تکی</strong></th>
                <th class="tbl-head-col"><strong>انتخاب همه</strong></th>
                <th class="tbl-head-col">
                    <label class="switch">
                        <input class="apple-switch" type="checkbox" value="All" onClick="toggle(this)"/>
                        <span class="slider"></span>
                    </label>
                </th>
            </tr>
	        <?php if ( ! empty( (array) $data ) ): ?>
		        <?php foreach ( $data as $record ): ?>
                    <tr class="exp-sms-user-rows">
                        <td style="width: 300px" class="tbl-content-row name-col">
                            <strong class="record-name">
                                <a href="<?php echo sprintf( '%s/post.php?post=%s&action=edit&post_type=product', admin_url(), $record->product_id ) ?>">
							        <?php echo get_the_title( (int) $record->product_id ); ?>
                                </a>
                            </strong>
                        </td>
                        <td class="tbl-content-row">
                            <em><?php echo ! empty( $record->user_name ) ? $record->user_name : '<em style="color: #8bc34a">بدون نام</em>'; ?></em>
                        </td>
                        <td class="tbl-content-row expert-sms-mobile" data-mobile="<?php echo $record->mobile ?>">
                            <em>
						        <?php
						        echo \ExpertSMS\Core\Utils::replace_persian_number( $record->mobile );
						        ?>
                            </em>
                        </td>
                        <td class="tbl-content-row">
                            <a class="exsms-delete-user"
                               href="<?php echo add_query_arg( [
						           'action' => 'user_delete',
						           'id'     => $record->id
					           ] ); ?>"
                               title="حذف کاربر">
                                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                     x="0px" y="0px"
                                     viewBox="0 0 27.965 27.965" style="enable-background:new 0 0 27.965 27.965;" xml:space="preserve">
<g>
    <g id="c142_x">
        <path d="M13.98,0C6.259,0,0,6.261,0,13.983c0,7.721,6.259,13.982,13.98,13.982c7.725,0,13.985-6.262,13.985-13.982
			C27.965,6.261,21.705,0,13.98,0z M19.992,17.769l-2.227,2.224c0,0-3.523-3.78-3.786-3.78c-0.259,0-3.783,3.78-3.783,3.78
			l-2.228-2.224c0,0,3.784-3.472,3.784-3.781c0-0.314-3.784-3.787-3.784-3.787l2.228-2.229c0,0,3.553,3.782,3.783,3.782
			c0.232,0,3.786-3.782,3.786-3.782l2.227,2.229c0,0-3.785,3.523-3.785,3.787C16.207,14.239,19.992,17.769,19.992,17.769z"/>
    </g>
    <g id="Capa_1_104_">
    </g>
</g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
</svg>
                            </a>
                        </td>
                        <td class="tbl-content-row">
                            <a class="exsms-edit-user"
                               href="<?php echo add_query_arg( [
						           'action' => 'user_edit',
						           'id'     => $record->id
					           ] ); ?>"
                               title="ویرایش اطلاعات">
                                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                     x="0px" y="0px"
                                     width="494.936px" height="494.936px" viewBox="0 0 494.936 494.936"
                                     style="enable-background:new 0 0 494.936 494.936;"
                                     xml:space="preserve">
<g>
    <g>
        <path d="M389.844,182.85c-6.743,0-12.21,5.467-12.21,12.21v222.968c0,23.562-19.174,42.735-42.736,42.735H67.157
			c-23.562,0-42.736-19.174-42.736-42.735V150.285c0-23.562,19.174-42.735,42.736-42.735h267.741c6.743,0,12.21-5.467,12.21-12.21
			s-5.467-12.21-12.21-12.21H67.157C30.126,83.13,0,113.255,0,150.285v267.743c0,37.029,30.126,67.155,67.157,67.155h267.741
			c37.03,0,67.156-30.126,67.156-67.155V195.061C402.054,188.318,396.587,182.85,389.844,182.85z"/>
        <path d="M483.876,20.791c-14.72-14.72-38.669-14.714-53.377,0L221.352,229.944c-0.28,0.28-3.434,3.559-4.251,5.396l-28.963,65.069
			c-2.057,4.619-1.056,10.027,2.521,13.6c2.337,2.336,5.461,3.576,8.639,3.576c1.675,0,3.362-0.346,4.96-1.057l65.07-28.963
			c1.83-0.815,5.114-3.97,5.396-4.25L483.876,74.169c7.131-7.131,11.06-16.61,11.06-26.692
			C494.936,37.396,491.007,27.915,483.876,20.791z M466.61,56.897L257.457,266.05c-0.035,0.036-0.055,0.078-0.089,0.107
			l-33.989,15.131L238.51,247.3c0.03-0.036,0.071-0.055,0.107-0.09L447.765,38.058c5.038-5.039,13.819-5.033,18.846,0.005
			c2.518,2.51,3.905,5.855,3.905,9.414C470.516,51.036,469.127,54.38,466.61,56.897z"/>
    </g>
</g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
</svg>
                            </a>
                        </td>
                        <td class="tbl-content-row">
                            <a class="exsms-send-to-user"
                               href="<?php echo add_query_arg( [
						           'action' => 'send_sms',
						           'id'     => $record->id
					           ] ); ?>"
                               title="ارسال پیامک">
                                <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                     x="0px" y="0px"
                                     viewBox="0 0 495.003 495.003" style="enable-background:new 0 0 495.003 495.003;" xml:space="preserve">
<g id="XMLID_51_">
    <path id="XMLID_53_" d="M164.711,456.687c0,2.966,1.647,5.686,4.266,7.072c2.617,1.385,5.799,1.207,8.245-0.468l55.09-37.616
		l-67.6-32.22V456.687z"/>
    <path id="XMLID_52_" d="M492.431,32.443c-1.513-1.395-3.466-2.125-5.44-2.125c-1.19,0-2.377,0.264-3.5,0.816L7.905,264.422
		c-4.861,2.389-7.937,7.353-7.904,12.783c0.033,5.423,3.161,10.353,8.057,12.689l125.342,59.724l250.62-205.99L164.455,364.414
		l156.145,74.4c1.918,0.919,4.012,1.376,6.084,1.376c1.768,0,3.519-0.322,5.186-0.977c3.637-1.438,6.527-4.318,7.97-7.956
		L494.436,41.257C495.66,38.188,494.862,34.679,492.431,32.443z"/>
</g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
                                    <g>
                                    </g>
</svg>
                            </a>
                        </td>
                        <td class="tbl-content-row">
                            <label class="switch">
                                <input
                                        type="checkbox"
                                        name="contact[]"
                                        id="contact"
                                        value="<?php echo $record->mobile ?>"
                                        data-username="<?php echo $record->user_name; ?>"
                                >
                                <span class="slider"></span>
                            </label>
                        </td>
                        <td class="tbl-content-row expert-sms-sender-result"></td>
                    </tr>
		        <?php endforeach; ?>
	        <?php else: ?>
                <tr>
                    <td style="color: red" class="tbl-content-row">نتیجه ای یافت نشد.</td>
                </tr>
	        <?php endif; ?>
        </table>
<!--        <label class="switch">-->
<!--            <input-->
<!--                    type="checkbox"-->
<!--                    value="All"-->
<!--                    name="send_all"-->
<!--                    id="send_all"-->
<!--                    data-send_all="okay"-->
<!--                    data-post_type="product"-->
<!--            />-->
<!--            <span class="slider"></span>-->
<!--        </label>-->
<!--        <span style="display: block;">ارسال پیام به تمامی کاربران</span>-->
		<?php
		$page_links = paginate_links( array(
			'base'      => add_query_arg( 'pagenum', '%#%' ),
			'format'    => '',
			'prev_text' => __( '&laquo;', 'text-domain' ),
			'next_text' => __( '&raquo;', 'text-domain' ),
			'total'     => $num_of_pages,
			'current'   => $pagenum
		) );

		if ( $page_links ) {
			echo '<div class="tablenav"><div class="tablenav-pages" style="margin: 1em 0">' . $page_links . '</div></div>';
		}
		?>
        <label class="lbl-content" for="sms_content">متن پیامک</label>
        <textarea class="sms-content" name="sms_content"></textarea>
        <input class="group-send-posts" type="submit" name="send_sms" value="ارسال پیام">
    </form>
</div>
<script type="text/javascript">
    function toggle(source) {
        checkboxes_contact = document.getElementsByName('contact[]');
        for (var i = 0, n = checkboxes_contact.length; i < n; i++) {
            checkboxes_contact[i].checked = source.checked;
        }
    }
</script>
