<div class="expsms-container">

	<div class="expsms-row">

		<div class="expsms-col-12">

            <div class="icon-page">
                <img src="<?php echo SMS_ASS_IMG . 'login-icon.jpg' ?>" alt="">
            </div>

            <form action="" id="user_register">

				<div class="expsms-field">
					<label for="mobile" class="expsms-lbl">شماره همراه : </label>
					<input type="tel" name="mobile" id="mobile" placeholder="09120000000">
				</div>
				<div class="expsms-field">
					<label for="full_name" class="expsms-lbl">نام و نام خانوادگی : </label>
					<input type="text" placeholder="نام و نام خانوادگی" name="full_name" id="full_name">
				</div>
				<div class="expsms-field">
					<input name="signup_submit" type="submit" value="ثبت نام">
				</div>
				<?php wp_nonce_field( 'signup_user', 'signup_user_field' ); ?>

			</form>

			<img class="loading" src="<?php echo SMS_ASS_IMG . 'ajax-loader.gif' ?>" alt="loading">
			<div id="loadFacebookG">
				<div id="blockG_1" class="facebook_blockG"></div>
				<div id="blockG_2" class="facebook_blockG"></div>
				<div id="blockG_3" class="facebook_blockG"></div>
			</div>

		</div>

	</div>

</div>

<div class="alert-success"></div>

<div class="alert-danger"></div>
