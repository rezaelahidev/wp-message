<div class="wrap exp-sms">
    <h1>ویرایش اطلاعات کاربران خبرنامه پیامکی</h1>
    <form action="" method="post">
        <table class="form-table">
            <tbody>

			<?php foreach ( $data as $item ): ?>

				<?php if ( isset( $_GET['action'] ) && 'user_edit_digits' !== $_GET['action'] ): ?>
                    <tr>
                        <th scope="row">
                            <label for="name">نام و نام خانوادگی :</label>
                        </th>
                        <td>
                            <input class="input-text" type="text" name="name" id="name"
                                   value="<?php echo $item->user_name; ?>"
                                   placeholder="نام و نام خانوادگی ...">
                        </td>
                    </tr>
				<?php endif; ?>

                <tr>
                    <th scope="row">
                        <label for="mobile">شماره همراه :</label>
                    </th>
                    <td>
                        <input class="input-text" type="text" name="mobile" id="mobile"
                               value="<?php echo isset( $_GET['action'] ) && 'user_edit_digits' === $_GET['action'] ? $item->meta_value : $item->mobile ?>"
                               placeholder="شماره همراه ...">
                    </td>
                </tr>
			<?php endforeach; ?>
            </tbody>
			<?php wp_nonce_field( 'edit_user', 'edit_user_nonce' ); ?>
        </table>
		<?php submit_button( 'ویرایش اطلاعات کاربری', 'primary', 'edit_user' ); ?>
    </form>
</div>