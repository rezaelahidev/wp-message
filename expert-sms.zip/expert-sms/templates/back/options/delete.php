<div class="wrap exp-sms">
	<h1>عملیات حذف</h1>
	<div class="delete-user">
		<p>کاربر مورد نظر از سامانه پیامکی حذف شد .</p>
	</div>
</div>