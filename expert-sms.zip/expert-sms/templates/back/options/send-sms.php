<div class="wrap exp-sms">
    <h1>ارسال پیامک سفارشی</h1>
    <form action="" method="post">
		<?php foreach ( $data ?? [] as $item ): ?>
            <p>
                <strong>ارسال پیامک به:</strong>
                <em style="color: #ff9800">
					<?php
					if ( isset( $_GET['action'] ) && 'send_sms_digits' === $_GET['action'] ) {
						$user = get_user_by( 'ID', (int) $item->user_id );
						if ( $user ) {
							$name = $user->display_name;
						}
					} else {
						$name = ! empty( $item->user_name ) ? $item->user_name : 'بدون نام';
					}
					?>


					<?php echo $name ?? $item->user_name ?? 'بدون نام'; ?>
                </em>
            </p>
            <ul>
                <li>برای استفاده از نام کاربر جاری میتوانید از متغیر<code>%name%</code> در متن پیامک استفاده کنید .</li>
                <li>برای رفتن به خط بعدی در متن پیامک باید از <code>%E</code> استفاده کنید .</li>
            </ul>
		<?php endforeach; ?>
        <table class="form-table">
            <tbody>
            <tr>
                <th scope="row">
                    <label for="content">متن پیامک :</label>
                </th>
                <td>
                    <textarea class="input-text" name="content" id="content" cols="30" rows="10"></textarea>
                </td>
            </tr>
            </tbody>
        </table>
		<?php submit_button( 'ارسال پیامک', 'primary', 'send' ); ?>
    </form>
</div>
