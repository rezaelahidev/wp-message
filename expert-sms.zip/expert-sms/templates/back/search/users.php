<?php
if ( ! is_null( $users ) ) {
	foreach ( $users as $user ) {
		$html .= '<tr class="exp-sms-user-rows">';
		$html .= '<td style="width: 300px" class="tbl-content-row name-col">';
		$html .= '<strong class="record-name">ID:' . $user->post_id . ' | ' . $user->post_name . '</strong>';
		$html .= '</td>
		<td class="tbl-content-row">
			<em>' . $user->user_name . '</em></td>';
		$html .= '<td class="tbl-content-row">
			<em>' . expert_sms_replace_persian_number( $user->mobile ) . '</em>
		</td>';
		$html .= '<td class="tbl-content-row"><a
				href="' . esc_url( admin_url( 'admin.php?page=post_users.php&action=user_delete&id=' . $user->id ) ) . '"
				title="حذف کاربر"><span class="dashicons dashicons-no"></span></a></td>';
		$html .= '<td class="tbl-content-row"><a
				href="' . esc_url( admin_url( 'admin.php?page=post_users.php&action=user_edit&id=' . $user->id ) ) . '"
				title="ویرایش اطلاعات"><span class="dashicons dashicons-hammer"></span></a></td>';
		$html .= '<td class="tbl-content-row"><a
				href="' . esc_url( admin_url( 'admin.php?page=post_users.php&action=send_sms&id=' . $user->id ) ) . '"
				title="ارسال پیامک"><span class="dashicons dashicons-email-alt"></span></a></td>';
		$html .= '<td class="tbl-content-row">
			<label class="switch">
				<input type="checkbox" name="contact[]" id="contact"
				       value="' . $user->mobile . '">';
		$html .= '<span class="slider"></span>
			</label>
		</td>
		<td class="tbl-content-row"></td></tr>';
	}
} else {
	return false;
}
if ( ! is_null( $dl_users ) ) {
	foreach ( $dl_users as $user ) {
		$html .= '<tr class="exp-sms-user-rows">';
		$html .= '<td style="width: 300px" class="tbl-content-row name-col"><span class="dashicons dashicons-arrow-up"></span>';
		$html .= '<strong class="record-name">ID:' . $user->download_id . ' | ' . $user->download_name . '</strong>';
		$html .= '</td>
		<td class="tbl-content-row" style="position: relative">
			<em>' . $user->user_name . '</em>';
		$html .= $user->purchase == true ? '<span class="purchase-status">خریدار' . '</span>' : '';
		$html .= '</td>';
		$html .= '<td class="tbl-content-row">
			<em>' . expert_sms_replace_persian_number( $user->mobile ) . '</em>
		</td>';
		$html .= '<td class="tbl-content-row"><a
				href="' . esc_url( admin_url( 'admin.php?page=post_users.php&action=user_delete&id=' . $user->id ) ) . '"
				title="حذف کاربر"><span class="dashicons dashicons-no"></span></a></td>';
		$html .= '<td class="tbl-content-row"><a
				href="' . esc_url( admin_url( 'admin.php?page=post_users.php&action=user_edit&id=' . $user->id ) ) . '"
				title="ویرایش اطلاعات"><span class="dashicons dashicons-hammer"></span></a></td>';
		$html .= '<td class="tbl-content-row"><a
				href="' . esc_url( admin_url( 'admin.php?page=post_users.php&action=send_sms&id=' . $user->id ) ) . '"
				title="ارسال پیامک"><span class="dashicons dashicons-email-alt"></span></a></td>';
		$html .= '<td class="tbl-content-row">
			<label class="switch">
				<input type="checkbox" name="contact[]" id="contact"
				       value="' . $user->mobile . '">';
		$html .= '<span class="slider"></span>
			</label>
		</td>
		<td class="tbl-content-row"></td></tr>';
	}
} else {
	return false;
}

return wp_send_json( [
	'success'      => true,
	'render_users' => $html
] );

$html .= '</table>';