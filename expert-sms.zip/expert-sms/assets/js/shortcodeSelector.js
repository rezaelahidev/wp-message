function getSelectedContent(a, d) {
    var b = a.selection.getContent({
        format: "text"
    });
    var c = b.length;
    if (c <= 0) {
        return d
    } else {
        return b
    }
}

(function () {
    tinymce.PluginManager.add("shortcodeSelector", function (a, b) {
        a.addButton("shortcodeSelector", {
            text: "خبرنامه",
            icon: false,
            type: "menubutton",
            menu: [{
                text: "خبرنامه نوشته ها",
                onclick: function () {
                    a.insertContent('[smsNewsletters dialog_heading="' + getSelectedContent(a, "لطفاً عنوان باکس خبرنامه را وارد کنید ") + '  title="' + getSelectedContent(a, "لطفاً عنوان خبرنامه را وارد کنید ") + '" name="' + getSelectedContent(a, "false") + '" description="' + getSelectedContent(a, "متن توضیحات ") + '"]<br>')
                }
            }, {
                text: "خبرنامه دانلود ها",
                onclick: function () {
                    a.insertContent('[smsNewslettersDownload dialog_heading="' + getSelectedContent(a, "لطفاً عنوان باکس خبرنامه را وارد کنید ") + ' title="' + getSelectedContent(a, "لطفاً عنوان خبرنامه را وارد کنید ") + '" name="' + getSelectedContent(a, "false") + '" description="' + getSelectedContent(a, "متن توضیحات ") + '"]<br>')
                }
            }, {
                text: "خبرنامه محصولات",
                onclick: function () {
                    a.insertContent('[smsNewslettersProduct dialog_heading="' + getSelectedContent(a, "لطفاً عنوان باکس خبرنامه را وارد کنید ") + ' title="' + getSelectedContent(a, "لطفاً عنوان خبرنامه را وارد کنید ") + '" name="' + getSelectedContent(a, "false") + '" description="' + getSelectedContent(a, "متن توضیحات ") + '"]<br>')
                }
            }
            ]
        })
    })
})();