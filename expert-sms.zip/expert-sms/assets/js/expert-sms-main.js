jQuery(document).ready(function ($) {
    var $dialog = $('.dialog');
    $(document).on('keyup', function onDocumentKeyup(e) {
        if (e.keyCode === 27) {
            dialogclose.trigger('click');
        }
    });

    $('#newsletter-btn').on('click',function(){
        $dialog.addClass('opened');
        $('body').addClass('has-dialog');
    });
    var dialogmask = $('.dialog__mask'),
        dialogclose = $('.dialog__header svg');

    dialogmask.on('click',closeDialog);
    dialogclose.on('click',closeDialog);
    function closeDialog(){
        $dialog.removeClass('opened');
        $('body').removeClass('has-dialog');
    };
});