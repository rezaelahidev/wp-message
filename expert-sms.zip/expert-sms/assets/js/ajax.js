jQuery(document).ready(function ($) {

    function sign_in($this) {

        var mobile = $('#mobile').val();
        var nonce = $('#signin_user_field').val();
        var verify_code = $('#verify_code').val();

        $.ajax({
            url: expert_sms.admin_url,
            type: 'post',
            dataType: 'json',
            data: {
                action: 'signin_user',
                mobile: mobile,
                nonce: nonce,
                verify_code: verify_code,
            },
            beforeSend: function () {
                $('#loadFacebookG').show(0).delay(3000).hide(0);
                $('.alert-danger').css({"display": "none"});
                $('.alert-success').css({"display": "none"});
            },
            success: function (response) {

                if (response.success) {

                    if (response.data.show_verify_field) {

                        $('.expsms-field input#verify_code').show();
                        $('.expsms-field .verify-code').show();

                        timer(response.data.resend, mobile);
                    }

                    $('.alert-danger').css({"display": "none"});
                    $('.alert-success').text(response.data.message);
                    $('.alert-success').css({"display": "block"});
                    $('#verify_code').val('');

                    if (response.data.redirect) {

                        window.location.replace(expert_sms.profile_page);
                    }

                } else {
                    $('.alert-success').css({"display": "none"});
                    $('.alert-danger').text(response.message);
                    $('.alert-danger').css({"display": "block"});
                    $('#verify_code').val('');
                }
            },
            error: function (response) {

            }
        });
    }

    function sign_up($this) {

        var mobile = $('#mobile').val();
        var nonce = $('#signup_user_field').val();
        var full_name = $('#full_name').val();

        $.ajax({
            url: expert_sms.admin_url,
            type: 'post',
            dataType: 'json',
            data: {
                action: 'signup_user',
                mobile: mobile,
                nonce: nonce,
                full_name: full_name
            },
            beforeSend: function () {
                $('#loadFacebookG').show(0).delay(3000).hide(0);
                $('.alert-danger').css({"display": "none"});
                $('.alert-success').css({"display": "none"});
            },
            success: function (response) {
                if (response.success) {
                    $('.alert-danger').css({"display": "none"});
                    $('.alert-success').text(response.data.message);
                    $('.alert-success').css({"display": "block"});
                    $('#full_name').val('');
                    window.location.replace(expert_sms.signin_page);
                } else {
                    $('.alert-success').css({"display": "none"});
                    $('.alert-danger').text(response.message);
                    $('.alert-danger').css({"display": "block"});
                    $('#verify_code').val('');
                }
            },
            error: function (response) {

            }
        });
    }

    function resend_code(button, mobile) {

        $.ajax({
            url: expert_sms.admin_url,
            type: 'post',
            dataType: 'json',
            data: {
                action: 'resend_code',
                mobile: mobile,
            },
            beforeSend: function () {
                $('#loadFacebookG').show(0).delay(3000).hide(0);
                $('.alert-danger').css({"display": "none"});
                $('.alert-success').css({"display": "none"});
            },
            success: function (response) {

                if (response.success) {

                    $('.alert-danger').css({"display": "none"});
                    $('.alert-success').text(response.data.message);
                    $('.alert-success').css({"display": "block"});
                    $('#verify_code').val('');

                    if (response.data.redirect) {

                        window.location.replace(expert_sms.profile_page);
                    }

                } else {
                    $('.alert-success').css({"display": "none"});
                    $('.alert-danger').text(response.message);
                    $('.alert-danger').css({"display": "block"});
                    $('#verify_code').val('');
                }
            },
            error: function (response) {

            }
        });
    }

    function timer(resend_button , mobile) {

        //timer counter
        var counter = 120;

        var interval = setInterval(function () {

            counter--;

            $('.timer').text(counter + 'ثانیه تا ارسال مجدد');

            // Display 'counter' wherever you want to display it.
            if (counter == 0) {

                $('.timer').hide();

                $('#signin_submit').after(resend_button);

                $('.resend-code').on('click', function (e) {

                    e.preventDefault();

                    resend_code($(this), mobile);
                })

                clearInterval(interval);
            }
        }, 1000);
    }

    $('#register_post_news').on('click', function (event) {
        event.preventDefault();
        var _this = $(this);
        var mobile = $('#mobile').val();
        var nonce = $('#register_mobile_nonce').val();
        var pid = _this.data('pid');
        var username = $('#sms_username').val();
        $.ajax({
            url: expert_sms.admin_url,
            type: 'post',
            dataType: 'json',
            data: {
                action: 'register_newsletters_post_user',
                username: username,
                mobile: mobile,
                nonce: nonce,
                pid: pid
            },
            beforeSend: function () {
                $('#loadFacebookG').show(0).delay(3000).hide(0);
                $('.alert-danger').css({"display": "none"});
                $('.alert-success').css({"display": "none"});
            },
            success: function (response) {
                if (response.status_message) {
                    $('.alert-danger').css({"display": "none"});
                    $('.alert-success').text(response.report_message);
                    $('.alert-success').css({"display": "block"});
                    $('#sms_username').val('');
                    $('#mobile').val('');
                } else {
                    $('.alert-success').css({"display": "none"});
                    $('.alert-danger').text(response.report_message);
                    $('.alert-danger').css({"display": "block"});
                    $('#sms_username').val('');
                    $('#mobile').val('');
                }
            },
            error: function (response) {

            }
        });
    });
    $('#register_download_news').on('click', function (event) {
        event.preventDefault();
        var _this = $(this);
        var mobile = $('#mobile').val();
        var nonce = $('#register_mobile_nonce').val();
        var download_id = _this.data('did');
        var username = $('#sms_username').val();
        $.ajax({
            url: expert_sms.admin_url,
            type: 'post',
            dataType: 'json',
            data: {
                action: 'register_newsletters_download_user',
                username: username,
                mobile: mobile,
                nonce: nonce,
                download_id: download_id
            },
            beforeSend: function () {
                $('#loadFacebookG').show(0).delay(3000).hide(0);
                $('.alert-danger').css({"display": "none"});
                $('.alert-success').css({"display": "none"});
            },
            success: function (response) {
                if (response.status_message) {
                    $('.alert-success').text(response.report_message);
                    $('.alert-danger').css({"display": "none"});
                    $('.alert-success').css({"display": "block"});
                    $('#sms_username').val('');
                    $('#mobile').val('');
                } else {
                    $('.alert-danger').text(response.report_message);
                    $('.alert-success').css({"display": "none"});
                    $('.alert-danger').css({"display": "block"});
                    $('#sms_username').val('');
                    $('#mobile').val('');
                }
            },
            error: function (response) {

            }
        });
    });
    $('#register_product_news').on('click', function (event) {
        event.preventDefault();
        var _this = $(this);
        var mobile = $('#mobile').val();
        var nonce = $('#register_mobile_nonce').val();
        var product_id = _this.data('product_id');
        var username = $('#sms_username').val();
        $.ajax({
            url: expert_sms.admin_url,
            type: 'post',
            dataType: 'json',
            data: {
                action: 'register_newsletters_product_user',
                username: username,
                mobile: mobile,
                nonce: nonce,
                product_id: product_id
            },
            beforeSend: function () {
                $('#loadFacebookG').show(0).delay(3000).hide(0);
                $('.alert-danger').css({"display": "none"});
                $('.alert-success').css({"display": "none"});
            },
            success: function (response) {
                if (response.status_message) {
                    $('.alert-success').text(response.report_message);
                    $('.alert-danger').css({"display": "none"});
                    $('.alert-success').css({"display": "block"});
                    $('#sms_username').val('');
                    $('#mobile').val('');
                } else {
                    $('.alert-danger').text(response.report_message);
                    $('.alert-success').css({"display": "none"});
                    $('.alert-danger').css({"display": "block"});
                    $('#sms_username').val('');
                    $('#mobile').val('');
                }
            },
            error: function (response) {

            }
        });
    });

    $('input[name="signin_submit"]').on('click', function (event) {

        event.preventDefault();

        var _this = $(this);

        sign_in(_this);
    });

    $('input[name="signup_submit"]').on('click', function (event) {

        event.preventDefault();

        var _this = $(this);

        sign_up(_this);
    });

    $('.resend-code').on('click', function (e) {

        e.preventDefault();

        var mobile = $('#mobile').val();

        resend_code($(this), mobile);
    })
});