<?php
/**
 * Plugin Name: Expert SMS
 * Plugin URI: https://www.zhaket.com/product/expertsms-wordpress-plugin/
 * Description: WordPress SMS Marketing.
 * Version: 6.0.1
 * Author: Reza Elahi
 * Author URI: relahi1373@gmail.com
 * Text Domain: ExpertSMS
 */

defined( 'ABSPATH' ) || die( __( 'Access Denied!', 'ExpertSMS' ) );

require_once __DIR__ . '/vendor/autoload.php';

/**
 * Define all constants.
 *
 * @since 1.0.0
 */
const SMS__FILE__ = __FILE__;
define( 'SMS_ASS_CSS', plugin_dir_url( __FILE__ ) . 'assets/css/' );
define( 'SMS_ASS_IMG', plugin_dir_url( __FILE__ ) . 'assets/img/' );
define( 'SMS_ASS_JS', plugin_dir_url( __FILE__ ) . 'assets/js/' );
define( 'SMS_INC', plugin_dir_path( __FILE__ ) . 'inc/' );
define( 'SMS_ADMIN', plugin_dir_path( __FILE__ ) . 'admin/' );
define( 'SMS_TMP', plugin_dir_path( __FILE__ ) . 'templates/' );
define( 'SMS_DIR', plugin_dir_path( __FILE__ ) );
define( 'SMS_SRC', plugin_dir_url( __FILE__ ) . 'src/' );
const SMS_VER = '6.0.1';


\ExpertSMS\ExpertSMS::getInstance();

